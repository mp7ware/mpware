#using module .\CustomCheckedListBoxModule
function debloat {

  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
    , [Parameter(mandatory = $false)] [bool]$debloatAll = $false
    , [Parameter(mandatory = $false)] [bool]$debloatSXE = $false
    , [Parameter(mandatory = $false)] [bool]$debloatSX = $false
    , [Parameter(mandatory = $false)] [bool]$debloatE = $false
    , [Parameter(mandatory = $false)] [bool]$debloatS = $false
  )
  
  # ----------------------------------------------------------- DEBLOAT FUNCTIONS ---------------------------------------------------

  #TODO: REMOVE THESE FUNCTIONS AND USE MINE INSTEAD

  function Get-InstalledSoftware {
  
    [CmdletBinding()]
    param(
      [ArgumentCompleter( {
          param ($Command, $Parameter, $WordToComplete, $CommandAst, $FakeBoundParams)

          Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\', 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\' | ForEach-Object { try { Get-ItemPropertyValue -Path $_.pspath -Name DisplayName -ErrorAction Stop } catch { $null } } | Where-Object { $_ -like "*$WordToComplete*" } | ForEach-Object { "'$_'" }
        })]
      [string[]] $appName,

      [Parameter(ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
      [string[]] $computerName,

      [switch] $dontIgnoreUpdates,

      [ValidateNotNullOrEmpty()]
      [ValidateSet('AuthorizedCDFPrefix', 'Comments', 'Contact', 'DisplayName', 'DisplayVersion', 'EstimatedSize', 'HelpLink', 'HelpTelephone', 'InstallDate', 'InstallLocation', 'InstallSource', 'Language', 'ModifyPath', 'NoModify', 'NoRepair', 'Publisher', 'QuietUninstallString', 'UninstallString', 'URLInfoAbout', 'URLUpdateInfo', 'Version', 'VersionMajor', 'VersionMinor', 'WindowsInstaller')]
      [string[]] $property = ('DisplayName', 'DisplayVersion', 'UninstallString'),

      [switch] $ogv
    )

    PROCESS {
      $scriptBlock = {
        param ($Property, $DontIgnoreUpdates, $appName)

        # where to search for applications
        $RegistryLocation = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\', 'SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\'

        # define what properties should be outputted
        $SelectProperty = @('DisplayName') # DisplayName will be always outputted
        if ($Property) {
          $SelectProperty += $Property
        }
        $SelectProperty = $SelectProperty | Select-Object -Unique

        $RegBase = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $env:COMPUTERNAME)
        if (!$RegBase) {
          Write-Error "Unable to open registry on $env:COMPUTERNAME"
          return
        }

        foreach ($RegKey in $RegistryLocation) {
          Write-Verbose "Checking '$RegKey'"
          foreach ($appKeyName in $RegBase.OpenSubKey($RegKey).GetSubKeyNames()) {
            Write-Verbose "`t'$appKeyName'"
            $ObjectProperty = [ordered]@{}
            foreach ($CurrentProperty in $SelectProperty) {
              Write-Verbose "`t`tGetting value of '$CurrentProperty' in '$RegKey$appKeyName'"
              $ObjectProperty.$CurrentProperty = ($RegBase.OpenSubKey("$RegKey$appKeyName")).GetValue($CurrentProperty)
            }

            if (!$ObjectProperty.DisplayName) {
              # Skipping. There are some weird records in registry key that are not related to any app"
              continue
            }

            $ObjectProperty.ComputerName = $env:COMPUTERNAME

            # create final object
            $appObj = New-Object -TypeName PSCustomObject -Property $ObjectProperty

            if ($appName) {
              $appNameRegex = $appName | ForEach-Object {
                [regex]::Escape($_)
              }
              $appNameRegex = $appNameRegex -join '|'
              $appObj = $appObj | Where-Object { $_.DisplayName -match $appNameRegex }
            }

            if (!$DontIgnoreUpdates) {
              $appObj = $appObj | Where-Object { $_.DisplayName -notlike '*Update for Microsoft*' -and $_.DisplayName -notlike 'Security Update*' }
            }

            $appObj
          }
        }
      }

      $param = @{
        scriptBlock  = $scriptBlock
        ArgumentList = $property, $dontIgnoreUpdates, $appName
      }
      if ($computerName) {
        $param.computerName = $computerName
        $param.HideComputerName = $true
      }

      $result = Invoke-Command @param

      if ($computerName) {
        $result = $result | Select-Object * -ExcludeProperty RunspaceId
      }
    }

    END {
      if ($ogv) {
        $comp = $env:COMPUTERNAME
        if ($computerName) { $comp = $computerName }
        $result | Out-GridView -PassThru -Title "Installed software on $comp"
      }
      else {
        $result
      }
    }
  }

  function Uninstall-ApplicationViaUninstallString {
  
    [CmdletBinding()]
    param (
      [Parameter(Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
      [Alias('displayName')]
      [ArgumentCompleter( {
          param ($Command, $Parameter, $WordToComplete, $CommandAst, $FakeBoundParams)

          Get-ChildItem 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\', 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\' | ForEach-Object { try { Get-ItemPropertyValue -Path $_.pspath -Name DisplayName -ErrorAction Stop } catch { $null } } | Where-Object { $_ -like "*$WordToComplete*" } | ForEach-Object { "'$_'" }
        })]
      [string[]] $name,

      [string] $addArgument
    )

    begin {
      # without admin rights msiexec uninstall fails without any error
      if (! ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
        throw 'Run with administrator rights'
      }

      if (!(Get-Command Get-InstalledSoftware)) {
        throw 'Function Get-InstalledSoftware is missing'
      }
    }

    process {
      $appList = Get-InstalledSoftware -property DisplayName, UninstallString, QuietUninstallString | Where-Object DisplayName -In $name

      if ($appList) {
        foreach ($app in $appList) {
          if ($app.QuietUninstallString) {
            $uninstallCommand = $app.QuietUninstallString
          }
          else {
            $uninstallCommand = $app.UninstallString
          }
          $name = $app.DisplayName

          if (!$uninstallCommand) {
            Write-Warning "Uninstall command is not defined for app '$name'"
            continue
          }

          if ($uninstallCommand -like 'msiexec.exe*') {
            # it is MSI
            $uninstallMSIArgument = $uninstallCommand -replace 'MsiExec.exe'
            # sometimes there is /I (install) instead of /X (uninstall) parameter
            $uninstallMSIArgument = $uninstallMSIArgument -replace '/I', '/X'
            # add silent and norestart switches
            $uninstallMSIArgument = "$uninstallMSIArgument /QN"
            if ($addArgument) {
              $uninstallMSIArgument = $uninstallMSIArgument + ' ' + $addArgument
            }
            Write-Warning "Uninstalling app '$name' via: msiexec.exe $uninstallMSIArgument"
            Start-Process 'msiexec.exe' -ArgumentList $uninstallMSIArgument -Wait
          }
          else {
            # it is EXE
            # region extract path to the EXE uninstaller
            # path to EXE is typically surrounded by double quotes
            $match = ([regex]'("[^"]+")(.*)').Matches($uninstallCommand)
            if (!$match.count) {
              # string doesn't contain ", try search for ' instead
              $match = ([regex]"('[^']+')(.*)").Matches($uninstallCommand)
            }
            if ($match.count) {
              $uninstallExe = $match.captures.groups[1].value
            }
            else {
              # string doesn't contain even '
              # before blindly use the whole string as path to an EXE, check whether it doesn't contain common argument prefixes '/', '-' ('-' can be part of the EXE path, but it is more safe to make false positive then fail later because of faulty command)
              if ($uninstallCommand -notmatch '/|-') {
                $uninstallExe = $uninstallCommand
              }
            }
            if (!$uninstallExe) {
              Write-Error "Unable to extract EXE path from '$uninstallCommand'"
              continue
            }
            #endregion extract path to the EXE uninstaller
            if ($match.count) {
              $uninstallExeArgument = $match.captures.groups[2].value
            }
            else {
              Write-Verbose "I've used whole uninstall string as EXE path"
            }
            if ($addArgument) {
              $uninstallExeArgument = $uninstallExeArgument + ' ' + $addArgument
            }
            # Start-Process param block
            $param = @{
              FilePath = $uninstallExe
              Wait     = $true
            }
            if ($uninstallExeArgument) {
              $param.ArgumentList = $uninstallExeArgument
            }
            Write-Warning "Uninstalling app '$name' via: $uninstallExe $uninstallExeArgument"
            Start-Process @param
          }
        }
      }
      else {
        Write-Warning "No software with name $($name -join ', ') was found. Get the correct name by running 'Get-InstalledSoftware' function."
      }
    }
  }


  function debloat-TeamsOneDrive {
    #   Description:
    # This script will remove and disable OneDrive integration.
 
    # taskkill.exe /F /IM 'OneDrive.exe' *>$null 
    taskkill.exe /F /IM 'explorer.exe' *>$null 
    Stop-Process -Name OneDrive* -Force -ErrorAction SilentlyContinue

    $oneDrivePaths = @(
      "$ENV:SystemRoot\System32\OneDriveSetup.exe",
      "$ENV:SystemRoot\SysWOW64\OneDriveSetup.exe",
      "$ENV:ProgramFiles\Microsoft Office\root\Integration\Addons\OneDriveSetup.exe",
      "${ENV:ProgramFiles(x86)}\Microsoft Office\root\Integration\Addons\OneDriveSetup.exe"
    )

    foreach ($path in $oneDrivePaths) {
      if (Test-Path $path) {
        Start-Process -FilePath "$path" -ArgumentList '/uninstall'
      }
    }
    
   
    $OneDrivePath = $env:OneDrive

    # if ($OneDrivePath) {
    #  Write-Status -Message 'Moving Onedrive files from OneDrive to User Profile' -type Output
    # if (!(Test-Path "$env:USERPROFILE\OneDrive_Backup")) {
    #    New-Item "$env:USERPROFILE\OneDrive_Backup" -ItemType Directory -Force | Out-Null
    #  }
    #   robocopy "$OneDrivePath" "$env:USERPROFILE" /move /e /xj 
    # }

    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$env:localappdata\Microsoft\OneDrive"
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$env:programdata\Microsoft OneDrive"
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "$env:systemdrive\OneDriveTemp"
   
    if ($OneDrivePath) {
      Write-Status -Message "OneDrive Folder Found at [$OneDrivePath]" -type Output
      Write-Status -Message 'Make Sure there is No Files or Folders Here That You Want' -type Warning
    }

    New-PSDrive -PSProvider 'Registry' -Root 'HKEY_CLASSES_ROOT' -Name 'HKCR'
    mkdir -Force 'HKCR:\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}'
    Set-ItemProperty -Path 'HKCR:\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}' 'System.IsPinnedToNameSpaceTree' 0
    mkdir -Force 'HKCR:\Wow6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}'
    Set-ItemProperty -Path 'HKCR:\Wow6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}' 'System.IsPinnedToNameSpaceTree' 0
    Remove-PSDrive 'HKCR'

    # Thank you Matthew Israelsson
    reg load 'hku\Default' 'C:\Users\Default\NTUSER.DAT'
    reg delete 'HKEY_USERS\Default\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' /v 'OneDriveSetup' /f
    reg unload 'hku\Default'
    Remove-Item -Force -ErrorAction SilentlyContinue "$env:userprofile\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.exe"

    if ($OneDrivePath) {
      Write-Status -Message 'Fixing Shell Folder Links...' -Type Output
      #fix shell folder links
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'AppData' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Cache' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Local\Microsoft\Windows\INetCache' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Cookies' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Local\Microsoft\Windows\INetCookies' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Desktop' /t REG_EXPAND_SZ /d '%USERPROFILE%\Desktop' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Favorites' /t REG_EXPAND_SZ /d '%USERPROFILE%\Favorites' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'History' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Local\Microsoft\Windows\History' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Local AppData' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Local' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'My Music' /t REG_EXPAND_SZ /d '%USERPROFILE%\Music' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'My Pictures' /t REG_EXPAND_SZ /d '%USERPROFILE%\Pictures' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'My Video' /t REG_EXPAND_SZ /d '%USERPROFILE%\Videos' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'NetHood' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Network Shortcuts' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Personal' /t REG_EXPAND_SZ /d '%USERPROFILE%\Documents' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'PrintHood' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Printer Shortcuts' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Programs' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Recent' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Recent' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'SendTo' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming\Microsoft\Windows\SendTo' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Start Menu' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Startup' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v 'Templates' /t REG_EXPAND_SZ /d '%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Templates' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' /v '{374DE290-123F-4565-9164-39C4925E467B}' /t REG_EXPAND_SZ /d '%USERPROFILE%\Downloads' /f
      
      Write-Status -Message "Attempting to move files from [$OneDrivePath] to [$env:USERPROFILE]" -Type Output
      Get-ChildItem -Path $OneDrivePath | Move-Item -Destination $env:USERPROFILE -Force -ErrorAction SilentlyContinue
    }
    

    Restart-Explorer 


    ## Teams Removal - Source: https://github.com/asheroto/UninstallTeams
    function getUninstallString($match) {
      return (Get-ChildItem -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall, HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall | Get-ItemProperty | Where-Object { $_.DisplayName -like "*$match*" }).UninstallString
    }
            
    $TeamsPath = [System.IO.Path]::Combine($env:LOCALAPPDATA, 'Microsoft', 'Teams')
    $TeamsUpdateExePath = [System.IO.Path]::Combine($TeamsPath, 'Update.exe')
            
    Stop-Process -Name '*teams*' -Force -ErrorAction SilentlyContinue
        
    if ([System.IO.File]::Exists($TeamsUpdateExePath)) {
      # Uninstall app
      $proc = Start-Process $TeamsUpdateExePath '-uninstall -s' -PassThru
      $proc.WaitForExit()
    }
        
    Get-AppxPackage '*Teams*' | Remove-AppxPackage -ErrorAction SilentlyContinue
    Get-AppxPackage '*Teams*' -AllUsers | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue
        
    if ([System.IO.Directory]::Exists($TeamsPath)) {
      Remove-Item $TeamsPath -Force -Recurse -ErrorAction SilentlyContinue
    }
        
    # Uninstall from Uninstall registry key UninstallString
    $us = getUninstallString('Teams');
    if ($us.Length -gt 0) {
      $us = ($us.Replace('/I', '/uninstall ') + ' /quiet').Replace('  ', ' ')
      $FilePath = ($us.Substring(0, $us.IndexOf('.exe') + 4).Trim())
      $ProcessArgs = ($us.Substring($us.IndexOf('.exe') + 5).Trim().replace('  ', ' '))
      $proc = Start-Process -FilePath $FilePath -Args $ProcessArgs -PassThru
      $proc.WaitForExit()
    }
  }

  
  function get-dismPackages {
    $packagesToRemove = @(
      'Microsoft-Windows-QuickAssist-Package*' 
      'Microsoft-Windows-Hello-Face-Package*'
      'Microsoft-Windows-StepsRecorder-Package*'
      'Microsoft-Windows-TabletPCMath*' 
      'Microsoft-Windows-Wallpaper-Content-Extended*'
      'Microsoft-OneCore-ApplicationModel-Sync-Desktop*'
      'Microsoft-Windows-MediaPlayer*'
    )
    $packages = Get-WindowsPackage -Online
    $foundPackages = @()
    foreach ($package in $packages) {
      $match = $packagesToRemove | Where-Object { $package.PackageName -like $_ -and $package.PackageName -notlike '*wow64*' -and $package.PackageState -eq 'Installed' }
      if ($match) {
        $foundPackages += $package
      }
    }
    
    return $foundPackages
  }


  function get-dismCapability {
    $capabilitesToRemove = @(
      'Accessibility.Braille~~~~*'
      'App.StepsRecorder~~~~*'
      'App.Support.QuickAssist~~~~*'
      'Hello.Face.20134~~~~*'
      'Hello.Face.18967~~~~*'
      'AzureArcSetup~~~~*'
      'MathRecognizer~~~~*'
      'Microsoft.Wallpapers.Extended~~~~*'
      'OneCoreUAP.OneSync~~~~*'
      'Print.Fax.Scan~~~~*'
      'Print.Management.Console~~~~*'
      'XPS.Viewer~~~~*'
      'Media.WindowsMediaPlayer~~~~*'
    )
    $capabilites = get-windowscapability -online 
    $foundCapabilities = @()
    foreach ($capability in $capabilites) {
      $match = $capabilitesToRemove | Where-Object { $capability.Name -like $_ -and $capability.State -eq 'Installed' }
      if ($match) {
        $foundCapabilities += $capability
      }
    }

    return $foundCapabilities

  }

  function get-dismFeatures {
    $featuresToRemove = @(
      'Printing-XPSServices-Features'
      'WorkFolders-Client'
      'MediaPlayback'
      'WindowsMediaPlayer'
      'Microsoft-RemoteDesktopConnection'
      'Recall'
      'Printing-PrintToPDFServices-Features'
      'Printing-Foundation-Features'
      'Printing-Foundation-InternetPrinting-Client'
      'Printing-Foundation-LPDPrintService'
      'Printing-Foundation-LPRPortMonitor'
      'Windows-Defender-Default-Definitions'
    )
    $features = Get-WindowsOptionalFeature -Online
    $foundFeatures = @()
    foreach ($feature in $features) {
      $match = $featuresToRemove | Where-Object { $feature.FeatureName -eq $_ -and $feature.State -eq 'Enabled' }
      if ($match) {
        $foundFeatures += $feature
      }
    }
    return $foundFeatures

  }

  function debloat-HealthUpdateTools {
    #uninstall health update tools and installed updates
    $apps = Get-InstalledSoftware  
    foreach ($app in $apps) {
      if ($app.DisplayName -like '*Update for Windows*' -or $app.DisplayName -like '*Microsoft Update Health Tools*') {
        Uninstall-ApplicationViaUninstallString $app.DisplayName
      }
    }

    #clean up others to be sure
    reg delete 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\UpdateHealthTools' /f *>$null
    reg delete 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\rempl' /f *>$null
    reg delete 'HKLM\SOFTWARE\Microsoft\CloudManagedUpdate' /f *>$null
    Remove-Item "$env:ProgramW6432\Microsoft Update Health Tools" -Force -ErrorAction SilentlyContinue

    msiexec /X '{804A0628-543B-4984-896C-F58BF6A54832}' /qn /norestart >$null
    Remove-Item "$env:ProgramW6432\PCHealthCheck" -Force -ErrorAction SilentlyContinue >$null 
    try {
      &"$env:ProgramW6432\WindowsInstallationAssistant\Windows10UpgraderApp.exe" /SunValley /ForceUninstall >$null
    }
    catch {
      #hide error
    }
    Remove-Item "$env:ProgramW6432\WindowsInstallationAssistant" -Force -ErrorAction SilentlyContinue >$null
  }

  function debloat-remotedesktop {
    #uninstall remote desktop connection
    
    try {
      #get uninstall string 
      $uninstallstr = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\mstsc*' -Name 'UninstallString').UninstallString
      $path, $arg = $uninstallstr -split ' '
      Start-Process -FilePath $path -ArgumentList $arg
      Start-Sleep 1
      $running = $true
      #create stopwatch for 10 secs incase of do while getting stuck
      $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
      do {
        $openWindows = Get-Process | Where-Object { $_.MainWindowTitle -ne '' } | Select-Object MainWindowTitle
        foreach ($window in $openWindows) {
          if ($window.MainWindowTitle -eq 'Remote Desktop Connection') {
            Stop-Process -Name 'mstsc' -Force
            $running = $false
          }
        }

        if ($stopwatch.Elapsed.TotalSeconds -ge 10) {
          $running = $false
        }
      }while ($running)

      $stopwatch.Stop()
    }
    catch {
      #remote desktop not found
      Write-Status -Message 'Remote Desktop Not Found' -Type Error
    }
    
    
    
  }


  function debloat-dismPackage {
    param(
      [string]$packageName
    )
    $ProgressPreference = 'SilentlyContinue'
   
    #erroraction silently continue doesnt work since error comes from dism
    #using catch block to ignore error
    Write-Status -Message "Removing Package $packageName..." -Type Output
    try {
      Remove-WindowsPackage -Online -PackageName $package -NoRestart -ErrorAction Stop *>$null
    }
    catch {
      #error from outdated package version
      #do nothing
    }
       

  }

  function debloat-dismCapability {
    param (
      [string]$capabilityName
    )
    Write-Status -Message "Removing Capability $capabilityName..." -Type Output
    $ProgressPreference = 'SilentlyContinue'
    try {
      Remove-WindowsCapability -Online -Name $capabilityName -ErrorAction Stop *>$null
    }
    catch {
      #ignore error
    }
    

  }

  function debloat-dismFeatures {
    param(
      [string]$featureName
    )
    $ProgressPreference = 'SilentlyContinue'
    Write-Status -Message "Removing Feature $featureName..." -Type Output
    try {
      Disable-WindowsOptionalFeature -Online -FeatureName $featureName -Remove -NoRestart -ErrorAction Stop *>$null
    }
    catch {
      #ignore error
    }
    

  }

  function debloat-Win32Apps {
    param(
      [ValidateSet('speech', 'livecaptions', 'magnifier', 'Narrator', 'osk', 'voiceaccess', 'stepsrecorder', 'QuickAssist', 'MathInput')]
      [string]$appName
    )

    $startMenu = "$env:appdata\Microsoft\Windows\Start Menu\Programs\Accessibility"
    $startMenu2 = "$env:PROGRAMDATA\Microsoft\Windows\Start Menu\Programs\Accessories"
    $startMenu3 = "$env:PROGRAMDATA\Microsoft\Windows\Start Menu\Programs\Accessibility"
    switch ($appName) {
      'speech' { 
        Write-Status -Message 'Removing Speech App...' -Type Output
        $command = 'Remove-item -path C:\Windows\System32\Speech -recurse -force; Remove-item -path C:\Windows\Speech\Common -recurse -force'
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startmenu3\Speech Recognition.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
      'livecaptions' {
        Write-Status -Message 'Removing Live Captions...' -Type Output
        $command = "Remove-item -path $env:windir\System32\LiveCaptions.exe -force"
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startMenu\LiveCaptions.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
      'magnifier' {
        Write-Status -Message 'Removing Magnifier...' -Type Output
        $command = "Remove-item -path $env:windir\System32\magnify.exe -force"
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startMenu\Magnify.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
      'Narrator' {
        Write-Status -Message 'Removing Narrator...' -Type Output
        $command = "Remove-item -path $env:windir\System32\narrator.exe -force"
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startMenu\Narrator.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
      'osk' {
        Write-Status -Message 'Removing On Screen Keyboard...' -Type Output
        $command = "Remove-item -path $env:windir\System32\osk.exe -force; Remove-item -path `"$env:programfiles\Common Files\Microsoft Shared\ink`" -force -recurse"
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startMenu\On-Screen Keyboard.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
      'voiceaccess' {
        Write-Status -Message 'Removing Voice Access...' -Type Output
        $command = "Remove-item -path $env:windir\System32\voiceaccess.exe -force"
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startMenu\VoiceAccess.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
      'stepsrecorder' {
        Write-Status -Message 'Removing Steps Recorder...' -Type Output
        $command = "Remove-item -path $env:windir\System32\psr.exe -force"
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startMenu2\Steps Recorder.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
      'QuickAssist' {
        Write-Status -Message 'Removing Quick Assist...' -Type Output
        $command = "Remove-item -path $env:windir\System32\quickassist.exe -force"
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startMenu2\Quick Assist.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
      'MathInput' {
        Write-Status -Message 'Removing Math Input Panel...' -Type Output
        $command = "Remove-item -path `"$env:programfiles\Common Files\Microsoft Shared\ink`" -force -recurse" 
        Run-Trusted -command $command
        Start-Sleep 1
        Remove-Item "$startMenu2\Math Input Panel.lnk" -Force -ErrorAction SilentlyContinue
        break
      }
    }
  }
  
  function debloatPreset {
    param (
      [string]$choice,
      [array]$excludedPackages
    )

    function debloatAppx {

      param (
        [string]$Bloat
      )
      #silentlycontinue doesnt work sometimes so trycatch block is needed to supress errors
      try {
        Get-AppXPackage "*$Bloat*" -AllUsers -ErrorAction Stop | ForEach-Object { Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ErrorAction SilentlyContinue; Remove-AppxPackage -Package $_.PackageFullName -AllUsers -ErrorAction Stop } | Out-Null
      }
      catch {}
      try {
        Get-AppxProvisionedPackage -Online | Where-Object DisplayName -like "*$Bloat*" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction Stop | Out-Null
      }
      catch {}  
    }




    $packages = Get-AppxPackage -AllUsers | Where-Object { $excludedPackages -notcontains $_.Name }
    #remove dups
    $Bloatware = $packages | Sort-Object -Property Name | Get-Unique
    $ProgressPreference = 'SilentlyContinue'

    switch ($choice) {
      'debloatAll' {
        foreach ($Bloat in $Bloatware) {
          #using where-obj for wildcards to work
          $isProhibited = $prohibitedPackages | Where-Object { $Bloat.Name -like $_ }
          #skip locked packages to save time
          if ($Bloat.NonRemovable -eq $false -and !$isProhibited) {
            #dont remove nvcp, photos, notepad(11) and paint on 11 (win10 paint is "MSPaint")
            #using -like because microsoft like to randomly change package names
            if (!($Bloat.Name -like '*NVIDIA*' -or $Bloat.Name -like '*Photos*' -or $Bloat.Name -eq 'Microsoft.Paint' -or $Bloat.Name -like '*Notepad*' -or $Bloat.Name -like '*WindowsTerminal*')) { 
              Write-Status -Message "Trying to remove $($Bloat.Name)" -Type Output
              debloatAppx -Bloat $Bloat.Name
            }          
          }

        }
      }
      'debloatKeepStore' {
        foreach ($Bloat in $Bloatware) {
          #using where-obj for wildcards to work
          $isProhibited = $prohibitedPackages | Where-Object { $Bloat.Name -like $_ }
          #skip locked packages to save time
          if ($Bloat.NonRemovable -eq $false -and !$isProhibited) {
            #dont remove nvcp, photos or paint on 11 (win10 paint is "MSPaint")
            #dont remove store
            if (!($Bloat.Name -like '*NVIDIA*' -or $Bloat.Name -like '*Photos*' -or $Bloat.Name -eq 'Microsoft.Paint' -or $Bloat.Name -like '*Store*' -or $Bloat.Name -like '*Notepad*' -or $Bloat.Name -like '*WindowsTerminal*')) { 
              Write-Status -Message "Trying to remove $($Bloat.Name)" -Type Output
              debloatAppx -Bloat $Bloat.Name
            }          
          }

        }
      }
      'debloatKeepStoreXbox' {
        foreach ($Bloat in $Bloatware) {
          #using where-obj for wildcards to work
          $isProhibited = $prohibitedPackages | Where-Object { $Bloat.Name -like $_ }
          #skip locked packages to save time
          if ($Bloat.NonRemovable -eq $false -and !$isProhibited) {
            #dont remove nvcp, photos or paint on 11 (win10 paint is "MSPaint")
            #dont remove store and xbox
            if (!($Bloat.Name -like '*NVIDIA*' -or $Bloat.Name -like '*Photos*' -or $Bloat.Name -eq 'Microsoft.Paint' -or $Bloat.Name -like '*Store*' -or $Bloat.Name -like '*Xbox*' -or $Bloat.Name -like '*Gaming*' -or $Bloat.Name -like '*Notepad*' -or $Bloat.Name -like '*WindowsTerminal*')) { 
              Write-Status -Message "Trying to remove $($Bloat.Name)" -Type Output
              debloatAppx -Bloat $Bloat.Name
            }          
          }

        }
      }
    }


  }

  function Get-InstalledApps {
    #gets installed apps from registry using the well known "uninstall" location (appwiz.cpl apps)
    #gets additional apps from lesser known location (dups are removed)
    param(
      [switch]$ThirdPartyOnly,
      [switch]$AllApps #show apps even if they are marked as a system component

    )


    $regPath64 = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'

    $regPath32 = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

    $apps64 = Get-ChildItem $regPath64 
    $apps32 = Get-ChildItem $regPath32


    $installedApps = @()

    foreach ($app64 in $apps64) {

      $values = Get-ItemProperty $app64.PSPath 

      $obj = [pscustomobject]@{
        RegPath              = $app64.Name
        DisplayName          = $values.DisplayName
        InstallLocation      = $values.InstallLocation
        InstallSource        = $values.InstallSource
        Publisher            = $values.Publisher
        UninstallString      = $values.UninstallString
        QuietUninstallString = $values.QuietUninstallString
        DisplayIcon          = $values.DisplayIcon
        SystemComponent      = $values.SystemComponent
      }

      $installedApps += $obj

    }



    foreach ($app32 in $apps32) {

      $values = Get-ItemProperty $app32.PSPath 

      $obj = [pscustomobject]@{
        RegPath              = $app32.Name
        DisplayName          = $values.DisplayName
        InstallLocation      = $values.InstallLocation
        InstallSource        = $values.InstallSource
        Publisher            = $values.Publisher
        UninstallString      = $values.UninstallString
        QuietUninstallString = $values.QuietUninstallString
        DisplayIcon          = $values.DisplayIcon
        SystemComponent      = $values.SystemComponent
      }

      $installedApps += $obj

    }

    #another location
    $regPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData'

    $users = Get-ChildItem $regPath -ErrorAction SilentlyContinue
    if ($users) {
      foreach ($user in $users) {
        $hives = Get-ChildItem "$($user.PSPath)\Products" 

        foreach ($hive in $hives) {
          try {

            $props = Get-ItemProperty "$($hive.PSPath)\InstallProperties" -ErrorAction Stop
            $obj = [pscustomobject]@{
              DisplayName     = $props.DisplayName
              InstallLocation = $props.InstallLocation
              InstallSource   = $props.InstallSource
              UninstallString = $props.UninstallString
              Publisher       = $props.Publisher
              SystemComponent = $props.SystemComponent
            }

            $installedApps += $obj

          }
          catch {}
  

        }

      }
    }

    #some apps dont make a uninstall key so we need to find the missing installed apps using get-package
    $additionalApps = @()
    $programs = get-package -ProviderName Programs
    foreach ($program in $programs) {
      $appObj = [PSCustomObject]@{
        DisplayName          = $null
        DisplayIcon          = $null
        UninstallString      = $null
        Publisher            = $null
        InstallSource        = $null
        InstallLocation      = $null
        QuietUninstallString = $null
      }

      $names = $program.meta.attributes.keys.localname
      #get the index of the names inorder to index into the "values" array
      $i = 0
      $foundIndexIcon = $null
      $foundIndexName = $null
      $foundIndexUninstall = $null
      $foundIndexPublisher = $null
      $foundIndexSource = $null
      $foundIndexLocation = $null
      $foundIndexQuietUninstall = $null
      foreach ($name in $names) {
        if ($name -eq 'DisplayIcon') {
          $foundIndexIcon = $i
        }
        elseif ($name -eq 'UninstallString') {
          $foundIndexUninstall = $i
        }
        elseif ($name -eq 'DisplayName') {
          $foundIndexname = $i
        }
        elseif ($name -eq 'Publisher') {
          $foundIndexPublisher = $i
        }
        elseif ($name -eq 'InstallSource') {
          $foundIndexSource = $i
        }
        elseif ($name -eq 'InstallLocation') {
          $foundIndexLocation = $i
        }
        elseif ($name -eq 'QuietUninstallString') {
          $foundIndexQuietUninstall = $i
        }
        $i++
            
      }
      if ($foundIndexIcon -ne $null) {
        $appObj.DisplayIcon = $program.meta.attributes.values[$foundIndexIcon]
      }

      if ($foundIndexName -ne $null) {
        $appObj.DisplayName = $program.meta.attributes.values[$foundIndexname]
      }

      if ($foundIndexUninstall -ne $null) {
        $appObj.UninstallString = $program.meta.attributes.values[$foundIndexUninstall]
      }

      if ($foundIndexPublisher -ne $null) {
        $appObj.Publisher = $program.meta.attributes.values[$foundIndexPublisher]
      }

      if ($foundIndexSource -ne $null) {
        $appObj.InstallSource = $program.meta.attributes.values[$foundIndexSource]
      }

      if ($foundIndexLocation -ne $null) {
        $appObj.InstallLocation = $program.meta.attributes.values[$foundIndexLocation]
      }

      if ($foundIndexQuietUninstall -ne $null) {
        $appObj.QuietUninstallString = $program.meta.attributes.values[$foundIndexQuietUninstall]
      }


      $additionalApps += $appobj
    }
    
    #add the apps that install themselves to appdata and dont make a reg entry
    
    foreach ($app in $additionalApps) {
      if (!($app.UninstallString -in @($installedApps.UninstallString))) {
        $installedApps += $app
      }
    }
  
      

    if ($ThirdPartyOnly) {
      $installedApps = $installedApps | Where-Object { $_.Publisher -ne 'Microsoft Corporation' -and $_.Publisher -ne $null }
    }

    if (!($AllApps)) {
      $installedApps = $installedApps | Where-Object { $_.SystemComponent -ne 1 }
    }

    #filter out empty apps
    $installedApps = $installedApps | Where-Object { $_.DisplayName -ne $null }

    #filter out duplicates
    $installedApps = $installedApps | Group-Object -Property UninstallString | ForEach-Object { $_.Group | Select-Object -First 1 }

    return $installedApps


  }







  function Get-UninstallString {
    #create uninstall obj with silent msi args or silent uninstall string if it exists
    param($app)

    $uninstallString = $app.UninstallString
    $uninstallStringQ = $app.QuietUninstallString

    $obj = [pscustomobject]@{
      UninstallString = $null
      MsiExe          = $null
      Silent          = $null
    }

    if ($uninstallString -like 'MsiExec.exe*') {
      $silentUninstall = ($uninstallString -replace '/I' , '/X') + ' /qn'
      $obj.UninstallString = $silentUninstall
      $obj.MsiExe = $true
      $obj.Silent = $true
      return $obj
    }
    else {

      if ($uninstallStringQ) {
        $obj.MsiExe = $false
        $obj.Silent = $true
        $obj.UninstallString = $uninstallStringQ
        return $obj
      }
      else {
        $obj.MsiExe = $false
        $obj.Silent = $false
        $obj.UninstallString = $uninstallString
        return $obj
      }

    }



  }





  function Run-Uninstallers {
    #pass uninstall string obj
    param($uninstallString)

    if ($uninstallString.MsiExe) {
      $arguments = ($uninstallString.UninstallString -replace 'MsiExec.exe', '').Trim()
      #Write-Host "msiexe: args: $arguments"
      Start-Process MsiExec.exe -ArgumentList $arguments -Wait #wait for now might be able to uninstall multiple at once
    }
    else {

      #split path and args when path is surrounded by " or '
      $match = ([regex]'("[^"]+")(.*)').Matches($uninstallString.UninstallString)
      if (!$match.count) {
        #check for single quote if not "
        $match = ([regex]"('[^']+')(.*)").Matches($uninstallString.UninstallString)
      }
      if ($match.count) {
        $uninstallPath = ($match.captures.groups[1].value).Trim()
        $uninstallArgs = ($match.captures.groups[2].value).Trim()
      }
      else {

        #some will not have any " or ' 
        #some will be just a path with no args
        #might be a cleaner way to do this but the uninstall string is unpredictable

        #check if uninstall string is just a path
        if (Test-Path $uninstallString.UninstallString -ErrorAction Ignore) {
          $uninstallPath = $uninstallString.UninstallString
          $uninstallArgs = $null
        }
        else {
          #path has args could be - or /
          #split the string on first arg char since splitting on the space could potentially split the path instead
          if ($uninstallString.UninstallString -like '*-*') {
            $uninstallPath, $uninstallArgs = $uninstallString.UninstallString -split '-' , 2
            #add the arg char back
            $uninstallArgs = "-$uninstallArgs"
          }
          elseif ($uninstallString.UninstallString -like '*/*') {
            $uninstallPath, $uninstallArgs = $uninstallString.UninstallString -split '/' , 2
            #add the arg char back
            $uninstallArgs = "/$uninstallArgs"
          }

        }

      }

           

      #test path incase uninstall exe has been removed but still exists in registry
      $rawPath = $uninstallPath -replace '"', '' -replace "'" , ''
      if (Test-Path $rawPath) {
            
        if ($uninstallArgs) {
          #Write-Host "$uninstallPath + $uninstallArgs"
          $proc = Start-Process $uninstallPath -ArgumentList $uninstallArgs -PassThru | Get-Process
          #wait 1 min for uninstall process and then kill if it hasnt already
          Write-Status -Message 'Waiting For Uninstall Process 1 Minute [MAX]...' -Type Output
          $timer = 0
          while ((Get-Process $proc.Name -ErrorAction SilentlyContinue) -and $timer -le 60) {
            Start-Sleep 1
            $timer++
          }
          if ($timer -ge 60) {
            Stop-Process $proc -Force
          }
        }
        else {
          #Write-Host "$uninstallPath"
          $proc = Start-Process $uninstallPath -PassThru | Get-Process
          #wait 1 min for uninstall process and then kill if it hasnt already
          Write-Status -Message 'Waiting For Uninstall Process 1 Minute [MAX]...' -Type Output
          $timer = 0
          while ((Get-Process $proc.Name -ErrorAction SilentlyContinue) -and $timer -le 60) {
            Start-Sleep 1
            $timer++
          }
          if ($timer -ge 60) {
            Stop-Process $proc -Force
          }
        }
            
      }

    }


  }




  #-----------------------------------------------------------------------


  #helper function to delete folders and files
  function Remove-ItemForce {
    param($path)

    $isDir = $false
    if (Test-Path "$path" -PathType Container) {
      $isDir = $true
    }

    try {
      if ($isDir) {
        Remove-Item "$path" -Force -Recurse -ErrorAction Stop
      }
      else {
        Remove-Item "$path" -Force -ErrorAction Stop
      } 
    }
    catch {
      #need to takeown since admin priv failed
      if ($isDir) {
        takeown /f "$path" /r /d Y *>$null
        icacls "$path" /grant *S-1-5-32-544:F /t *>$null
        Remove-Item "$path" -Force -Recurse -ErrorAction SilentlyContinue
      }
      else {
        takeown /f "$path" *>$null
        icacls "$path" /grant *S-1-5-32-544:F /t *>$null
        Remove-Item "$path" -Force -ErrorAction SilentlyContinue
      }
        
    }
    #try with trusted installer
    if (Test-Path "$path" -ErrorAction Ignore) {
      $command = "Remove-Item '$path' -Force -Recurse"
      Run-Trusted -command $command
      Start-Sleep 1
    }

    if (Test-Path "$path" -ErrorAction Ignore) {
      Write-Status -Message "Unable to Remove $path" -Type Output
      #create task to run on next restart to attempt to cleanup file(s)
      Write-Status -Message 'Creating Task to Remove On Next Reboot...' -Type Output
      $regLocation = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
      $script = "$tempDir\fileRemoval.ps1"
      $removalCode = "Remove-Item `"$path`" -Force -Recurse"
  
      if (!(Test-Path $script)) {
        New-Item $script -Force | Out-Null
      }
        
      Add-Content $script -Value $removalCode -Force 
      $arguments = "-win 1 -ep bypass -c `"& `"$script`"; remove-item `"$script`"`""  
      Set-ItemProperty $regLocation -Name 'NextRun' -Value "Powershell.exe $arguments" -Force

    }
    else {
      Write-Status -Message "Removed $path Successfully" -Type Output
    }
  }



  # cleanup leftover files by searching common directories


  function Get-InstallDirs {
    #pass app object from get-installedsoftware to check the Install location props
    param(
      $app,
      [switch]$QuickClean
    )


    #dirs that could contain leftover temp files 
    $installDirsCache = @(
      "$env:USERPROFILE\Desktop",
      "$env:USERPROFILE\Documents",
      "$env:USERPROFILE\Downloads"
      "$env:ProgramData\Microsoft\Windows\Start Menu\Programs",
      "$env:APPDATA\Microsoft\Windows\Start Menu\Programs",
      "$tempDir",
      "$env:SystemRoot\Temp",
      "$env:SystemRoot\Prefetch",
      [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonDesktopDirectory),
      [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonDocuments)

    )

    #less specfic locations takes more time to search but less opportunity for missed files
    $installDirsBroad = @(
      $env:ProgramData,
      $env:ProgramFiles,
      ${env:ProgramFiles(x86)},
      $env:APPDATA, #roaming
      $env:LOCALAPPDATA   
    )

    $filter = '*' + ($app.DisplayName -split ' ')[0] + '*'
    #if the filter is just microsoft it will be too vauge
    if ($filter -eq '*Microsoft*') {
      #get the next two words after microsoft
      $filter = '*' + ($app.DisplayName -split ' ', 4)[1..2] + '*'
    }

    $foundDirs = @()

    #Write-Host "Filter for finding leftover files: $filter"
       
    if ($QuickClean) {
      #only search temp file dirs
      $foundDirs = ($installDirsCache | ForEach-Object { Get-ChildItem -Path $_ -Filter $filter -Recurse -ErrorAction SilentlyContinue }).FullName
        
    }
    else {
      #full cleanup
      #search temp dirs and install dirs
      $foundDirs = ($installDirsCache | ForEach-Object { Get-ChildItem -Path $_ -Filter $filter -Recurse -ErrorAction SilentlyContinue }).FullName
      $foundDirs += ($installDirsBroad | ForEach-Object { Get-ChildItem -Path $_ -Filter $filter -Recurse -ErrorAction SilentlyContinue }).FullName
      #match additional folders
      $folders = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\Folders' -ErrorAction SilentlyContinue
      if ($folders) {
        $members = $folders | Get-Member | Select-Object -Property Name
        $validFolders = @()
        foreach ($member in $members) {
          if (Test-Path $member.Name) {
            $validFolders += $member.Name
          }
     
        }
  
        foreach ($folder in $validFolders) {
          if ($folder -like $filter) {
            $foundDirs += $folder
          }
        }
      }
    }
      

    try {
      if (Test-Path $app.InstallSource -ErrorAction Ignore) {
        $foundDirs += $app.InstallSource
      }
    }
    catch {}

    try {
      if (Test-Path $app.InstallLocation -ErrorAction Ignore) {
        $foundDirs += $app.InstallLocation
      }
    }
    catch {}
   

   

    return $foundDirs 

  }





  function Get-RegLocation {
    #removes the hkcu and hklm \ software entry for the app as this could contain app settings
    param($app)

    $locations = @(
      'HKCU:\Software',
      'HKLM:\SOFTWARE'
    )

    $name = ($app.DisplayName -split ' ')[0]
    #if the filter is just microsoft it will be too vauge
    if ($name -eq 'Microsoft') {
      #get the next two words after microsoft
      $name = ($app.DisplayName -split ' ', 4)[1..2] -join ''
      $locations = @(
        'HKCU:\Software\Microsoft',
        'HKLM:\SOFTWARE\Microsoft'
      )
    }
   
    #Write-Host "registry search name: $name"

    $foundPaths = ($locations | ForEach-Object { Get-ChildItem $_ } | Where-Object { $_.Name -like "*$name*" }).PSPath

    return $foundPaths

  }

  function Display-LeftOvers {
    param (
      $filePaths,
      $regPaths
    )
    
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    # Create the form
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Select Items to Remove'
    $form.Size = New-Object System.Drawing.Size(700, 400)
    $form.StartPosition = 'CenterScreen'

    $type = $form.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($form, $true, $null)

    $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
    $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

    # Override the form's paint event to apply the gradient
    $form.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $form.Width, $form.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    # Create DataGridView
    $dataGridView = New-Object System.Windows.Forms.DataGridView
    $dataGridView.Location = New-Object System.Drawing.Point(10, 10)
    $dataGridView.Size = New-Object System.Drawing.Size(660, 300)
    $dataGridView.BackgroundColor = [System.Drawing.Color]::Black
    $dataGridView.ForeColor = 'White'
    $dataGridView.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = 'White'
    $dataGridView.DefaultCellStyle.BackColor = [System.Drawing.Color]::Black
    $dataGridView.DefaultCellStyle.ForeColor = 'White'
    $dataGridView.RowHeadersVisible = $false
    $dataGridView.AllowUserToAddRows = $false
    $dataGridView.ReadOnly = $false
    $dataGridView.SelectionMode = 'FullRowSelect'
    $dataGridView.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
    $dataGridView.Columns.Clear()

    # Define columns
    $checkboxColumn = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
    $checkboxColumn.Name = 'Select'
    $checkboxColumn.HeaderText = 'Select'
    $checkboxColumn.Width = 50
    $dataGridView.Columns.Add($checkboxColumn) | Out-Null

    $dataGridView.Columns.Add('Path', 'Path') | Out-Null
    $dataGridView.Columns.Add('Type', 'Type') | Out-Null
    $dataGridView.Columns['Type'].Width = 50
    $dataGridView.Columns['Path'].Width = 540
    $dataGridView.Columns['Type'].ReadOnly = $true
    $dataGridView.Columns['Path'].ReadOnly = $true

    # Create OK button
    $okButton = Create-ModernButton -Text 'OK' -Location (New-Object Drawing.Point(500, 320)) -Size (New-Object Drawing.Size(75, 30)) -borderSize 2 -DialogResult ([System.Windows.Forms.DialogResult]::OK)
   

    # Create Cancel button
    $cancelButton = Create-ModernButton -Text 'Cancel' -Location (New-Object Drawing.Point(585, 320)) -Size (New-Object Drawing.Size(75, 30)) -borderSize 2 -DialogResult ([System.Windows.Forms.DialogResult]::Cancel)

    $checkAllCheckbox = New-Object System.Windows.Forms.CheckBox
    $checkAllCheckbox.Location = New-Object System.Drawing.Point(10, 315)
    $checkAllCheckbox.Size = New-Object System.Drawing.Size(100, 20)
    $checkAllCheckbox.Text = 'Check All'
    $checkAllCheckbox.ForeColor = 'White'
    $checkAllCheckbox.BackColor = [System.Drawing.Color]::Transparent
    $checkAllCheckbox.Add_CheckedChanged({
        $dataGridView.EndEdit() # Ensure any pending edits are applied
        foreach ($row in $dataGridView.Rows) {
          $row.Cells['Select'].Value = $checkAllCheckbox.Checked
        }
        $dataGridView.Refresh()
      })
    $form.Controls.Add($checkAllCheckbox)

    # Add controls to form
    $form.Controls.Add($dataGridView)
    $form.Controls.Add($okButton)
    $form.Controls.Add($cancelButton)

    # Populate DataGridView
    $dataGridView.Rows.Clear()
    
    foreach ($path in $filePaths) {
      # Determine if it's a file or folder
      $type = if (Test-Path -Path $path -PathType Leaf) { 'File' } else { 'Folder' }
      $dataGridView.Rows.Add($false, $path, $type)
    }
    
    foreach ($regKey in $regPaths) {
      $dataGridView.Rows.Add($false, $regKey, 'Registry')
    }

    # Show the form and return selected items
    $result = $form.ShowDialog()
    
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
      $selectedItems = New-Object System.Collections.ArrayList
      foreach ($row in $dataGridView.Rows) {
        if ($row.Cells['Select'].Value -eq $true) {
          $path = [string]$row.Cells['Path'].Value
          $selectedItems.Add($path) | Out-Null
        }
      }
      return $selectedItems.ToArray()
      # $selectedItems = $dataGridView.Rows | Where-Object { $_.Cells['Select'].Value -eq $true } | ForEach-Object { $_.Cells['Path'].Value }
      # foreach ($row in $dataGridView.Rows) {
      #   if ($row.Cells['Select'].Value -eq $true) {
      #     $selectedItems += [string]$row.Cells['Path'].Value
      #   }
      # }
      #return $selectedItems
    }
    else {
      return $null
    }
    
    
  }


  function Get-AppIcon {
    param (
      $app
    )

    #gets/searches for app icon and returns the icon object


    #extracts icon from exe file if no icon use the default exe icon
    #type def from: https://gist.github.com/ThioJoe/1333742dd851a04a955a3f9e9bc1fbe5
    Add-Type -TypeDefinition @'
    using System;
    using System.Runtime.InteropServices;
    using System.Text;
    public class Shell32 {
        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr ExtractAssociatedIconExW(IntPtr hInst, StringBuilder lpIconPath, ref ushort piIconIndex, ref ushort piIconId);
    }
'@ 

    $iconPath = "$env:windir\system32\shell32.dll"
    $iconIndex = 2
    $iconId = 0
    $handle = [Shell32]::ExtractAssociatedIconExW([IntPtr]::Zero, $iconPath, [ref]$iconIndex, [ref]$iconId)
    $defaultAppIcon = [System.Drawing.Icon]::FromHandle($handle)


    #get icon from exe or msi file fallback to default app icon 
    #
    # this alg is somewhat messy but as far as i know there is no better way to get the app icon when its not included in the uninstall properties
    # TODO: prob need to dispose or [gc]::collect() the shortcut/shell object 
    #============================================================================================================ 
    function Get-IconNoPath {
      $startMenuPaths = @(
        "$env:ProgramData\Microsoft\Windows\Start Menu\Programs",
        "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"
      )
      $lnks = @()
      $dirs = @()

      #first pass search for folder using publisher or displayname
      $searchtermDir1 = $app.Publisher -replace '[^a-zA-Z\s]', '' -replace '\s+', ' '
      #Write-Host "First pass publisher: $searchtermDir1" #debug
      foreach ($path in $startMenuPaths) {
        $dirs += Get-ChildItem $path -Recurse -Directory | Where-Object { $_.Name -like "*$searchtermdir1*" } 
      }
      #dir not found try using the display name
      if ($dirs.count -eq 0) {
        #search for dir again but try display name
        $searchtermDir2 = (($app.DisplayName -replace '[^a-zA-Z\s]', '') -split ' ')[0].trim() -join ' '
        #Write-Host "Second Pass Display name: $searchtermdir2" #debug
        foreach ($path in $startMenuPaths) {
          $dirs += Get-ChildItem $path -Recurse -Directory | Where-Object { $_.Name -like "*$searchtermdir2*" } 
        }
      }

      if ($dirs.count -gt 0) {
        #search in found dirs first but they could be false positives so if nothing is found search the whole dir
        $searchterm1 = (($app.DisplayName -replace '[^a-zA-Z\s]', '' -replace '\s+', ' ') -split ' ')[0..2].trim()
        #Write-Host "dir found searching: $searchterm1" #debug
        foreach ($dir in $dirs) {
          $lnks += Get-ChildItem $dir.FullName -Recurse -File -Include '*.lnk' #| Where-Object { $_.Name -like "*$searchterm1*" } 
        }
            
        if ($lnks.count -eq 0) {
          foreach ($path in $startMenuPaths) {
            $lnks += Get-ChildItem $Path -Recurse -File -Include '*.lnk' | Where-Object { $_.Name -like "*$searchterm1*" } 
          }
        }
      }
      else {
        #dir not found just search the whole start menu dir 
        $searchterm1 = (($app.DisplayName -replace '[^a-zA-Z\s]', '' -replace '\s+', ' ') -split ' ')[0..2].trim()
        #Write-Host "dir not found: $searchterm1" #debug
        foreach ($path in $startMenuPaths) {
          $lnks += Get-ChildItem $path -Recurse -File -Include '*.lnk' | Where-Object { $_.Name -like "*$searchterm1*" } 
        }
      }

      if ($lnks) {
        $path = ($lnks | Select-Object -First 1).FullName
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($path)
        $targetPath = $shortcut.TargetPath
        $Global:imageKey = $targetPath
        $icon = [System.Drawing.Icon]::ExtractAssociatedIcon($targetPath) 
        #$imageList.Images.Add($imageKey, $icon)
        return $icon
      }
      else {
        try {
          #search install location if display icon is empty
          if (Test-Path $app.InstallSource -ErrorAction Stop) {
            $path = (Get-ChildItem $app.InstallSource -Recurse -Include '*.exe', '*.msi').FullName
            if ($path) {
              $Global:imageKey = $path
              $icon = [System.Drawing.Icon]::ExtractAssociatedIcon($path) 
              #$imageList.Images.Add($path, $icon)
              return $icon
            }
            else {
              throw #go to catch
            }
          }
          elseif (Test-Path $app.InstallLocation -ErrorAction Stop) {
            $path = (Get-ChildItem $app.InstallLocation -Recurse -Include '*.exe', '*.msi').FullName
            if ($path) {
              $Global:imageKey = $path
              $icon = [System.Drawing.Icon]::ExtractAssociatedIcon($path)
              #$imageList.Images.Add($path, $icon)
              return $icon
            }
            else {
              throw #go to catch
            }
          }
        }
        catch {
          #fallback to default icon
          $Global:imageKey = 'msiexec.exe' 
          #$imageList.Images.Add($imageKey, $defaultAppIcon)
          return $defaultAppIcon
        }
      }
    
    }

    if ($null -eq $app.DisplayIcon -or $app.DisplayIcon -eq 'msiexec.exe') {
      Get-IconNoPath
    }
    else {
       
      $fileCleaned = ($app.DisplayIcon -replace '"', '') -replace ',.*$', ''
      if (Test-Path $fileCleaned -ErrorAction Ignore) {
        $imageKey = $fileCleaned
        try {
          $icon = [System.Drawing.Icon]::ExtractAssociatedIcon($fileCleaned)
          #$imageList.Images.Add($fileCleaned, $icon)
          return $icon
        }
        catch {
          #fallback to default icon
          $imageKey = 'msiexec.exe' 
          #$imageList.Images.Add($imageKey, $defaultAppIcon)
          return $defaultAppIcon
        }
      }
      else {
        #display icon path doesnt exist
        Get-IconNoPath
      }
           
        
   
    }
   
    #============================================================================================================   
      
  }


    


  # ----------------------------------------------------------- DEBLOAT FUNCTIONS ---------------------------------------------------



  $comboBoxPresets = New-Object System.Windows.Forms.ComboBox
  $comboBoxPresets.Items.AddRange(@(
      'Debloat All',
      'Keep Store, Xbox and Edge',
      'Keep Store and Xbox',
      'Debloat All Keep Edge',
      'Debloat All Keep Store'
    ))

  #hashtable to loop through later for updating the config
  $settings = @{}
  $settings['debloatAll'] = 'Debloat All'
  $settings['debloatSXE'] = 'Keep Store, Xbox and Edge'
  $settings['debloatSX'] = 'Keep Store and Xbox'
  $settings['debloatE'] = 'Debloat All Keep Edge'
  $settings['debloatS'] = 'Debloat All Keep Store'

  <#
  $Global:lockedAppxPackages = @(
    'Microsoft.Windows.NarratorQuickStart' 
    'Microsoft.Windows.ParentalControls'
    'Microsoft.Windows.PeopleExperienceHost'
    'Microsoft.ECApp'
    'Microsoft.LockApp'
    'NcsiUwpApp'
    'Microsoft.XboxGameCallableUI'
    'Microsoft.Windows.XGpuEjectDialog'
    'Microsoft.Windows.SecureAssessmentBrowser'
    'Microsoft.Windows.PinningConfirmationDialog'
    'Microsoft.AsyncTextService'
    'Microsoft.AccountsControl'
    'F46D4000-FD22-4DB4-AC8E-4E1DDDE828FE'
    'E2A4F912-2574-4A75-9BB0-0D023378592B'
    'Microsoft.Windows.PrintQueueActionCenter'
    'Microsoft.Windows.CapturePicker'
    'Microsoft.CredDialogHost'
    'Microsoft.Windows.AssignedAccessLockApp'
    'Microsoft.Windows.Apprep.ChxApp'
    'Windows.PrintDialog'
    'Microsoft.Windows.ContentDeliveryManager'
    'Microsoft.BioEnrollment'
    'Microsoft.Windows.CloudExperienceHost'
    'MicrosoftWindows.UndockedDevKit'
    'Microsoft.Windows.OOBENetworkCaptivePortal'
    'Microsoft.Windows.OOBENetworkConnectionFlow'
    'Microsoft.AAD.BrokerPlugin'
    'MicrosoftWindows.Client.CoPilot'
    'MicrosoftWindows.Client.CBS'
    'MicrosoftWindows.Client.Core'
    'MicrosoftWindows.Client.FileExp'
    'Microsoft.SecHealthUI'
    'Microsoft.Windows.SecHealthUI'
    'windows.immersivecontrolpanel'
    'Windows.CBSPreview'
    'MicrosoftWindows.Client.WebExperience'
    'Microsoft.Windows.CallingShellApp'
    'Microsoft.Win32WebViewHost'
    'Microsoft.MicrosoftEdgeDevToolsClient'
    'Microsoft.Advertising.Xaml'
    'Microsoft.Services.Store.Engagement'
    'Microsoft.WidgetsPlatformRuntime'
    'MicrosoftWindows.Client.AIX'
    'MicrosoftWindows.Client.Photon'
    'Microsoft.DesktopAppInstaller'
    'MicrosoftWindows.55182690.Taskbar'
    'MicrosoftWindows.Client.CoreAI'
    'MicrosoftWindows.Client.LKG'
    'Microsoft.WidgetsPlatformRuntime'
    'Microsoft.Windows.AppSuggestedFoldersToLibraryDialog'
    'Microsoft.Windows.AppResolverUX'
    'c5e2524a-ea46-4f67-841f-6a9465d9d515'
    '1527c705-839a-4832-9118-54d4Bd6a0c89'
    'MicrosoftWindows.LKG.AccountsService'
    'MicrosoftWindows.LKG.DesktopSpotlight'
    'MicrosoftWindows.LKG.IrisService'
    'MicrosoftWindows.LKG.RulesEngine'
    'MicrosoftWindows.LKG.SpeechRuntime'
    'MicrosoftWindows.LKG.TwinSxS'
    'MicrosoftWindows.57074914.Livtop'
    'MicrosoftWindows.57074904.InpApp'
    'MicrosoftWindows.57058570.Speion'
    'MicrosoftWindows.56978801.Voiess'
    'MicrosoftWindows.54792954.Filons'
  )
  #>

  $Global:prohibitedPackages = @(
    'Microsoft.NET.Native.Framework.*'
    'Microsoft.NET.Native.Runtime.*'
    'Microsoft.UI.Xaml.*'
    'Microsoft.VCLibs.*'
    'Microsoft.WindowsAppRuntime.*'
    'Microsoft.Windows.ShellExperienceHost'
    'Microsoft.Windows.StartMenuExperienceHost'
    'Microsoft.Windows.Search'
    'MicrosoftWindows.Client.OOBE'
    'Microsoft.Windows.AugLoop.CBS'
  )

    
  if ($AutoRun) {
    $result = [System.Windows.Forms.DialogResult]::OK
    if ($debloatAll) {
      $comboBoxPresets.SelectedIndex = 0
    }
    elseif ($debloatSXE) {
      $comboBoxPresets.SelectedIndex = 1
    }
    elseif ($debloatSX) {
      $comboBoxPresets.SelectedIndex = 2
    }
    elseif ($debloatE) {
      $comboBoxPresets.SelectedIndex = 3
    }
    elseif ($debloatS) {
      $comboBoxPresets.SelectedIndex = 4
    }
    
  }
  else {
  
    #creating powershell list box 
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

        

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Debloat'
    $form.Size = New-Object System.Drawing.Size(700, 550)
    $form.StartPosition = 'CenterScreen'
    $form.BackColor = 'Black'
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 8)

    # Sidebar Panel
    $sidebarPanel = New-Object System.Windows.Forms.Panel
    $sidebarPanel.Location = New-Object System.Drawing.Point(0, 0)
    $sidebarPanel.Size = New-Object System.Drawing.Size(150, $form.ClientSize.Height)
    $sidebarPanel.BackColor = 'Black'
    $form.Controls.Add($sidebarPanel)

    $presetsBtn = Create-ModernButton -Text 'Debloat Presets' -Location (New-Object Drawing.Point(20, 10)) -Size (New-Object Drawing.Size(130, 40)) -ClickAction {
      $presetsPanel.Visible = $true
      $appxPanel.Visible = $false
      $featuresPanel.Visible = $false
      $extrasPanel.Visible = $false
      $appUninstallPanel.Visible = $false
      $presetsBtn.Tag = 'Active'
      $appxBtn.Tag = 'Inactive'
      $featuresBtn.Tag = 'Inactive'
      $extrasBtn.Tag = 'Inactive'
      $appUninstallBttn.tag = 'Inactive'
      $presetsBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $appxBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $featuresBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $appUninstallBttn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $extrasBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      Get-Packages -showLockedPackages $false -PresetPage
    } -r 47 -g 49 -b 58 
  
    $sidebarPanel.Controls.Add($presetsBtn)

    $appxBtn = Create-ModernButton -Text 'Appx Packages' -Location (New-Object Drawing.Point(20, 60)) -Size (New-Object Drawing.Size(130, 40)) -ClickAction {
      $presetsPanel.Visible = $false
      $appxPanel.Visible = $true
      $featuresPanel.Visible = $false
      $extrasPanel.Visible = $false
      $appUninstallPanel.Visible = $false
      $presetsBtn.Tag = 'Inactive'
      $appxBtn.Tag = 'Active'
      $featuresBtn.Tag = 'Inactive'
      $extrasBtn.Tag = 'Inactive'
      $appUninstallBttn.tag = 'Inactive'
      $presetsBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $appxBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $appUninstallBttn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $featuresBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $extrasBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      Get-Packages -showLockedPackages $showLockedPackages.Checked 
    } -r 47 -g 49 -b 58 
   
    $sidebarPanel.Controls.Add($appxBtn)

    $featuresBtn = Create-ModernButton -Text 'Optional Features' -Location (New-Object Drawing.Point(20, 110)) -Size (New-Object Drawing.Size(130, 40)) -ClickAction {
      $progressBar1.Visible = $true
      $labelLoading.Visible = $true
      $presetsPanel.Visible = $false
      $appUninstallPanel.Visible = $false
      $appxPanel.Visible = $false
      $featuresPanel.Visible = $true
      $extrasPanel.Visible = $false
      $presetsBtn.Tag = 'Inactive'
      $appxBtn.Tag = 'Inactive'
      $featuresBtn.Tag = 'Active'
      $extrasBtn.Tag = 'Inactive'
      $appUninstallBttn.tag = 'Inactive'
      $presetsBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $appxBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $featuresBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $extrasBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $appUninstallBttn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      Populate-DataGridView
      $progressBar1.Visible = $false
      $labelLoading.Visible = $false
    } -r 47 -g 49 -b 58 
    
    $sidebarPanel.Controls.Add($featuresBtn)

    $extrasBtn = Create-ModernButton -Text 'Extras' -Location (New-Object Drawing.Point(20, 160)) -Size (New-Object Drawing.Size(130, 40)) -ClickAction {
      $presetsPanel.Visible = $false
      $appxPanel.Visible = $false
      $featuresPanel.Visible = $false
      $appUninstallPanel.Visible = $false
      $extrasPanel.Visible = $true
      $presetsBtn.Tag = 'Inactive'
      $appxBtn.Tag = 'Inactive'
      $featuresBtn.Tag = 'Inactive'
      $appUninstallBttn.tag = 'Inactive'
      $extrasBtn.Tag = 'Active'
      $presetsBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $appxBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $featuresBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $appUninstallBttn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $extrasBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
    } -r 47 -g 49 -b 58 
   
    $sidebarPanel.Controls.Add($extrasBtn)

    $appUninstallBttn = Create-ModernButton -Text 'App Uninstaller' -Location (New-Object Drawing.Point(20, 210)) -Size (New-Object Drawing.Size(130, 40)) -ClickAction {
      $presetsPanel.Visible = $false
      $appxPanel.Visible = $false
      $featuresPanel.Visible = $false
      $extrasPanel.Visible = $false
      $appUninstallPanel.Visible = $true
      $presetsBtn.Tag = 'Inactive'
      $appxBtn.Tag = 'Inactive'
      $featuresBtn.Tag = 'Inactive'
      $extrasBtn.Tag = 'Inactive'
      $appUninstallBttn.Tag = 'Active'
      $presetsBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $appxBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $featuresBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $extrasBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $appUninstallBttn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      Display-apps -all
    } -r 47 -g 49 -b 58 
    $sidebarPanel.Controls.Add($appUninstallBttn)

    $url = 'https://github.com/MP7BDO/mpware/blob/main/features.md#debloat'
    $infobutton = New-Object Windows.Forms.Button
    $infobutton.Location = New-Object Drawing.Point(5, 480)
    $infobutton.Size = New-Object Drawing.Size(30, 27)
    $infobutton.Cursor = 'Hand'
    $infobutton.Add_Click({
        try {
          Start-Process $url -ErrorAction Stop
        }
        catch {
          Write-Status -Message 'No Internet Connected...' -Type Error
        }
            
      })
    $infobutton.BackColor = 'Black'
    $image = [System.Drawing.Image]::FromFile('C:\Windows\System32\SecurityAndMaintenance.png')
    $resizedImage = New-Object System.Drawing.Bitmap $image, 24, 25
    $infobutton.Image = $resizedImage
    $infobutton.ImageAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $infobutton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $infobutton.FlatAppearance.BorderSize = 0
    #$infobutton.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(62, 62, 64)
    #$infobutton.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(27, 27, 28)
    $sidebarPanel.Controls.Add($infobutton)

  
    # Main Content Panel
    $contentPanel = New-Object System.Windows.Forms.Panel
    $contentPanel.Location = New-Object System.Drawing.Point(160, 0)
    $contentPanel.Size = New-Object System.Drawing.Size(525, 550) 
    
    $form.Controls.Add($contentPanel)


    # Debloat Presets Panel
    $presetsPanel = New-Object System.Windows.Forms.Panel
    $presetsPanel.Location = New-Object System.Drawing.Point(0, 0)
    $presetsPanel.Size = New-Object System.Drawing.Size(525, 550)
    
    $presetsPanel.Visible = $true
    $contentPanel.Controls.Add($presetsPanel)

    $type = $presetsPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($presetsPanel, $true, $null)

    $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
    $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

    # Override the form's paint event to apply the gradient
    $presetsPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $presetsPanel.Width, $presetsPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })


    $label1 = New-Object System.Windows.Forms.Label
    $label1.Location = New-Object System.Drawing.Point(10, 10)
    $label1.Size = New-Object System.Drawing.Size(200, 20)
    $label1.Text = 'Debloat Presets'
    $label1.ForeColor = 'White'
    $label1.BackColor = [System.Drawing.Color]::Transparent
    $label1.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $presetsPanel.Controls.Add($label1)

    $labelEx = New-Object System.Windows.Forms.Label
    $labelEx.Location = New-Object System.Drawing.Point(10, 130)
    $labelEx.Size = New-Object System.Drawing.Size(200, 20)
    $labelEx.Text = 'Exclude Additional Apps'
    $labelEx.ForeColor = 'White'
    $labelEx.BackColor = [System.Drawing.Color]::Transparent
    $labelEx.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $presetsPanel.Controls.Add($labelEx)

    $comboBoxPresets = New-Object System.Windows.Forms.ComboBox
    $comboBoxPresets.Location = New-Object System.Drawing.Point(20, 40)
    $comboBoxPresets.Size = New-Object System.Drawing.Size(480, 25)
    $comboBoxPresets.Items.AddRange(@('Debloat All', 'Keep Store, Xbox and Edge', 'Keep Store and Xbox', 'Debloat All Keep Edge', 'Debloat All Keep Store'))
    $comboBoxPresets.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    $comboBoxPresets.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $comboBoxPresets.ForeColor = 'White'
    $comboBoxPresets.SelectedIndex = 0
    $presetsPanel.Controls.Add($comboBoxPresets)

    $presetDescriptionLabel = New-Object System.Windows.Forms.Label
    $presetDescriptionLabel.Location = New-Object System.Drawing.Point(20, 70)
    $presetDescriptionLabel.Size = New-Object System.Drawing.Size(480, 60)
    $presetDescriptionLabel.ForeColor = 'White'
    $presetDescriptionLabel.BackColor = [System.Drawing.Color]::Transparent
    $presetDescriptionLabel.Font = New-Object System.Drawing.Font('Segoe UI', 10) 
    $presetDescriptionLabel.Text = "Removes all non-essential apps, including Store, Xbox, and Edge.`r`nAlso removes Remote Desktop, Health Update Tools, and cleans Start Menu Pinned Icons + Outdated Store Apps."
    $presetsPanel.Controls.Add($presetDescriptionLabel)

    $listView2 = New-Object System.Windows.Forms.ListView
    $listView2.Location = New-Object System.Drawing.Point(20, 150)
    $listView2.Size = New-Object System.Drawing.Size(480, 320)
    $listView2.View = [System.Windows.Forms.View]::Details
    $listView2.BackColor = [System.Drawing.Color]::Black
    $listView2.ForeColor = [System.Drawing.Color]::White
    $listView2.CheckBoxes = $true
    $listView2.FullRowSelect = $false
    $listView2.HeaderStyle = [System.Windows.Forms.ColumnHeaderStyle]::None
    $listView2.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $listView2.Columns.Add('Package Name', 455) | Out-Null

    $imageList2 = New-Object System.Windows.Forms.ImageList
    $imageList2.ImageSize = New-Object System.Drawing.Size(32, 32)
    $imageList2.ColorDepth = [System.Windows.Forms.ColorDepth]::Depth32Bit
    $listView2.SmallImageList = $imageList2

    $presetsPanel.Controls.Add($listView2)

    Add-Type -TypeDefinition @'
    using System;
    using System.Runtime.InteropServices;
    using System.Text;
    public class Shell32 {
        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr ExtractAssociatedIconExW(IntPtr hInst, StringBuilder lpIconPath, ref ushort piIconIndex, ref ushort piIconId);
    }
'@ 

    $iconPath = "$env:windir\system32\shell32.dll"
    $iconIndex = 2
    $iconId = 0
    $handle = [Shell32]::ExtractAssociatedIconExW([IntPtr]::Zero, $iconPath, [ref]$iconIndex, [ref]$iconId)
    $defaultAppicon = [System.Drawing.Icon]::FromHandle($handle)

    #GLOBAL VARS
    $Global:logos = [System.Collections.Hashtable]::new()
    $Global:sortedPackages = @()

    function Add-LogoForPackage {
      param (
        [string]$packageName,
        [string]$installLocation,
        [bool]$PresetPage
      )
  
      # Initialize WinLogo as a global fallback to avoid repeated initialization
      if (-not $Global:winLogoIndex) {
        
        $iconBitmap = $defaultAppicon.ToBitmap()
        $resizedBitmap = New-Object System.Drawing.Bitmap(32, 32)
        $graphics = [System.Drawing.Graphics]::FromImage($resizedBitmap)
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $graphics.DrawImage($iconBitmap, 0, 0, 32, 32)
        if ($PresetPage) {
          $imageList2.Images.Add($resizedBitmap)
          $Global:winLogoIndex = $imageList2.Images.Count - 1
        }
        else {
          $imageList.Images.Add($resizedBitmap)
          $Global:winLogoIndex = $imageList.Images.Count - 1
        }
        $graphics.Dispose()
        $resizedBitmap.Dispose()
        $iconBitmap.Dispose()
        
      }
  
      if (-not $installLocation -or -not (Test-Path $installLocation)) {
        $Global:logos.Add($packageName, $Global:winLogoIndex)
        return
      }
  
      $xmlPath = Join-Path $installLocation 'AppxManifest.xml'
      $logoFullPath = $null
  
      try {
        $xmlContent = [xml](Get-Content $xmlPath -ErrorAction Stop)
        $logo = $xmlContent.Package.Applications.Application.VisualElements.Square44x44Logo
        if ($logo -and $logo -is [string] -and $logo.Contains('.')) {
          $index = $logo.LastIndexOf('.')
          $logoPath = $logo.Substring(0, $index)
          $logoExt = $logo.Substring($index)
          $logoFullPath = (Get-ChildItem "$installLocation\$logoPath.scale*$logoExt" -ErrorAction SilentlyContinue | Select-Object -First 1).FullName
        }
        
      }
      catch {}
  
      if ($logoFullPath -and (Test-Path $logoFullPath)) {
        try {
          $image = [System.Drawing.Image]::FromFile($logoFullPath)
          if ($image.Width -gt 0 -and $image.Height -gt 0) {
            $resizedImage = New-Object System.Drawing.Bitmap(32, 32)
            try {
              $graphics = [System.Drawing.Graphics]::FromImage($resizedImage)
              $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
              $graphics.DrawImage($image, 0, 0, 32, 32)
              if ($PresetPage) {
                $imageList2.Images.Add($resizedImage)
                $Global:logos.Add($packageName, $imageList2.Images.Count - 1)
              }
              else {
                $imageList.Images.Add($resizedImage)
                $Global:logos.Add($packageName, $imageList.Images.Count - 1)
              }
              
            }
            finally {
              if ($graphics) { $graphics.Dispose() }
              $resizedImage.Dispose()
            }
          }
          else {
            $Global:logos.Add($packageName, $Global:winLogoIndex)
          }
          $image.Dispose()
        }
        catch {
          $Global:logos.Add($packageName, $Global:winLogoIndex)
        }
      }
      else {
        $Global:logos.Add($packageName, $Global:winLogoIndex)
      }
    }
    function Get-Packages {
      param (
        [bool]$showLockedPackages,
        [switch]$PresetPage
      )
  
  
      $Global:logos.Clear()
      if ($PresetPage) {
        $listView2.Items.Clear()
        $imageList2.Images.Clear()
      }
      else {
        $listView.Items.Clear()
        $imageList.Images.Clear()
      }
      
  
      # Reset WinLogo index
      $Global:winLogoIndex = $null
  
      # Get packages
      try {
        $packageNames = Get-AppxPackage -AllUsers | Select-Object Name, InstallLocation, NonRemovable
        $Global:sortedPackages = $packageNames | Sort-Object Name -Unique
      }
      catch {
        return
      }
  
      if ($showLockedPackages) {
        $Global:BloatwareLocked = @()
        foreach ($package in $Global:sortedPackages) {
          $isProhibited = $Global:prohibitedPackages | Where-Object { $package.Name -like $_ }
          if ($package.NonRemovable -eq $true -and -not $isProhibited) {
            $packageObj = [PSCustomObject]@{
              Name            = $package.Name
              InstallLocation = $package.InstallLocation
            }
            if ($package.Name -eq 'E2A4F912-2574-4A75-9BB0-0D023378592B') {
              $packageObj.Name = 'Microsoft.Windows.AppResolverUX'
            }
            elseif ($package.Name -eq 'F46D4000-FD22-4DB4-AC8E-4E1DDDE828FE') {
              $packageObj.Name = 'Microsoft.Windows.AppSuggestedFoldersToLibraryDialog'
            }
            elseif ($package.Name -eq 'c5e2524a-ea46-4f67-841f-6a9465d9d515') {
              $packageObj.Name = 'Microsoft.Windows.FileExplorer'
            }
            elseif ($package.Name -eq '1527c705-839a-4832-9118-54d4Bd6a0c89') {
              $packageObj.Name = 'Microsoft.Windows.FilePicker'
            }
            $Global:BloatwareLocked += $packageObj
          }
        }
        foreach ($package in $Global:BloatwareLocked) {
          Add-LogoForPackage -packageName $package.Name -installLocation $package.InstallLocation
        }
      }
      else {
        $Global:Bloatware = @()
        foreach ($package in $Global:sortedPackages) {
          $isProhibited = $Global:prohibitedPackages | Where-Object { $package.Name -like $_ }
          if ($package.NonRemovable -ne $true -and -not $isProhibited) {
            $Global:Bloatware += [PSCustomObject]@{
              Name            = $package.Name
              InstallLocation = $package.InstallLocation
            }
          }
        }
        foreach ($package in $Global:Bloatware) {
          Add-LogoForPackage -packageName $package.Name -installLocation $package.InstallLocation -PresetPage $PresetPage
        }
      }
  
      foreach ($package in $Global:logos.GetEnumerator()) {
        $item = New-Object System.Windows.Forms.ListViewItem
        $item.Text = $package.Key
        $item.ImageIndex = $package.Value
        if ($PresetPage) {
          $listView2.Items.Add($item) | Out-Null
        }
        else {
          $listView.Items.Add($item) | Out-Null
        }
      }
      if ($PresetPage) {
        $listView2.Refresh()
      }
      else {
        $listView.Refresh()
      }
    }


    

    $applyPreset = Create-ModernButton -Text 'Apply Preset' -Location (New-Object Drawing.Point(20, 480)) -Size (New-Object Drawing.Size(480, 30)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -ClickAction {
      $applyPreset.Tag = 'true'
    } -borderSize 2
    $applyPreset.Tag = 'false'
    
    <#
    $applyPreset = New-Object System.Windows.Forms.Button
    $applyPreset.Location = New-Object System.Drawing.Point(20, 150)
    $applyPreset.Size = New-Object System.Drawing.Size(480, 30)
    $applyPreset.Text = 'Apply Preset'
    $applyPreset.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $applyPreset.ForeColor = [System.Drawing.Color]::White
    $applyPreset.DialogResult = [System.Windows.Forms.DialogResult]::OK
    
    $applyPreset.Add_Click({ $applyPreset.Tag = 'true' })
    #>
    $presetsPanel.Controls.Add($applyPreset)

    $comboBoxPresets.Add_SelectedIndexChanged({
        switch ($comboBoxPresets.SelectedIndex) {
          0 { $presetDescriptionLabel.Text = "Removes all non-essential apps, including Store, Xbox, and Edge.`r`nAlso removes Remote Desktop, Health Update Tools, and cleans Start Menu Pinned Icons + Outdated Store Apps." }
          1 { $presetDescriptionLabel.Text = "Keeps Microsoft Store, Xbox apps, and Edge browser.`r`nAlong with removing Remote Desktop, Health Update Tools, and cleaning Start Menu Pinned Icons + Outdated Store Apps" }
          2 { $presetDescriptionLabel.Text = "Keeps Microsoft Store and Xbox apps, removes Edge.`r`nAlong with removing Remote Desktop, Health Update Tools, and cleaning Start Menu Pinned Icons + Outdated Store Apps" }
          3 { $presetDescriptionLabel.Text = "Removes all non-essential apps except Edge browser.`r`nAlong with removing Remote Desktop, Health Update Tools, and cleaning Start Menu Pinned Icons + Outdated Store Apps" }
          4 { $presetDescriptionLabel.Text = "Removes all non-essential apps except Microsoft Store.`r`nAlong with removing Remote Desktop, Health Update Tools, and cleaning Start Menu Pinned Icons + Outdated Store Apps" }
        }
      })

    # Appx Packages Panel
    $appxPanel = New-Object System.Windows.Forms.Panel
    $appxPanel.Location = New-Object System.Drawing.Point(0, 0)
    $appxPanel.Size = New-Object System.Drawing.Size(525, 550)
    $appxPanel.BackColor = [System.Drawing.Color]::FromArgb(65, 65, 65)
    $appxPanel.Visible = $false
    $contentPanel.Controls.Add($appxPanel)

    $type = $appxPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($appxPanel, $true, $null)

    # Override the form's paint event to apply the gradient
    $appxPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $appxPanel.Width, $appxPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    $removeAppxPackages = {
      if ($listView.CheckedItems.Count -eq 0) { Write-Status -Message 'No Packages Selected' -Type Error }
      else {
        $ProgressPreference = 'SilentlyContinue'
        foreach ($item in $listView.CheckedItems) {
          $package = $item.Text
          Write-Status -Message "Trying to Remove $package" -Type Output
          #silentlycontinue doesnt work sometimes so trycatch block is needed to supress errors
          try {
            Get-AppXPackage "*$package*" -AllUsers -ErrorAction Stop | ForEach-Object { Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ErrorAction SilentlyContinue; Remove-AppxPackage -Package $_.PackageFullName -AllUsers -ErrorAction Stop } | Out-Null
          }
          catch {}
          try {
            Get-AppxProvisionedPackage -Online | Where-Object DisplayName -like "*$package*" | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction Stop | Out-Null
          }
          catch {}    
        }
        #refresh list box
        Get-Packages -showLockedPackages $false
      }
    }

    $removeAppx = Create-ModernButton -Text 'Remove Appx Packages' -Location (New-Object Drawing.Point(20, 430)) -Size (New-Object Drawing.Size(230, 30)) -ClickAction {
      &$removeAppxPackages
    } -borderSize 2
    <#
    $removeAppx = New-Object System.Windows.Forms.Button
    $removeAppx.Location = New-Object System.Drawing.Point(20, 430)
    $removeAppx.Size = New-Object System.Drawing.Size(230, 30)
    $removeAppx.Text = 'Remove Appx Packages'
    $removeAppx.Font = New-Object System.Drawing.Font('Segoe UI', 9) 
    $removeAppx.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $removeAppx.ForeColor = [System.Drawing.Color]::White
    #$removeAppx.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    #$removeAppx.FlatAppearance.BorderSize = 0
    #$removeAppx.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(62, 62, 64)
    #$removeAppx.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(27, 27, 28)
    $removeAppx.Add_Click({
        &$removeAppxPackages
      })
      #>
    $appxPanel.Controls.Add($removeAppx)

    
    $removeLockedPackages = {
      if ($listView.CheckedItems.Count -eq 0) { Write-Status -Message 'No Packages Selected' -Type Error }
      else {
        $selectedLockedPackages = @()
        foreach ($item in $listView.CheckedItems) {
          $selectedLockedPackages += $item.Text
        }

        $removelockedFunc = Search-File '*Remove-Locked.ps1'
        foreach ($packageName in $selectedLockedPackages) {
          Write-Status -Message "Trying to Remove $packageName" -Type Output
          #dot source function 
          Run-Trusted -command ".'$removelockedFunc'; Remove-Locked $packageName"
          Start-Sleep .5
        }
       
      }
      #update list
      Get-Packages -showLockedPackages $true
    }
    
    $removeLocked = Create-ModernButton -Text 'Remove Locked Packages' -Location (New-Object Drawing.Point(270, 430)) -Size (New-Object Drawing.Size(230, 30)) -ClickAction {
      &$removeLockedPackages
    } -borderSize 2
    <#
    $removeLocked = New-Object System.Windows.Forms.Button
    $removeLocked.Location = New-Object System.Drawing.Point(270, 430)
    $removeLocked.Size = New-Object System.Drawing.Size(230, 30)
    $removeLocked.Text = 'Remove Locked Packages'
    $removeLocked.Font = New-Object System.Drawing.Font('Segoe UI', 9) 
    $removeLocked.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $removeLocked.ForeColor = [System.Drawing.Color]::White
    #$removeLocked.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    #$removeLocked.FlatAppearance.BorderSize = 0
    #$removeLocked.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(62, 62, 64)
    #$removeLocked.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(27, 27, 28)
    $removeLocked.Add_Click({
        &$removeLockedPackages
      })
      #>
    $appxPanel.Controls.Add($removeLocked)

 
    $checkAllBoxes = {
      if (!$checkAll.Checked) {
        foreach ($item in $listView.Items) {
          $item.Checked = $false
        }
      }
      else {
        foreach ($item in $listView.Items) {
          $item.Checked = $true
        }
      }
    }

    $checkAll = New-Object System.Windows.Forms.CheckBox
    $checkAll.Location = New-Object System.Drawing.Point(20, 40)
    $checkAll.Size = New-Object System.Drawing.Size(90, 21)
    $checkAll.Text = 'Check All'
    $checkAll.ForeColor = 'White'
    $checkAll.Add_Click({ 
        &$checkAllBoxes
      })
    $appxPanel.Controls.Add($checkAll)

    $label2 = New-Object System.Windows.Forms.Label
    $label2.Location = New-Object System.Drawing.Point(10, 10)
    $label2.Size = New-Object System.Drawing.Size(200, 20)
    $label2.Text = 'Appx Packages'
    $label2.ForeColor = 'White'
    $label2.BackColor = [System.Drawing.Color]::Transparent
    $label2.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $appxPanel.Controls.Add($label2)


    $listView = New-Object System.Windows.Forms.ListView
    $listView.Location = New-Object System.Drawing.Point(20, 70)
    $listView.Size = New-Object System.Drawing.Size(480, 350)
    $listView.View = [System.Windows.Forms.View]::Details
    $listView.BackColor = [System.Drawing.Color]::Black
    $listView.ForeColor = [System.Drawing.Color]::White
    $listView.CheckBoxes = $true
    $listView.FullRowSelect = $false
    $listView.HeaderStyle = [System.Windows.Forms.ColumnHeaderStyle]::None
    $listView.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $listView.Columns.Add('Package Name', 455) | Out-Null

    $imageList = New-Object System.Windows.Forms.ImageList
    $imageList.ImageSize = New-Object System.Drawing.Size(32, 32)
    $imageList.ColorDepth = [System.Windows.Forms.ColorDepth]::Depth32Bit
    $listView.SmallImageList = $imageList


    $appxPanel.Controls.Add($listView)

   
    # Optional Features Panel
    $featuresPanel = New-Object System.Windows.Forms.Panel
    $featuresPanel.Location = New-Object System.Drawing.Point(0, 0)
    $featuresPanel.Size = New-Object System.Drawing.Size(525, 550)
   
    $featuresPanel.Visible = $false
    $contentPanel.Controls.Add($featuresPanel)
    
    $type = $featuresPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($featuresPanel, $true, $null)

    # Override the form's paint event to apply the gradient
    $featuresPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $featuresPanel.Width, $featuresPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    $label3 = New-Object System.Windows.Forms.Label
    $label3.Location = New-Object System.Drawing.Point(10, 10)
    $label3.Size = New-Object System.Drawing.Size(200, 20)
    $label3.Text = 'Optional Features'
    $label3.ForeColor = 'White'
    $label3.BackColor = [System.Drawing.Color]::Transparent
    $label3.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $featuresPanel.Controls.Add($label3)

    $checkAllCheckbox = New-Object System.Windows.Forms.CheckBox
    $checkAllCheckbox.Location = New-Object System.Drawing.Point(420, 20)
    $checkAllCheckbox.Size = New-Object System.Drawing.Size(100, 20)
    $checkAllCheckbox.Text = 'Check All'
    $checkAllCheckbox.ForeColor = 'White'
    $checkAllCheckbox.Add_CheckedChanged({
        $dataGridView.EndEdit() # Ensure any pending edits are applied
        foreach ($row in $dataGridView.Rows) {
          $row.Cells['Select'].Value = $checkAllCheckbox.Checked
        }
        $dataGridView.Refresh()
      })
    $featuresPanel.Controls.Add($checkAllCheckbox)

    $dataGridView = New-Object System.Windows.Forms.DataGridView
    $dataGridView.Location = New-Object System.Drawing.Point(20, 40)
    $dataGridView.Size = New-Object System.Drawing.Size(480, 350)
    $dataGridView.BackgroundColor = [System.Drawing.Color]::Black
    $dataGridView.ForeColor = 'White'
    $dataGridView.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $dataGridView.ColumnHeadersDefaultCellStyle.ForeColor = 'White'
    $dataGridView.DefaultCellStyle.BackColor = [System.Drawing.Color]::Black
    $dataGridView.DefaultCellStyle.ForeColor = 'White'
    $dataGridView.RowHeadersVisible = $false
    $dataGridView.AllowUserToAddRows = $false
    $dataGridView.ReadOnly = $false
    $dataGridView.SelectionMode = 'FullRowSelect'
    $dataGridView.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill
    $dataGridView.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
    $dataGridView.Columns.Clear()
    $featuresPanel.Controls.Add($dataGridView)
    
    $Global:progressBar1 = New-Object System.Windows.Forms.ProgressBar
    $progressBar1.Location = New-Object System.Drawing.Point(230, 485)
    $progressBar1.Size = New-Object System.Drawing.Size(150, 15)
    $progressBar1.Style = [System.Windows.Forms.ProgressBarStyle]::Continuous
    $progressBar1.Minimum = 0
    $progressBar1.Maximum = 100
    $progressBar1.Visible = $false
    $featuresPanel.Controls.Add($progressBar1)

    $Global:labelLoading = New-Object System.Windows.Forms.Label
    $labelLoading.Text = 'Loading'
    $labelLoading.ForeColor = 'White'
    $labelLoading.Location = New-Object System.Drawing.Point(160, 480)
    $labelLoading.AutoSize = $true
    $labelLoading.Font = New-Object System.Drawing.Font('Segoe UI', 11)
    $labelLoading.Visible = $false
    $labelLoading.BackColor = [System.Drawing.Color]::Transparent
    $featuresPanel.Controls.Add($labelLoading)
    
    $Global:timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 1000 # 1 second
    $script:progressValue = 0
    $timer.Add_Tick({
        $script:progressValue++
        if ($script:progressValue -le 100) {
          $progressBar1.Value = $script:progressValue
        }
        else {
          $timer.Stop()
        }
      })


    function Populate-DataGridView {
    
      # Create a DataTable to hold the data
      $dataTable = New-Object System.Data.DataTable
      [void]$dataTable.Columns.Add('Select', [bool])
      [void]$dataTable.Columns.Add('Name', [string])
      [void]$dataTable.Columns.Add('Type', [string])

      $script:progressValue = 0
      $progressBar1.Value = 0
      $timer.Start()
    
      $totalItems = 0
      $processedItems = 0

      $packages = get-dismPackages
      $totalItems += $packages.Count
      foreach ($package in $packages) {
        if ($package.PackageName) {
          $row = $dataTable.NewRow()
          $row['Select'] = $false
          $row['Name'] = $package.PackageName
          $row['Type'] = 'Package'
          $dataTable.Rows.Add($row)
          $processedItems++
          $progressBar1.Value = [math]::Min(100, ($processedItems / $totalItems) * 100)
          $form.Refresh() 
        }
      }
    
      $capabilities = get-dismCapability
      $totalItems += $capabilities.Count
      foreach ($capability in $capabilities) {
        if ($capability.Name) {
          $row = $dataTable.NewRow()
          $row['Select'] = $false
          $row['Name'] = $capability.Name
          $row['Type'] = 'Capability'
          $dataTable.Rows.Add($row)
          $processedItems++
          $progressBar1.Value = [math]::Min(100, ($processedItems / $totalItems) * 100)
          $form.Refresh() 
        }
      }
    
      $features = get-dismFeatures
      $totalItems += $features.Count
      foreach ($feature in $features) {
        if ($feature.FeatureName) {
          $row = $dataTable.NewRow()
          $row['Select'] = $false
          $row['Name'] = $feature.FeatureName
          $row['Type'] = 'Feature'
          $dataTable.Rows.Add($row)
          $processedItems++
          $progressBar1.Value = [math]::Min(100, ($processedItems / $totalItems) * 100)
          $form.Refresh() 
        }
      }
    
        
      $dataGridView.DataSource = $dataTable
    
      $dataGridView.Columns['Select'].ReadOnly = $false
      $dataGridView.Columns['Name'].ReadOnly = $true
      $dataGridView.Columns['Type'].ReadOnly = $true
      $dataGridView.Columns['Select'].Width = 60
      $dataGridView.Columns['Name'].Width = 340
      $dataGridView.Columns['Type'].Width = 80
        

      $progressBar1.Value = 100
      $timer.Stop()
     
      $dataGridView.Refresh()
      $dataGridView.Update()
      $featuresPanel.Refresh()
      $dataGridView.ClearSelection()
      
    }
  
    $removeSelectedButton = Create-ModernButton -Text 'Remove Selected' -Location (New-Object Drawing.Point(20, 400)) -Size (New-Object Drawing.Size(480, 30)) -ClickAction {
      $selectedRows = $dataGridView.Rows | Where-Object { $_.Cells['Select'].Value -eq $true }
      if ($selectedRows.Count -eq 0) {
        Write-Status -Message 'No items selected for removal.' -Type Error
        return
      }
  
      foreach ($row in $selectedRows) {
        $name = $row.Cells['Name'].Value
        $type = $row.Cells['Type'].Value
        if ($type -eq 'Package') {
          debloat-dismPackage -packageName $name
        }
        elseif ($type -eq 'Capability') {
          debloat-dismCapability -capabilityName $name
        }
        elseif ($type -eq 'Feature') {
          debloat-dismFeatures -featureName $name
        }
          
      }
      #refresh grid view
      Populate-DataGridView
    } -borderSize 2

    <#
    $removeSelectedButton = New-Object System.Windows.Forms.Button
    $removeSelectedButton.Location = New-Object System.Drawing.Point(20, 400)
    $removeSelectedButton.Size = New-Object System.Drawing.Size(480, 30)
    $removeSelectedButton.Text = 'Remove Selected'
    $removeSelectedButton.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $removeSelectedButton.ForeColor = [System.Drawing.Color]::White
    $removeSelectedButton.Add_Click({
        $selectedRows = $dataGridView.Rows | Where-Object { $_.Cells['Select'].Value -eq $true }
        if ($selectedRows.Count -eq 0) {
          Write-Status -Message 'No items selected for removal.' -Type Error
          return
        }
    
        foreach ($row in $selectedRows) {
          $name = $row.Cells['Name'].Value
          $type = $row.Cells['Type'].Value
          if ($type -eq 'Package') {
            debloat-dismPackage -packageName $name
          }
          elseif ($type -eq 'Capability') {
            debloat-dismCapability -capabilityName $name
          }
          elseif ($type -eq 'Feature') {
            debloat-dismFeatures -featureName $name
          }
            
        }
        #refresh grid view
        Populate-DataGridView
      })
      #>
    $featuresPanel.Controls.Add($removeSelectedButton)

   
        
    $showLockedPackages = New-Object System.Windows.Forms.CheckBox
    $showLockedPackages.Location = New-Object System.Drawing.Point(120, 40)
    $showLockedPackages.Size = New-Object System.Drawing.Size(140, 20)
    $showLockedPackages.Text = 'Show Locked Packages'
    $showLockedPackages.ForeColor = 'White'
    $showLockedPackages.Checked = $false
    $showLockedPackages.Add_CheckedChanged({ Get-Packages -showLockedPackages $showLockedPackages.Checked })
    $appxPanel.Controls.Add($showLockedPackages)
        
    # Extras Panel
    $extrasPanel = New-Object System.Windows.Forms.Panel
    $extrasPanel.Location = New-Object System.Drawing.Point(0, 0)
    $extrasPanel.Size = New-Object System.Drawing.Size(525, 550)
    $extrasPanel.Visible = $false
    $contentPanel.Controls.Add($extrasPanel)

    $type = $extrasPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($extrasPanel, $true, $null)

    # Override the form's paint event to apply the gradient
    $extrasPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $extrasPanel.Width, $extrasPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    $groupBox = New-Object System.Windows.Forms.GroupBox
    $groupBox.Text = 'Win 32 Apps'
    $groupBox.Size = New-Object System.Drawing.Size(240, 290)
    $groupBox.Location = New-Object System.Drawing.Point(10, 40)
    $groupBox.BackColor = [System.Drawing.Color]::FromArgb(65, 65, 65)
    $groupBox.ForeColor = 'White'
    $groupBox.BackColor = [System.Drawing.Color]::Transparent
    $extrasPanel.Controls.Add($groupBox)

    $extraSpeech = New-Object System.Windows.Forms.CheckBox
    $extraSpeech.Location = New-Object System.Drawing.Point(20, 20)
    $extraSpeech.Size = New-Object System.Drawing.Size(115, 20)
    $extraSpeech.Text = 'Speech App'
    $extraSpeech.ForeColor = 'White'
    $groupBox.Controls.Add($extraSpeech)

    $extraLiveCap = New-Object System.Windows.Forms.CheckBox
    $extraLiveCap.Location = New-Object System.Drawing.Point(20, 50)
    $extraLiveCap.Size = New-Object System.Drawing.Size(115, 20)
    $extraLiveCap.Text = 'Live Captions'
    $extraLiveCap.ForeColor = 'White'
    $groupBox.Controls.Add($extraLiveCap)

    $extraMagnifier = New-Object System.Windows.Forms.CheckBox
    $extraMagnifier.Location = New-Object System.Drawing.Point(20, 80)
    $extraMagnifier.Size = New-Object System.Drawing.Size(115, 20)
    $extraMagnifier.Text = 'Magnifier'
    $extraMagnifier.ForeColor = 'White'
    $groupBox.Controls.Add($extraMagnifier)

    $extraNarrator = New-Object System.Windows.Forms.CheckBox
    $extraNarrator.Location = New-Object System.Drawing.Point(20, 110)
    $extraNarrator.Size = New-Object System.Drawing.Size(115, 20)
    $extraNarrator.Text = 'Narrator'
    $extraNarrator.ForeColor = 'White'
    $groupBox.Controls.Add($extraNarrator)

    $extraOSK = New-Object System.Windows.Forms.CheckBox
    $extraOSK.Location = New-Object System.Drawing.Point(20, 140)
    $extraOSK.Size = New-Object System.Drawing.Size(125, 20)
    $extraOSK.Text = 'On-Screen Keyboard'
    $extraOSK.ForeColor = 'White'
    $groupBox.Controls.Add($extraOSK)

    $extraVoice = New-Object System.Windows.Forms.CheckBox
    $extraVoice.Location = New-Object System.Drawing.Point(20, 170)
    $extraVoice.Size = New-Object System.Drawing.Size(115, 20)
    $extraVoice.Text = 'Voice Access'
    $extraVoice.ForeColor = 'White'
    $groupBox.Controls.Add($extraVoice)

    $extraSteps = New-Object System.Windows.Forms.CheckBox
    $extraSteps.Location = New-Object System.Drawing.Point(20, 200)
    $extraSteps.Size = New-Object System.Drawing.Size(115, 20)
    $extraSteps.Text = 'Steps Recorder'
    $extraSteps.ForeColor = 'White'
    $groupBox.Controls.Add($extraSteps)

    $extraQuickAssist = New-Object System.Windows.Forms.CheckBox
    $extraQuickAssist.Location = New-Object System.Drawing.Point(20, 230)
    $extraQuickAssist.Size = New-Object System.Drawing.Size(115, 20)
    $extraQuickAssist.Text = 'Quick Assist'
    $extraQuickAssist.ForeColor = 'White'
    $groupBox.Controls.Add($extraQuickAssist)

    $extraMathInput = New-Object System.Windows.Forms.CheckBox
    $extraMathInput.Location = New-Object System.Drawing.Point(20, 260)
    $extraMathInput.Size = New-Object System.Drawing.Size(115, 20)
    $extraMathInput.Text = 'Math Input Panel'
    $extraMathInput.ForeColor = 'White'
    $groupBox.Controls.Add($extraMathInput)

    $label4 = New-Object System.Windows.Forms.Label
    $label4.Location = New-Object System.Drawing.Point(10, 10)
    $label4.Size = New-Object System.Drawing.Size(200, 20)
    $label4.Text = 'Extras'
    $label4.ForeColor = 'White'
    $label4.BackColor = [System.Drawing.Color]::Transparent
    $label4.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $extrasPanel.Controls.Add($label4)

    $groupBox2 = New-Object System.Windows.Forms.GroupBox
    $groupBox2.Text = 'Misc'
    $groupBox2.Size = New-Object System.Drawing.Size(240, 260)
    $groupBox2.Location = New-Object System.Drawing.Point(260, 40)
    $groupBox2.BackColor = [System.Drawing.Color]::FromArgb(65, 65, 65)
    $groupBox2.ForeColor = 'White'
    $groupBox2.BackColor = [System.Drawing.Color]::Transparent
    $extrasPanel.Controls.Add($groupBox2)

    $extraEdge = New-Object System.Windows.Forms.CheckBox
    $extraEdge.Location = New-Object System.Drawing.Point(20, 20)
    $extraEdge.Size = New-Object System.Drawing.Size(115, 20)
    $extraEdge.Text = 'Microsoft Edge'
    $extraEdge.ForeColor = 'White'
    $groupBox2.Controls.Add($extraEdge)

    $extraWebview = New-Object System.Windows.Forms.CheckBox
    $extraWebview.Location = New-Object System.Drawing.Point(20, 50)
    $extraWebview.Size = New-Object System.Drawing.Size(100, 20)
    $extraWebview.Text = 'Edge WebView'
    $extraWebview.ForeColor = 'White'
    $groupBox2.Controls.Add($extraWebview)

    $extraTeamsOneDrive = New-Object System.Windows.Forms.CheckBox
    $extraTeamsOneDrive.Location = New-Object System.Drawing.Point(20, 80)
    $extraTeamsOneDrive.Size = New-Object System.Drawing.Size(150, 20)
    $extraTeamsOneDrive.Text = 'Teams and OneDrive'
    $extraTeamsOneDrive.ForeColor = 'White'
    $groupBox2.Controls.Add($extraTeamsOneDrive)

    $extraUpdateTools = New-Object System.Windows.Forms.CheckBox
    $extraUpdateTools.Location = New-Object System.Drawing.Point(20, 110)
    $extraUpdateTools.Size = New-Object System.Drawing.Size(150, 20)
    $extraUpdateTools.Text = 'Windows Update Tools'
    $extraUpdateTools.ForeColor = 'White'
    $groupBox2.Controls.Add($extraUpdateTools)

    $extraRemoveRemote = New-Object System.Windows.Forms.CheckBox
    $extraRemoveRemote.Location = New-Object System.Drawing.Point(20, 140)
    $extraRemoveRemote.Size = New-Object System.Drawing.Size(170, 20)
    $extraRemoveRemote.Text = 'Remote Desktop Connection'
    $extraRemoveRemote.ForeColor = 'White'
    $groupBox2.Controls.Add($extraRemoveRemote)

    $extraStartMenu = New-Object System.Windows.Forms.CheckBox
    $extraStartMenu.Location = New-Object System.Drawing.Point(20, 170)
    $extraStartMenu.Size = New-Object System.Drawing.Size(200, 20)
    $extraStartMenu.Text = 'Clean Start Menu Icons'
    $extraStartMenu.ForeColor = 'White'
    $groupBox2.Controls.Add($extraStartMenu)

    $extraCleanStoreApps = New-Object System.Windows.Forms.CheckBox
    $extraCleanStoreApps.Location = New-Object System.Drawing.Point(20, 200)
    $extraCleanStoreApps.Size = New-Object System.Drawing.Size(200, 20)
    $extraCleanStoreApps.Text = 'Clean Outdated Store Apps'
    $extraCleanStoreApps.ForeColor = 'White'
    $groupBox2.Controls.Add($extraCleanStoreApps)

    $extraCBSApps = New-Object System.Windows.Forms.CheckBox
    $extraCBSApps.Location = New-Object System.Drawing.Point(20, 230)
    $extraCBSApps.Size = New-Object System.Drawing.Size(200, 20)
    $extraCBSApps.Text = 'Remove Backup App && Get Started'
    $extraCBSApps.ForeColor = 'White'
    $groupBox2.Controls.Add($extraCBSApps)

    $applyExtras = Create-ModernButton -Text 'Apply Extras' -Location (New-Object Drawing.Point(20, 350)) -Size (New-Object Drawing.Size(480, 30)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2

    $extrasPanel.Controls.Add($applyExtras)

    $appUninstallPanel = New-Object System.Windows.Forms.Panel 
    $appUninstallPanel.Location = New-Object System.Drawing.Point(0, 0) 
    $appUninstallPanel.Size = New-Object System.Drawing.Size(525, 550) 
    $appUninstallPanel.Visible = $false
    $contentPanel.Controls.Add($appUninstallPanel)

    $type = $appUninstallPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($appUninstallPanel, $true, $null)

    # Override the form's paint event to apply the gradient
    $appUninstallPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $appUninstallPanel.Width, $appUninstallPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    $appslistView = New-Object System.Windows.Forms.ListView
    $appslistView.Location = New-Object System.Drawing.Point(20, 70)
    $appslistView.Size = New-Object System.Drawing.Size(480, 390)
    $appslistView.View = [System.Windows.Forms.View]::Details
    $appslistView.BackColor = [System.Drawing.Color]::Black
    $appslistView.ForeColor = [System.Drawing.Color]::White
    $appslistView.CheckBoxes = $true
    $appslistView.FullRowSelect = $false
    $appslistView.HeaderStyle = [System.Windows.Forms.ColumnHeaderStyle]::None
    $appslistView.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $appslistView.Columns.Add('App Name', 455) | Out-Null

    $imageListApps = New-Object System.Windows.Forms.ImageList
    $imageListApps.ImageSize = New-Object System.Drawing.Size(32, 32)
    $imageListApps.ColorDepth = [System.Windows.Forms.ColorDepth]::Depth32Bit
    $appslistView.SmallImageList = $imageListApps

    function Display-Apps {
      param (
        [switch]$all,
        [switch]$ThirdPartyOnly
      )

      $appslistView.Items.Clear()
      $imageListApps.Images.Clear()

      if ($all) {
        $AllApps = Get-InstalledApps -AllApps
      }
      elseif ($ThirdPartyOnly) {
        $AllApps = Get-InstalledApps -ThirdPartyOnly
      }
   

      foreach ($app in $AllApps) {
        $icon = Get-AppIcon -app $app
        $imageListApps.Images.Add($app.DisplayName, $icon)  
        $item = New-Object System.Windows.Forms.ListViewItem
        $item.Text = $app.DisplayName
        $item.ImageKey = $app.DisplayName
        $item.Tag = $app #store the app object for uninstalling 
        $appslistView.Items.Add($item)
      }
      
    }

    $appUninstallPanel.Controls.Add($appslistView)

    $labelapps = New-Object System.Windows.Forms.Label
    $labelapps.Location = New-Object System.Drawing.Point(12, 10)
    $labelapps.Size = New-Object System.Drawing.Size(200, 30)
    $labelapps.Text = 'Installed Apps'
    $labelapps.ForeColor = 'White'
    $labelapps.BackColor = [System.Drawing.Color]::Transparent
    $labelapps.Font = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
    $appUninstallPanel.Controls.Add($labelapps)

    $uninstallAppbttn = Create-ModernButton -Text 'Uninstall App(s)' -Location (New-Object Drawing.Point(20, 470)) -Size (New-Object Drawing.Size(480, 30)) -ClickAction {
      #setup log file for uninstall
      #mainly for debugging
      $logPath = "$env:USERPROFILE\zAppUninstall.log"
      if (!(Test-Path $logPath)) {
        New-Item $logPath -Force | Out-Null
      }
      if ($appslistView.CheckedItems.Count -ne 0) {
        foreach ($selectedapp in $appslistView.CheckedItems) {
          $app = $selectedapp.tag
          Write-Status "Uninstalling $($app.DisplayName)" -Type Output
          Add-Content $logPath -Value "Uninstalling $($app.DisplayName)"
          #run specfic uninstaller for edge
          if ($app.displayName -like '*Edge*') {
            $edge = Search-File '*EdgeRemove.ps1'
            if ($app.displayName -like '*WebView*') {
              &$edge -Webview
            }
            else {
              &$edge
            }
          }
          else {
            $uninstallOBJ = Get-UninstallString -app $app #returns uninstall obj
            Add-Content $logPath -Value "UninstallString: $($uninstallOBJ.UninstallString)"
            Add-Content $logPath -Value "UninstallStringQuiet: $($uninstallOBJ.silent)"
            Run-Uninstallers -uninstallString $uninstallOBJ

            #handle removing leftovers
            #pop up window to ask and then display found leftover files and reg location
            Write-Status -Message 'Searching For Leftover Files and Folders...' -Type Output
            $filePaths = Get-InstallDirs -app $app
            $regPaths = Get-RegLocation -app $app
            $selectedPaths = $null
            if ($filePaths -or $regPaths) {
              $selectedPaths = Display-LeftOvers -filePaths $filePaths -regPaths $regPaths
              #i would check if selectedPaths is empty but for some reason data gridview adds numbers to the array even if nothing is selected
              foreach ($path in $selectedPaths) {
                #because test-path is retarded and errors when the path is null even with erroraction
                #we need to catch to hide the error 
                try {
                  if (Test-Path $path -ErrorAction SilentlyContinue) {
                    Write-Status "Trying to Remove: $path" -Type Output
                    Add-Content $logPath -Value "Trying to Remove: $path"
                    Remove-ItemForce -path $path
                  }
                }
                catch {}
             
              }
            }
            else {
              Write-Status -Message 'No Leftovers Found!' -Type Output
            }
            
          }
       
          

        }
        #refresh the ui
        if ($3rdPartyAppsCheckbox.checked) {
          Display-Apps -ThirdPartyOnly
        }
        else {
          Display-Apps -all
        }
        
      }
      else {
        Write-Status -Message 'No App Selected...Please Select an App to Uninstall' -Type Warning
      }

    } -borderSize 2
    $appUninstallPanel.Controls.Add($uninstallAppbttn)

    $checkAllBoxesApps = {
      if (!$checkAllApps.Checked) {
        foreach ($item in $appslistView.Items) {
          $item.Checked = $false
        }
      }
      else {
        foreach ($item in $appslistView.Items) {
          $item.Checked = $true
        }
      }
    }

    $checkAllApps = New-Object System.Windows.Forms.CheckBox
    $checkAllApps.Location = New-Object System.Drawing.Point(17, 45)
    $checkAllApps.Size = New-Object System.Drawing.Size(90, 21)
    $checkAllApps.Text = 'Check All'
    $checkAllApps.ForeColor = 'White'
    $checkAllApps.BackColor = [System.Drawing.Color]::Transparent
    $checkAllApps.Add_Click({ 
        &$checkAllBoxesApps
      })
    $appUninstallPanel.Controls.Add($checkAllApps)

    $3rdPartyAppsCheckbox = New-Object System.Windows.Forms.CheckBox
    $3rdPartyAppsCheckbox.Location = New-Object System.Drawing.Point(130, 45)
    $3rdPartyAppsCheckbox.Size = New-Object System.Drawing.Size(150, 21)
    $3rdPartyAppsCheckbox.Text = 'Hide Microsoft Apps'
    $3rdPartyAppsCheckbox.ForeColor = 'White'
    $3rdPartyAppsCheckbox.Checked = $false
    $3rdPartyAppsCheckbox.BackColor = [System.Drawing.Color]::Transparent
    $3rdPartyAppsCheckbox.Add_Click({ 
        if ($3rdPartyAppsCheckbox.Checked) {
          Display-Apps -ThirdPartyOnly
        }
        else {
          Display-Apps -all
        }
      })
    $appUninstallPanel.Controls.Add($3rdPartyAppsCheckbox)


    $presetsPanel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }

    $appxPanel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }

    $featuresPanel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }

    $extrasPanel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }

    $form.Add_Shown({
        Get-Packages -showLockedPackages $false -PresetPage
      })
   
    $result = $form.ShowDialog()
  }


  
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    if (!($Autorun)) {
      #loop through checkbox hashtable to update config
      $settings.GetEnumerator() | ForEach-Object {
            
        $settingName = $_.Key
        $checkbox = $_.Value
        #dont update config with options already checked
        if ($Global:enabledOptions -contains $settingName) {
          $checkbox.Checked = $false
        }
        
        if ($checkbox.Checked) {
          update-config -setting $settingName -value 1
        }
      }
    }
  
    if ($applyPreset.Tag -eq 'True' -or $AutoRun) {
      if (!$AutoRun) {
        $excludedPackages = @()
        foreach ($item in $listView2.CheckedItems) {
          $excludedPackages += $item.Text
        }
      }
      else {
        $excludedPackages = $null
      }
      if ($comboBoxPresets.SelectedIndex -eq 0) {
          
        debloatPreset -choice 'debloatAll' -excludedPackages $excludedPackages
        Write-Status -Message 'Removing Teams and One Drive' -Type Output
        debloat-TeamsOneDrive
        Write-Status -Message 'Removing Remote Desktop Connection' -Type Output
        debloat-remotedesktop
        debloat-HealthUpdateTools
        Write-Status -Message 'Uninstalling Edge...' -Type Output
        $edge = Search-File '*EdgeRemove.ps1'
        &$edge -Webview
        Write-Status -Message 'Cleaning Outdated Store Apps...' -Type Output
        Start-Process rundll32.exe -ArgumentList 'AppxDeploymentClient.dll, AppxCleanupOrphanPackages'
        Write-Status -Message 'Cleaning Start Menu...' -Type Output
        $unpin = Search-File '*unpin.ps1'
        & $unpin
      }
      if ($comboBoxPresets.SelectedIndex -eq 1) {
     
      
        debloatPreset -choice 'debloatKeepStoreXbox' -excludedPackages $excludedPackages
        Write-Status -Message 'Removing Teams and One Drive' -Type Output
        debloat-TeamsOneDrive
        debloat-HealthUpdateTools
        Write-Status -Message 'Removing Remote Desktop Connection' -Type Output
        debloat-remotedesktop
        Write-Status -Message 'Cleaning Outdated Store Apps...' -Type Output
        Start-Process rundll32.exe -ArgumentList 'AppxDeploymentClient.dll, AppxCleanupOrphanPackages'
        Write-Status -Message 'Cleaning Start Menu...' -Type Output
        $unpin = Search-File '*unpin.ps1'
        & $unpin
  
      }
      if ($comboBoxPresets.SelectedIndex -eq 2) {
  
     
        debloatPreset -choice 'debloatKeepStoreXbox' -excludedPackages $excludedPackages
        Write-Status -Message 'Removing Teams and One Drive' -Type Output
        debloat-TeamsOneDrive
        debloat-HealthUpdateTools
        Write-Status -Message 'Removing Remote Desktop Connection' -Type Output
        debloat-remotedesktop
        Write-Status -Message 'Uninstalling Edge...' -Type Output
        $edge = Search-File '*EdgeRemove.ps1'
        &$edge
        Write-Status -Message 'Cleaning Outdated Store Apps...' -Type Output
        Start-Process rundll32.exe -ArgumentList 'AppxDeploymentClient.dll, AppxCleanupOrphanPackages'
        Write-Status -Message 'Cleaning Start Menu...' -Type Output
        $unpin = Search-File '*unpin.ps1'
        & $unpin     
      
      }
      if ($comboBoxPresets.SelectedIndex -eq 3) {
        debloatPreset -choice 'debloatAll' -excludedPackages $excludedPackages
        Write-Status -Message 'Removing Teams and One Drive' -Type Output
        debloat-TeamsOneDrive
        Write-Status -Message 'Removing Remote Desktop Connection' -Type Output
        debloat-remotedesktop
        debloat-HealthUpdateTools
        Write-Status -Message 'Cleaning Outdated Store Apps...' -Type Output
        Start-Process rundll32.exe -ArgumentList 'AppxDeploymentClient.dll, AppxCleanupOrphanPackages'
        Write-Status -Message 'Cleaning Start Menu...' -Type Output
        $unpin = Search-File '*unpin.ps1'
        & $unpin
  
      }
      if ($comboBoxPresets.SelectedIndex -eq 4) { 
    
     
        debloatPreset -choice 'debloatKeepStore' -excludedPackages $excludedPackages
        Write-Status -Message 'Removing Teams and One Drive' -Type Output
        debloat-TeamsOneDrive
        debloat-HealthUpdateTools
        Write-Status -Message 'Removing Remote Desktop Connection' -Type Output
        debloat-remotedesktop
        Write-Status -Message 'Uninstalling Edge...' -Type Output
        $edge = Search-File '*EdgeRemove.ps1'
        &$edge
        Write-Status -Message 'Cleaning Outdated Store Apps...' -Type Output
        Start-Process rundll32.exe -ArgumentList 'AppxDeploymentClient.dll, AppxCleanupOrphanPackages'
        Write-Status -Message 'Cleaning Start Menu...' -Type Output
        $unpin = Search-File '*unpin.ps1'
        & $unpin
  
      }

    }
    


    #------------------------- debloat extras

    if ($extraEdge.Checked) {
      if ($extraWebview.Checked) {
        Write-Status -Message 'Uninstalling Edge && WebView...' -Type Output
        $edge = Search-File '*EdgeRemove.ps1'
        &$edge -Webview
      }
      else {
        Write-Status -Message 'Uninstalling Edge...' -Type Output
        $edge = Search-File '*EdgeRemove.ps1'
        &$edge
      }
    }

    if ($extraTeamsOneDrive.Checked) {
      Write-Status -Message 'Removing Teams and One Drive' -Type Output
      debloat-TeamsOneDrive
    }

    if ($extraUpdateTools.Checked) {
      Write-Status -Message 'Removing Windows Update Tools' -Type Output
      debloat-HealthUpdateTools
    }

    if ($extraRemoveRemote.Checked) {
      Write-Status -Message 'Removing Remote Desktop Connection' -Type Output
      debloat-remotedesktop
    }

    if ($extraStartMenu.Checked) {
      Write-Status -Message 'Cleaning Start Menu...' -Type Output
      $unpin = Search-File '*unpin.ps1'
      & $unpin
    }

    if ($extraCleanStoreApps.Checked) {
      Write-Status -Message 'Cleaning Outdated Store Apps...' -Type Output
      Start-Process rundll32.exe -ArgumentList 'AppxDeploymentClient.dll, AppxCleanupOrphanPackages'
    }

    if ($extraCBSApps.Checked) {
      Write-Status -Message 'Removing Windows Backup App and Get Started...' -Type Output
      Remove-CBS-Apps
    }

    if ($extraSpeech.Checked) {
      debloat-Win32Apps -appName speech
    }

    if ($extraLiveCap.Checked) {
      debloat-Win32Apps -appName livecaptions
    }
    
    if ($extraMagnifier.Checked) {
      debloat-Win32Apps -appName magnifier
    }

    if ($extraNarrator.Checked) {
      debloat-Win32Apps -appName Narrator
    }

    if ($extraOSK.Checked) {
      debloat-Win32Apps -appName osk
    }

    if ($extraVoice.Checked) {
      debloat-Win32Apps -appName voiceaccess
    }

    if ($extraSteps.Checked) {
      debloat-Win32Apps -appName stepsrecorder
    }

    if ($extraQuickAssist.Checked) {
      debloat-Win32Apps -appName QuickAssist
    }

    if ($extraMathInput.Checked) {
      debloat-Win32Apps -appName MathInput
    }

    if (!($Autorun)) {
      #replace message box
      Custom-MsgBox -message 'Bloat Removed!' -type None
    }
     
  }
}
Export-ModuleMember -Function debloat


function disable-services {
  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
    # ,[Parameter(mandatory=$false)] $setting 
  )



  if ($Autorun) {
    $msgBoxInput = 'OK'
  }
  else {
    $msgBoxInput = Custom-MsgBox -message 'Do you want to disable Bluetooth, Printing and others?' -type Question
  }
  
  
  switch ($msgBoxInput) {
  
    'OK' {
      if (!($Autorun)) {
        #update config
        update-config -setting 'disableServices' -value 1
      }
      
      #disables some unecessary services 
      Write-Status -Message 'Disabling Services...' -Type Output
      Write-Status -Message 'See Full List: [github.com/MP7BDO/mpware/blob/main/features.md#disable-services]' -Type Output   
       
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\BTAGService' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\BthAvctpSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\bthserv' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\BluetoothUserService' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\Fax' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\Spooler' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\PrintWorkflowUserSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\PrintNotify' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\shpamsvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\RemoteRegistry' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\PhoneSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\defragsvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\DoSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\RmSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\wisvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\TabletInputService' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\diagsvc' /v 'Start' /t REG_DWORD /d '4' /f
      $command = "Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\DPS' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\WdiServiceHost' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\WdiSystemHost' /v 'Start' /t REG_DWORD /d '4' /f"
      Run-Trusted -command $command
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\AssignedAccessManagerSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\MapsBroker' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\lfsvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\Netlogon' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\WpcMonSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\SCardSvr' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\ScDeviceEnum' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\SCPolicySvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\WbioSrvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\WalletService' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\whesvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\wuqisvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\WSAIFabricSvc' /v 'Start' /t REG_DWORD /d '4' /f 

  
      if (!($Autorun)) {
        Custom-MsgBox -message 'Services Disabled!' -type None
      }
  
    }
  
    'Cancel' {}
  
  }
  
}
Export-ModuleMember -Function disable-services








function gpTweaks {

  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
    , [Parameter(mandatory = $false)] [bool]$gpUpdates = $false
    , [Parameter(mandatory = $false)] [bool]$gpTel = $false
  )




  $checkbox1 = New-Object System.Windows.Forms.CheckBox
  $checkbox2 = New-Object System.Windows.Forms.CheckBox
  $checkbox3 = New-Object System.Windows.Forms.CheckBox
  

 
  #hashtable to loop through
  $settings = @{}
  $settings['gpUpdates'] = $checkbox1
  $settings['gpTel'] = $checkbox3


  if ($Autorun) {
    $result = [System.Windows.Forms.DialogResult]::OK
    $checkbox1.Checked = $gpUpdates
    $checkbox2.Checked = $false
    $checkbox3.Checked = $gpTel
  }
  else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.Application]::EnableVisualStyles()

    # Create the form
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Group Policy Tweaks'
    $form.Size = New-Object System.Drawing.Size(300, 170)
    $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $form.MaximizeBox = $false
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
    $form.BackColor = 'Black'
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 8)

    $url = 'https://github.com/MP7BDO/mpware/blob/main/features.md#group-policy-tweaks'
    $infobutton = New-Object System.Windows.Forms.Button
    $infobutton.Location = New-Object System.Drawing.Point(255, 7)  
    $infobutton.Size = New-Object System.Drawing.Size(30, 27)
    $infobutton.Cursor = 'Hand'
    $infobutton.Add_Click({
        try {
          Start-Process $url -ErrorAction Stop
        }
        catch {
          Write-Status -Message 'No Internet Connected...' -Type Error
        }
      })
    $infobutton.BackColor = [System.Drawing.Color]::Transparent
    $image = [System.Drawing.Image]::FromFile('C:\Windows\System32\SecurityAndMaintenance.png')
    $resizedImage = New-Object System.Drawing.Bitmap $image, 24, 25
    $infobutton.Image = $resizedImage
    $infobutton.ImageAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $infobutton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $infobutton.FlatAppearance.BorderSize = 0
    $infobutton.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::Transparent
    $infobutton.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::Transparent
    $form.Controls.Add($infobutton)

    $resetCheckedBttn = New-Object Windows.Forms.Button
    $resetCheckedBttn.Location = New-Object Drawing.Point(225, 7) # Adjusted to bottom-left of sidebar
    $resetCheckedBttn.Size = New-Object Drawing.Size(30, 27)
    $resetCheckedBttn.Cursor = 'Hand'
    $resetCheckedBttn.Add_Click({
        $Global:enabledOptions = @()
        function Get-AllControls($parent) {
          foreach ($control in $parent.Controls) {
            $control
            if ($control.Controls.Count -gt 0) {
              Get-AllControls $control
            }
          }
        }
        Get-AllControls $form | Where-Object { $_ -is [System.Windows.Forms.CheckBox] } | ForEach-Object { 
          $_.Checked = $false 
          $_.ForeColor = 'White'
        }
        
      })
    $resetCheckedBttn.BackColor = [System.Drawing.Color]::Transparent
    $resetCheckedBttn.Text = 'X'
    $resetCheckedBttn.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $resetCheckedBttn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $resetCheckedBttn.FlatAppearance.BorderSize = 0
    $resetCheckedBttn.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::Transparent
    $resetCheckedBttn.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::Transparent
    $form.Controls.Add($resetCheckedBttn)

    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($resetCheckedBttn, 'Reset currently checked tweaks')

    $type = $form.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($form, $true, $null)

    $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
    $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

    # Override the form's paint event to apply the gradient
    $form.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $form.Width, $form.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })
    
    # Create the checkboxes
    
    $checkbox1.Text = 'Disable Updates'
    $checkbox1.Location = New-Object System.Drawing.Point(20, 20)
    $checkbox1.ForeColor = 'White'
    $checkbox1.BackColor = [System.Drawing.Color]::Transparent
    $checkbox1.AutoSize = $true
    $form.Controls.Add($checkbox1)
    
    $checkbox3.Text = 'Disable Telemetry'
    $checkbox3.Location = New-Object System.Drawing.Point(20, 50)
    $checkbox3.ForeColor = 'White'
    $checkbox3.BackColor = [System.Drawing.Color]::Transparent
    $checkbox3.AutoSize = $true
    $form.Controls.Add($checkbox3)

    foreach ($setting in $settings.GetEnumerator()) {
      if ($Global:enabledOptions -contains $setting.key) {
        $setting.value.ForeColor = [System.Drawing.Color]::Gray
        $setting.value.checked = $true
      }
    }

    
    
    $OKButton = Create-ModernButton -Text 'OK' -Location (New-Object Drawing.Point(70, 100)) -Size (New-Object Drawing.Size(75, 25)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2
    $form.Controls.Add($OKButton)
    $CancelButton = Create-ModernButton -Text 'Cancel' -Location (New-Object Drawing.Point(150, 100)) -Size (New-Object Drawing.Size(75, 25)) -DialogResult ([System.Windows.Forms.DialogResult]::Cancel) -borderSize 2
    $form.Controls.Add($CancelButton)

    
    
    # Show the form and wait for user input
    $result = $form.ShowDialog()
  }
  
  
  # Check the selected checkboxes
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    
    if (!($Autorun)) {
      #loop through checkbox hashtable to update config
      $settings.GetEnumerator() | ForEach-Object {
            
        $settingName = $_.Key
        $checkbox = $_.Value
        #dont update config with options already checked
        if ($Global:enabledOptions -contains $settingName) {
          $checkbox.Checked = $false
        }
        
        if ($checkbox.Checked) {
          update-config -setting $settingName -value 1
        }
      }
    }

    if ($checkbox1.Checked) {
      Write-Status -Message 'Disabling Updates...' -Type Output
      #disables updates through gp edit and servives
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'WUServer' /t REG_SZ /d 'https://DoNotUpdateWindows10.com/' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'WUStatusServer' /t REG_SZ /d 'https://DoNotUpdateWindows10.com/' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'UpdateServiceUrlAlternate' /t REG_SZ /d 'https://DoNotUpdateWindows10.com/' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'SetProxyBehaviorForUpdateDetection' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'SetDisableUXWUAccess' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DoNotConnectToWindowsUpdateInternetLocations' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'ExcludeWUDriversInQualityUpdate' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' /v 'NoAutoUpdate' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' /v 'UseWUServer' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\UsoSvc' /v 'Start' /t REG_DWORD /d '4' /f 
      Reg.exe add 'HKU\S-1-5-20\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings' /v 'DownloadMode' /t REG_DWORD /d '0' /f
      Disable-ScheduledTask -TaskName 'Microsoft\Windows\WindowsUpdate\Scheduled Start' -Erroraction SilentlyContinue
      
   
  
    }
  
  
    if ($checkbox3.Checked) {
      Write-Status -Message 'Disabling Telemetry...' -Type Output
      #removes telemetry through gp edit
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection' /v 'AllowTelemetry' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer' /v 'DisableGraphRecentItems' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' /v 'AllowClipboardHistory' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' /v 'AllowCrossDeviceClipboard' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' /v 'EnableActivityFeed' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' /v 'PublishUserActivities' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' /v 'UploadUserActivities' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo' /v 'Enabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo' /v 'DisabledByGroupPolicy' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting' /v 'DontSendAdditionalData' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection' /v 'AllowDeviceNameInTelemetry' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent' /v 'DisableCloudOptimizedContent' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent' /v 'DisableWindowsConsumerFeatures' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent' /v 'DisableTailoredExperiencesWithDiagnosticData' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' /v 'AllowTelemetry' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' /v 'MaxTelemetryAllowed' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\DiagTrack' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\System\ControlSet001\Services\dmwappushservice' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\System\ControlSet001\Control\WMI\Autologger\Diagtrack-Listener' /v 'Start' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\Software\Policies\Microsoft\Biometrics' /v 'Enabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\AppV\CEIP' /v 'CEIPEnable' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\SQMClient\Windows' /v 'CEIPEnable' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\Control Panel\International\User Profile' /v 'HttpAcceptLanguageOptOut' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CPSS\DevicePolicy\AllowTelemetry' /v 'DefaultValue' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\CPSS\Store\AllowTelemetry' /v 'Value' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\Software\Policies\Microsoft\Windows\DataCollection' /v 'AllowCommercialDataPipeline' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\Software\Policies\Microsoft\Windows\DataCollection' /v 'LimitEnhancedDiagnosticDataWindowsAnalytics' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Privacy' /v 'TailoredExperiencesWithDiagnosticDataEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\TextInput' /v 'AllowLinguisticDataCollection' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Personalization\Settings' /v 'AcceptedPrivacyPolicy' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Bluetooth' /v 'AllowAdvertising' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\System' /v 'AllowExperimentation' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\PolicyManager\default\Wifi\AllowAutoConnectToWiFiSenseHotspots' /v 'value' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\PolicyManager\default\Wifi\AllowWiFiHotSpotReporting' /v 'value' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\config' /v 'AutoConnectAllowedOEM' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\WMDRM' /v 'DisableOnline' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat' /v 'AITEnable' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat' /v 'DisableInventory' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat' /v 'DisablePCA' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat' /v 'DisablePcaRecording' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat' /v 'DisableScriptedDiagnosticLogging' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\AppCompat' /v 'DisableUAR' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\StorPort' /v 'TelemetryDeviceHealthEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\StorPort' /v 'TelemetryErrorDataEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\StorPort' /v 'TelemetryPerformanceEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\whesvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\wuqisvc' /v 'Start' /t REG_DWORD /d '4' /f
      #disable and remove connected devices platform 
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\CDPSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\CDPUserSvc' /v 'Start' /t REG_DWORD /d '4' /f
      Stop-Service CDPSvc -Force -ErrorAction SilentlyContinue
      Get-Service 'CDPUserSvc_*' -ErrorAction SilentlyContinue | Stop-Service -Force -ErrorAction SilentlyContinue
      Remove-Item -Path "$env:LOCALAPPDATA\ConnectedDevicesPlatform" -Recurse -Force -ErrorAction SilentlyContinue


      #block telemetry domains https://learn.microsoft.com/en-us/windows/privacy/configure-windows-diagnostic-data-in-your-organization
      #also extracted using https://github.com/MP7BDO/mpware
      $domains = @(
        'v10.events.data.microsoft.com'
        'v10c.events.data.microsoft.com'
        'v10.vortex-win.data.microsoft.com'
        'watson.telemetry.microsoft.com'
        'umwatsonc.events.data.microsoft.com'
        'ceuswatcab01.blob.core.windows.net'
        'ceuswatcab02.blob.core.windows.net'
        'eaus2watcab01.blob.core.windows.net'
        'eaus2watcab02.blob.core.windows.net'
        'weus2watcab01.blob.core.windows.net'
        'weus2watcab02.blob.core.windows.net'
        'oca.telemetry.microsoft.com'
        'oca.microsoft.com'
        'kmwatsonc.events.data.microsoft.com'
        'au.vortex-win.data.microsoft.com'
        'au-v10.events.data.microsoft.com'
        'au-v20.events.data.microsoft.com'
        'eu-v10.events.data.microsoft.com'
        'eu-v20.events.data.microsoft.com'
        'in-v10.events.data.microsoft.com'
        'in-v20.events.data.microsoft.com'
        'jp-v10.events.data.microsoft.com'
        'jp-v20.events.data.microsoft.com'
        'uk.vortex-win.data.microsoft.com'
        'uk-v20.events.data.microsoft.com'
        'us4-v20.events.data.microsoft.com'
        'us5-v20.events.data.microsoft.com'
        'us-v10.events.data.microsoft.com'
        'us-v20.events.data.microsoft.com'
        'v20.events.data.microsoft.com'
      )

      $hostsPath = "$env:SystemRoot\System32\drivers\etc\hosts"

      function Get-LockingProcesses {
        param([string]$FilePath)

        $script = @'
using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;

public class RmHelper {
    [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)]
    public static extern int RmStartSession(out uint pSessionHandle, int dwSessionFlags, string strSessionKey);
    [DllImport("rstrtmgr.dll")]
    public static extern int RmEndSession(uint pSessionHandle);
    [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)]
    public static extern int RmRegisterResources(uint pSessionHandle, uint nFiles, string[] rgsFilenames, uint nApplications, [In] RM_UNIQUE_PROCESS[] rgApplications, uint nServices, string[] rgsServiceNames);
    [DllImport("rstrtmgr.dll")]
    public static extern int RmGetList(uint dwSessionHandle, out uint pnProcInfoNeeded, ref uint pnProcInfo, [In, Out] RM_PROCESS_INFO[] rgAffectedApps, ref uint lpdwRebootReasons);

    [StructLayout(LayoutKind.Sequential)]
    public struct RM_UNIQUE_PROCESS { public int dwProcessId; public System.Runtime.InteropServices.ComTypes.FILETIME ProcessStartTime; }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct RM_PROCESS_INFO {
        public RM_UNIQUE_PROCESS Process;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string strAppName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]  public string strServiceShortName;
        public int ApplicationType; public uint AppStatus; public int TSSessionId;
        [MarshalAs(UnmanagedType.Bool)] public bool bRestartable;
    }

    public static List<int> GetLockingPids(string path) {
        var pids = new List<int>();
        uint session; string key = Guid.NewGuid().ToString();
        if (RmStartSession(out session, 0, key) != 0) return pids;
        try {
            RmRegisterResources(session, 1, new[] { path }, 0, null, 0, null);
            uint needed = 0, count = 0, reasons = 0;
            RmGetList(session, out needed, ref count, null, ref reasons);
            if (needed > 0) {
                var procs = new RM_PROCESS_INFO[needed]; count = needed;
                RmGetList(session, out needed, ref count, procs, ref reasons);
                foreach (var p in procs) pids.Add(p.Process.dwProcessId);
            }
        } finally { RmEndSession(session); }
        return pids;
    }
}
'@
        Add-Type -TypeDefinition $script
        $pids = [RmHelper]::GetLockingPids($FilePath)
        $pids | ForEach-Object { Get-Process -Id $_ -ErrorAction SilentlyContinue }
        return $pids
      }

      

      foreach ($domain in $domains) {
        Get-LockingProcesses -FilePath $hostsPath | Stop-Process -Force 
        try {
          Add-Content $hostsPath -Value "0.0.0.0 $domain" -Force -ErrorAction Stop
        }
        catch {
          $locked = $true
          break
          #try {
          #  [System.IO.File]::AppendAllText($hostsPath, "0.0.0.0 $domain")
          #}
          #catch {
          #  Write-Status -Message 'Unable to Add Telemetry Domains to Hosts File...' -Type Error
          #  Write-Status -Message 'Please Run This Tweak Again After Restarting the PC..' -Type Error
          #}
          
        }
        
      }
      if ($locked) {
        Copy-Item $hostsPath -Destination $tempDir -Force
        foreach ($domain in $domains) {
          Add-Content "$tempDir\hosts" -Value "0.0.0.0 $domain" -Force
        }
        Remove-Item $hostsPath -force
        Move-Item "$tempDir\hosts" -Destination $(Split-Path $hostsPath -Parent) -Force

      }


      #disable all the loggers under diag track
      $subkeys = Get-ChildItem -Path 'HKLM:\System\ControlSet001\Control\WMI\Autologger\Diagtrack-Listener'
      foreach ($subkey in $subkeys) {
        Set-ItemProperty -Path "registry::$($subkey.Name)" -Name 'Enabled' -Value 0 -Force
      }
 
      Disable-ScheduledTask -TaskName 'Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser' -ErrorAction SilentlyContinue
      Disable-ScheduledTask -TaskName 'Microsoft\Windows\Application Experience\ProgramDataUpdater' -ErrorAction SilentlyContinue
      Disable-ScheduledTask -TaskName 'Microsoft\Windows\Autochk\Proxy' -ErrorAction SilentlyContinue
      Disable-ScheduledTask -TaskName 'Microsoft\Windows\Customer Experience Improvement Program\Consolidator' -ErrorAction SilentlyContinue
      Disable-ScheduledTask -TaskName 'Microsoft\Windows\Customer Experience Improvement Program\UsbCeip' -ErrorAction SilentlyContinue
      Disable-ScheduledTask -TaskName 'Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector' -ErrorAction SilentlyContinue
  
    

    }
  
  
    #updates group policy so that the previous changes are applied 
    Write-Status -Message 'Updating Policy...' -Type Output
    gpupdate /force
  }
  
}
Export-ModuleMember -Function gpTweaks





function import-powerplan {

  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
    , [Parameter(mandatory = $false)] [bool]$importPPlan = $false
    , [Parameter(mandatory = $false)] [bool]$enableUltimate = $false
    , [Parameter(mandatory = $false)] [bool]$enableMaxOverlay = $false 
    , [Parameter(mandatory = $false)] [bool]$enableHighOverlay = $false 
    , [Parameter(mandatory = $false)] [bool]$removeallPlans = $false
    , [Parameter(mandatory = $false)] [bool]$importPPlanAMD = $false
  )
      
  
  $checkbox1 = New-Object System.Windows.Forms.CheckBox
  $checkbox2 = New-Object System.Windows.Forms.CheckBox
  $checkbox3 = New-Object System.Windows.Forms.CheckBox
  $checkboxALL = New-Object System.Windows.Forms.CheckBox
  $checkboxCustomPlan1 = New-Object System.Windows.Forms.CheckBox
  $checkboxCustomPlan2 = New-Object System.Windows.Forms.CheckBox

    
  #hashtable to loop through
  $settings = @{}
  $settings['enableUltimate'] = $checkbox1
  $settings['enableMaxOverlay'] = $checkbox2
  $settings['enableHighOverlay'] = $checkbox3
  $settings['removeallPlans'] = $checkboxALL

  if ($Autorun) {
    $checkboxCustomPlan1.Checked = $importPPlan
    $checkboxCustomPlan2.Checked = $importPPlanAMD
    $result = [System.Windows.Forms.DialogResult]::OK
    $checkbox1.Checked = $enableUltimate
    $checkbox2.Checked = $enableMaxOverlay
    $checkbox3.Checked = $enableHighOverlay
    $checkboxALL.Checked = $removeallPlans
  }
  else {
    
    $Global:output = powercfg /l
    $powerplanNames = @()
    foreach ($line in $output) {
      if ($line -match ':') {
        $start = $line.trim().IndexOf('(') + 1
        $end = $line.trim().IndexOf(')')
        $length = $end - $start
        try {
          $powerplanNames += $line.trim().Substring($start, $length)
        }
        catch {}
        
      }
    }
   
    
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    # Create the form
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Power Tweaks'
    $form.Size = New-Object System.Drawing.Size(750, 550) 
    $form.StartPosition = 'CenterScreen'
    $form.BackColor = 'Black'
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 8)

    # Sidebar Panel
    $sidebarPanel = New-Object System.Windows.Forms.Panel
    $sidebarPanel.Location = New-Object System.Drawing.Point(0, 0)
    $sidebarPanel.Size = New-Object System.Drawing.Size(150, $form.ClientSize.Height)
    $sidebarPanel.BackColor = 'Black'
    $form.Controls.Add($sidebarPanel)

    # Sidebar Buttons

    $powerPlanBtn = Create-ModernButton -Text 'Power Plan' -Location (New-Object System.Drawing.Point(20, 10)) -Size (New-Object System.Drawing.Size(130, 40)) -ClickAction {
      $powerPlanPanel.Visible = $true
      $usbPowerPanel.Visible = $false
      $powerPlanPanel.controls.add($OKButton)
      $powerPlanPanel.controls.add($CancelButton)
      $powerPlanBtn.Tag = 'Active'
      $usbPowerBtn.Tag = 'Inactive'
      $powerPlanBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $usbPowerBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)   
      
    } -r 47 -g 49 -b 58 
    <#
    $powerPlanBtn = New-Object System.Windows.Forms.Button
    $powerPlanBtn.Location = New-Object System.Drawing.Point(10, 10)
    $powerPlanBtn.Size = New-Object System.Drawing.Size(130, 40)
    $powerPlanBtn.Text = 'Power Plan'
    $powerPlanBtn.ForeColor = 'White'
    $powerPlanBtn.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51)
    $powerPlanBtn.FlatAppearance.BorderSize = 0
    $powerPlanBtn.FlatStyle = [System.Windows.Forms.FlatStyle]::Standard
    $powerPlanBtn.Tag = 'Active' 
    $powerPlanBtn.Add_MouseEnter({ $this.BackColor = [System.Drawing.Color]::FromArgb(90, 90, 90) })
    $powerPlanBtn.Add_MouseLeave({
        if ($this.Tag -eq 'Active') { $this.BackColor = [System.Drawing.Color]::FromArgb(74, 74, 74) }
        else { $this.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51) }
      })
      #>
    $sidebarPanel.Controls.Add($powerPlanBtn)

    $usbPowerBtn = Create-ModernButton -Text 'USB Power' -Location (New-Object System.Drawing.Point(20, 60)) -Size (New-Object System.Drawing.Size(130, 40)) -ClickAction {
      $powerPlanPanel.Visible = $false
      $usbPowerPanel.Visible = $true
      $usbPowerPanel.controls.add($OKButton)
      $usbPowerPanel.controls.add($CancelButton)
      $usbPowerBtn.Tag = 'Active'
      $powerPlanBtn.Tag = 'Inactive'
      $usbPowerBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $powerPlanBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)   
    } -r 47 -g 49 -b 58 
    <#
    $usbPowerBtn = New-Object System.Windows.Forms.Button
    $usbPowerBtn.Location = New-Object System.Drawing.Point(10, 60)
    $usbPowerBtn.Size = New-Object System.Drawing.Size(130, 40)
    $usbPowerBtn.Text = 'USB Power'
    $usbPowerBtn.ForeColor = 'White'
    $usbPowerBtn.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51)
    $usbPowerBtn.FlatAppearance.BorderSize = 0
    $usbPowerBtn.FlatStyle = [System.Windows.Forms.FlatStyle]::Standard
    $usbPowerBtn.Tag = 'Inactive' 
    $usbPowerBtn.Add_MouseEnter({ $this.BackColor = [System.Drawing.Color]::FromArgb(90, 90, 90) })
    $usbPowerBtn.Add_MouseLeave({
        if ($this.Tag -eq 'Active') { $this.BackColor = [System.Drawing.Color]::FromArgb(74, 74, 74) }
        else { $this.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51) }
      })
      #>
    $sidebarPanel.Controls.Add($usbPowerBtn)

    # Info Button in Sidebar
    $url = 'https://github.com/MP7BDO/mpware/blob/main/features.md#import-and-remove-power-plans'
    $infobutton = New-Object System.Windows.Forms.Button
    $infobutton.Location = New-Object System.Drawing.Point(5, 480)  
    $infobutton.Size = New-Object System.Drawing.Size(30, 27)
    $infobutton.Cursor = 'Hand'
    $infobutton.Add_Click({
        try {
          Start-Process $url -ErrorAction Stop
        }
        catch {
          Write-Status -Message 'No Internet Connected...' -Type Error
        }
      })
    $infobutton.BackColor = [System.Drawing.Color]::Transparent
    $image = [System.Drawing.Image]::FromFile('C:\Windows\System32\SecurityAndMaintenance.png')
    $resizedImage = New-Object System.Drawing.Bitmap $image, 24, 25
    $infobutton.Image = $resizedImage
    $infobutton.ImageAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $infobutton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $infobutton.FlatAppearance.BorderSize = 0
    $infobutton.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::Transparent
    $infobutton.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::Transparent
    $sidebarPanel.Controls.Add($infobutton)

    $resetCheckedBttn = New-Object Windows.Forms.Button
    $resetCheckedBttn.Location = New-Object Drawing.Point(45, 480) # Adjusted to bottom-left of sidebar
    $resetCheckedBttn.Size = New-Object Drawing.Size(30, 27)
    $resetCheckedBttn.Cursor = 'Hand'
    $resetCheckedBttn.Add_Click({
        $Global:enabledOptions = @()
        function Get-AllControls($parent) {
          foreach ($control in $parent.Controls) {
            $control
            if ($control.Controls.Count -gt 0) {
              Get-AllControls $control
            }
          }
        }
        Get-AllControls $form | Where-Object { $_ -is [System.Windows.Forms.CheckBox] } | ForEach-Object { 
          $_.Checked = $false 
          $_.ForeColor = 'White'
        }
        
      })
    $resetCheckedBttn.BackColor = 'Black'
    $resetCheckedBttn.Text = 'X'
    $resetCheckedBttn.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $resetCheckedBttn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $resetCheckedBttn.FlatAppearance.BorderSize = 0
    $sidebarPanel.Controls.Add($resetCheckedBttn)

    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($resetCheckedBttn, 'Reset currently checked tweaks')

    # Main Content Panel
    $contentPanel = New-Object System.Windows.Forms.Panel
    $contentPanel.Location = New-Object System.Drawing.Point(165, 0)
    $contentPanel.Size = New-Object System.Drawing.Size(570, 550)  
    $form.Controls.Add($contentPanel)

    # Power Plan Panel
    $powerPlanPanel = New-Object System.Windows.Forms.Panel
    $powerPlanPanel.Location = New-Object System.Drawing.Point(0, 0)
    $powerPlanPanel.Size = New-Object System.Drawing.Size(570, 550) 
    $powerPlanPanel.Visible = $true
    $contentPanel.Controls.Add($powerPlanPanel)

    $type = $powerPlanPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($powerPlanPanel, $true, $null)

    $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
    $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

    # Override the form's paint event to apply the gradient
    $powerPlanPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $powerPlanPanel.Width, $powerPlanPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })


    # USB Power Panel
    $usbPowerPanel = New-Object System.Windows.Forms.Panel
    $usbPowerPanel.Location = New-Object System.Drawing.Point(0, 0)
    $usbPowerPanel.Size = New-Object System.Drawing.Size(570, 550)  
    $usbPowerPanel.Visible = $false
    $contentPanel.Controls.Add($usbPowerPanel)

    $type = $usbPowerPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($usbPowerPanel, $true, $null)

    $usbPowerPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $usbPowerPanel.Width, $usbPowerPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })


    # Labels for Power Plan Panel
    $labelPowerPlan = New-Object System.Windows.Forms.Label
    $labelPowerPlan.Text = 'Power Plan'
    $labelPowerPlan.Location = New-Object System.Drawing.Point(10, 10)
    $labelPowerPlan.Size = New-Object System.Drawing.Size(200, 20)
    $labelPowerPlan.ForeColor = 'White'
    $labelPowerPlan.BackColor = [System.Drawing.Color]::Transparent
    $labelPowerPlan.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $powerPlanPanel.Controls.Add($labelPowerPlan)

    $lineStartPoint = New-Object System.Drawing.Point(5, 35)
    $lineEndPoint = New-Object System.Drawing.Point(250, 35)
    $lineColor = [System.Drawing.Color]::White
    $lineWidth = 1.5

    $powerPlanPanel.Add_Paint({
        $graphics = $powerPlanPanel.CreateGraphics()
        $pen = New-Object System.Drawing.Pen($lineColor, $lineWidth)
        $graphics.DrawLine($pen, $lineStartPoint, $lineEndPoint)
        $pen.Dispose()
        $graphics.Dispose()
      })

    $labelRemovePower = New-Object System.Windows.Forms.Label
    $labelRemovePower.Text = 'Remove Power Plans:'
    $labelRemovePower.Location = New-Object System.Drawing.Point(10, 50)
    $labelRemovePower.Size = New-Object System.Drawing.Size(200, 20)
    $labelRemovePower.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $labelRemovePower.ForeColor = 'White'
    $labelRemovePower.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($labelRemovePower)

    $labelHidden = New-Object System.Windows.Forms.Label
    $labelHidden.Text = 'Enable Hidden Power Plans:'
    $labelHidden.Location = New-Object System.Drawing.Point(260, 50)
    $labelHidden.Size = New-Object System.Drawing.Size(250, 20)
    $labelHidden.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $labelHidden.ForeColor = 'White'
    $labelHidden.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($labelHidden)

    $labelCustom = New-Object System.Windows.Forms.Label
    $labelCustom.Text = 'Import Custom Plans:'
    $labelCustom.Location = New-Object System.Drawing.Point(10, 290)
    $labelCustom.Size = New-Object System.Drawing.Size(250, 20)
    $labelCustom.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $labelCustom.ForeColor = 'White'
    $labelCustom.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($labelCustom)

  
    $checkboxCustomPlan1.Text = "mpware Ultimate Performance"
    $checkboxCustomPlan1.Location = New-Object System.Drawing.Point(10, 320)
    $checkboxCustomPlan1.Size = New-Object System.Drawing.Size(200, 20)
    if ($Global:enabledOptions -contains 'usePowerPlan') {
      $checkboxCustomPlan1.ForeColor = [System.Drawing.Color]::Gray
      $checkboxCustomPlan1.Checked = $true
    }
    else {
      $checkboxCustomPlan1.ForeColor = 'White'
      $checkboxCustomPlan1.Checked = $false
    }
    $checkboxCustomPlan1.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($checkboxCustomPlan1)

    $tooltip1 = New-Object System.Windows.Forms.ToolTip
    $tooltip1.SetToolTip($checkboxCustomPlan1, 'Provides Optimal Performance for All CPUs with All Power Saving Features Disabled')
    
    $checkboxCustomPlan2 = New-Object System.Windows.Forms.CheckBox
    $checkboxCustomPlan2.Text = "mpware Ultimate Performance (AMD)"
    $checkboxCustomPlan2.Location = New-Object System.Drawing.Point(10, 350)
    $checkboxCustomPlan2.Size = New-Object System.Drawing.Size(200, 20)
    if ($Global:enabledOptions -contains 'usePowerPlanAMD') {
      $checkboxCustomPlan2.ForeColor = [System.Drawing.Color]::Gray
      $checkboxCustomPlan2.Checked = $true
    }
    else {
      $checkboxCustomPlan2.ForeColor = 'White'
      $checkboxCustomPlan2.Checked = $false
    }
    $checkboxCustomPlan2.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($checkboxCustomPlan2)

    $tooltip2 = New-Object System.Windows.Forms.ToolTip
    $tooltip2.SetToolTip($checkboxCustomPlan2, 'AMD-focused Ultimate Performance power profile')
   
    $labelCustom2 = New-Object System.Windows.Forms.Label
    $labelCustom2.Text = 'Import Your Own Plan:'
    $labelCustom2.Location = New-Object System.Drawing.Point(260, 290)
    $labelCustom2.Size = New-Object System.Drawing.Size(250, 20)
    $labelCustom2.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $labelCustom2.ForeColor = 'White'
    $labelCustom2.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($labelCustom2)

    $powerTextbox = New-Object System.Windows.Forms.TextBox
    $powerTextbox.Location = New-Object System.Drawing.Point(260, 320)
    $powerTextbox.Size = New-Object System.Drawing.Size(250, 20)
    $powerTextbox.Text = $null
    $powerPlanPanel.Controls.Add($powerTextbox)

    $filebrowsebttn = New-Object System.Windows.Forms.Button
    $filebrowsebttn.Location = New-Object System.Drawing.Point(515, 320)
    $filebrowsebttn.Size = New-Object System.Drawing.Size(40, 20)
    $filebrowsebttn.Text = '...'
    $filebrowsebttn.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $filebrowsebttn.BackColor = [System.Drawing.Color]::FromArgb(25, 25, 25)
    $filebrowsebttn.ForeColor = [System.Drawing.Color]::White
    $filebrowsebttn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $filebrowsebttn.FlatAppearance.BorderSize = 1
    #$filebrowsebttn.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(62, 62, 64)
    #$filebrowsebttn.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(27, 27, 28)
    $filebrowsebttn.Add_Click({    
        $selectedPowFile = Show-ModernFilePicker -Mode File -fileType pow
        if ($selectedPowFile) {
          $powerTextbox.Text = $selectedPowFile 
        }
        
      })
    $powerPlanPanel.Controls.Add($filebrowsebttn)

    # Labels for USB Power Panel
    $labelUSBPower = New-Object System.Windows.Forms.Label
    $labelUSBPower.Text = 'USB Power'
    $labelUSBPower.Location = New-Object System.Drawing.Point(10, 10)
    $labelUSBPower.Size = New-Object System.Drawing.Size(200, 20)
    $labelUSBPower.ForeColor = 'White'
    $labelUSBPower.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $labelUSBPower.BackColor = [System.Drawing.Color]::Transparent
    $usbPowerPanel.Controls.Add($labelUSBPower)

    $lineStartPoint = New-Object System.Drawing.Point(5, 35)
    $lineEndPoint = New-Object System.Drawing.Point(250, 35)
    $lineColor = [System.Drawing.Color]::White
    $lineWidth = 1.5

    $usbPowerPanel.Add_Paint({
        $graphics = $usbPowerPanel.CreateGraphics()
        $pen = New-Object System.Drawing.Pen($lineColor, $lineWidth)
        $graphics.DrawLine($pen, $lineStartPoint, $lineEndPoint)
        $pen.Dispose()
        $graphics.Dispose()
      })

    $labelDisablePowerSaving = New-Object System.Windows.Forms.Label
    $labelDisablePowerSaving.Text = 'Disable Power Saving:'
    $labelDisablePowerSaving.Location = New-Object System.Drawing.Point(10, 50)
    $labelDisablePowerSaving.Size = New-Object System.Drawing.Size(200, 20)
    $labelDisablePowerSaving.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $labelDisablePowerSaving.ForeColor = 'White'
    $labelDisablePowerSaving.BackColor = [System.Drawing.Color]::Transparent
    $usbPowerPanel.Controls.Add($labelDisablePowerSaving)

    $checkedListBox = New-Object System.Windows.Forms.CheckedListBox
    $checkedListBox.Size = New-Object System.Drawing.Size(230, 150)  
    $checkedListBox.BackColor = 'Black'
    $checkedListBox.ForeColor = 'White'
    $checkedListBox.CheckOnClick = $true
    $checkedListBox.Location = New-Object System.Drawing.Point(10, 70)
    $powerPlanPanel.Controls.Add($checkedListBox)
    
    foreach ($name in $powerplanNames) {
      [void]$checkedListBox.Items.Add($name)
    }

    $checkboxALL.Text = 'Check All'
    $checkboxALL.Location = New-Object System.Drawing.Point(10, 220)  
    $checkboxALL.Size = New-Object System.Drawing.Size(100, 20)
    $checkboxALL.ForeColor = 'White'
    $checkboxALL.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($checkboxALL)

    $checkboxALL.Add_CheckedChanged({
        $total = $checkedListBox.Items.Count
        $index = 0
        if ($checkboxALL.Checked) {
          for ($index = 0; $index -lt $total; $index++) {
            $checkedListBox.SetItemChecked($index, $true)
          }
        }
        else {
          for ($index = 0; $index -lt $total; $index++) {
            $checkedListBox.SetItemChecked($index, $false)
          }
        }
      })

    $checkboxRestore = New-Object System.Windows.Forms.CheckBox
    $checkboxRestore.Text = 'Restore Default'
    $checkboxRestore.Location = New-Object System.Drawing.Point(120, 220)  
    $checkboxRestore.Size = New-Object System.Drawing.Size(125, 20)
    $checkboxRestore.ForeColor = 'White'
    $checkboxRestore.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($checkboxRestore)

    # Enable Hidden Power Plans Checkboxes
    $checkbox1.Text = 'Ultimate Performance'
    $checkbox1.Location = New-Object System.Drawing.Point(260, 80)
    $checkbox1.Size = New-Object System.Drawing.Size(200, 20)
    $checkbox1.ForeColor = 'White'
    $checkbox1.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($checkbox1)

    $checkbox2.Text = 'Max Performance Overlay'
    $checkbox2.Location = New-Object System.Drawing.Point(260, 110)
    $checkbox2.Size = New-Object System.Drawing.Size(200, 20)
    $checkbox2.ForeColor = 'White'
    $checkbox2.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($checkbox2)

    $checkbox3.Text = 'High Performance Overlay'
    $checkbox3.Location = New-Object System.Drawing.Point(260, 140)
    $checkbox3.Size = New-Object System.Drawing.Size(200, 20)
    $checkbox3.ForeColor = 'White'
    $checkbox3.BackColor = [System.Drawing.Color]::Transparent
    $powerPlanPanel.Controls.Add($checkbox3)

    $treeView = New-Object System.Windows.Forms.TreeView
    $treeView.CheckBoxes = $true
    $treeView.Location = New-Object System.Drawing.Point(10, 70)
    $treeView.Size = New-Object System.Drawing.Size(540, 350)  
    $treeView.Scrollable = $true
    $treeView.BackColor = 'Black'
    $treeView.ForeColor = [System.Drawing.Color]::White
    $usbPowerPanel.Controls.Add($treeView)

    # Populate TreeView with USB Devices
    Write-Status -Message 'Getting USB Devices...' -Type Output
    $usbDevices = Get-PnpDevice -Class USB | Where-Object { $_.Status -ne 'Unknown' } | ForEach-Object {
      [PSCustomObject]@{
        Name       = $_.FriendlyName
        InstanceId = $_.InstanceId
        Parent     = (Get-PnpDeviceProperty -InstanceId $_.InstanceId -KeyName DEVPKEY_Device_Parent).Data
      }
    }

    $controllers = $usbDevices | Where-Object { $_.Name -like '*Host Controller*' } | Group-Object -Property InstanceId -AsHashTable -AsString
    $genhubs = $usbDevices | Where-Object { $_.Name -like '*USB Hub*' } | Group-Object -Property Parent -AsHashTable -AsString
    $restOfDevices = $usbDevices | Where-Object { 
      $_.Name -notlike '*Host Controller*' -and 
      $_.Name -notlike '*USB Hub*' 
    } | Group-Object -Property Parent -AsHashTable -AsString

    foreach ($controller in $controllers.Values) {
      $controllerNode = New-Object System.Windows.Forms.TreeNode
      $controllerNode.Text = $controller.Name
      $controllerNode.Tag = $controller.InstanceId
      $controllerNode.ImageIndex = 0

      $childDevices = $usbDevices | Where-Object { $_.Parent -eq $controller.InstanceId }

      foreach ($device in $childDevices) {
        $deviceNode = New-Object System.Windows.Forms.TreeNode
        $deviceNode.Text = $device.Name
        $deviceNode.Tag = $device.InstanceId

        if ($genhubs.ContainsKey($device.InstanceId)) {
          $hubNode = New-Object System.Windows.Forms.TreeNode
          $hubNode.Text = $genhubs[$device.InstanceId].Name
          $hubNode.Tag = $genhubs[$device.InstanceId].InstanceId

          $hubChildren = $usbDevices | Where-Object { $_.Parent -eq $device.InstanceId }
          foreach ($hubChild in $hubChildren) {
            $hubChildNode = New-Object System.Windows.Forms.TreeNode
            $hubChildNode.Text = $hubChild.Name
            $hubChildNode.Tag = $hubChild.InstanceId

            if ($restOfDevices.ContainsKey($hubChild.InstanceId)) {
              $childDevices = $restOfDevices[$hubChild.InstanceId]
              foreach ($childDevice in $childDevices) {
                $childNode = New-Object System.Windows.Forms.TreeNode
                $childNode.Text = $childDevice.Name
                $childNode.Tag = $childDevice.InstanceId
                $hubChildNode.Nodes.Add($childNode)
              }
            }

            $hubNode.Nodes.Add($hubChildNode)
          }
          $deviceNode.Nodes.Add($hubNode)
        }
        elseif ($restOfDevices.ContainsKey($device.InstanceId)) {
          $childDevices = $restOfDevices[$device.InstanceId]
          foreach ($childDevice in $childDevices) {
            $childNode = New-Object System.Windows.Forms.TreeNode
            $childNode.Text = $childDevice.Name
            $childNode.Tag = $childDevice.InstanceId
            $deviceNode.Nodes.Add($childNode)
          }
        }

        $controllerNode.Nodes.Add($deviceNode)
      }

      $treeView.Nodes.Add($controllerNode)
    }

    $treeView.ExpandAll()

    $treeView.add_AfterCheck({
        param($sender, $e)
        if ($e.Node.Nodes.Count -gt 0 -and $e.Node.Checked) {
          foreach ($childNode in $e.Node.Nodes) {
            $childNode.Checked = $true
          }
        }
        elseif ($e.Node.Nodes.Count -gt 0 -and -not $e.Node.Checked) {
          foreach ($childNode in $e.Node.Nodes) {
            $childNode.Checked = $false
          }
        }
      })

    # Check All Checkbox for USB Power
    $checkboxALLUSB = New-Object System.Windows.Forms.CheckBox
    $checkboxALLUSB.Text = 'Check All'
    $checkboxALLUSB.Location = New-Object System.Drawing.Point(460, 50) 
    $checkboxALLUSB.Size = New-Object System.Drawing.Size(100, 20)
    $checkboxALLUSB.ForeColor = 'White'
    $checkboxALLUSB.BackColor = [System.Drawing.Color]::Transparent
    $usbPowerPanel.Controls.Add($checkboxALLUSB)

    $checkboxALLUSB.Add_CheckedChanged({
        if ($checkboxALLUSB.Checked) {
          foreach ($treeNode in $treeView.Nodes) {
            $treeNode.Checked = $true
          }
        }
        else {
          foreach ($treeNode in $treeView.Nodes) {
            $treeNode.Checked = $false
          }
        }
      })

    foreach ($setting in $settings.GetEnumerator()) {
      if ($Global:enabledOptions -contains $setting.key -and $setting.key -ne 'removeallPlans') {
        $setting.value.ForeColor = [System.Drawing.Color]::Gray
        $setting.value.checked = $true
      }
    }


    # OK and Cancel Buttons
    $OKButton = Create-ModernButton -Text 'OK' -Location (New-Object System.Drawing.Point(300, 470)) -Size (New-Object System.Drawing.Size(120, 27)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2

    $CancelButton = Create-ModernButton -Text 'Cancel' -Location (New-Object System.Drawing.Point(425, 470)) -Size (New-Object System.Drawing.Size(120, 27)) -DialogResult ([System.Windows.Forms.DialogResult]::Cancel) -borderSize 2
    $powerPlanPanel.controls.add($OKButton)
    $powerPlanPanel.controls.add($CancelButton)
    <#
    $OKButton = New-Object System.Windows.Forms.Button
    $OKButton.Location = New-Object System.Drawing.Point(315, 470)  
    $OKButton.Size = New-Object System.Drawing.Size(100, 23)
    $OKButton.Text = 'Apply'
    $OKButton.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $OKButton.ForeColor = [System.Drawing.Color]::White
    $OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.AcceptButton = $OKButton
    $form.Controls.Add($OKButton)

    $CancelButton = New-Object System.Windows.Forms.Button
    $CancelButton.Location = New-Object System.Drawing.Point(425, 470) 
    $CancelButton.Size = New-Object System.Drawing.Size(100, 23)
    $CancelButton.Text = 'Cancel'
    $CancelButton.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $CancelButton.ForeColor = [System.Drawing.Color]::White
    $CancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.CancelButton = $CancelButton
    $form.Controls.Add($CancelButton)
#>
  

    # Activate the form
    $form.Add_Shown({ $form.Activate() })
    $result = $form.ShowDialog()
      
  }
      
      
      

              
   
   
      
      
      
  # Check the selected checkboxes
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    if ($Global:enabledOptions -contains 'usePowerPlan') {
      $checkboxCustomPlan1.Checked = $false
    }
    if ($Global:enabledOptions -contains 'usePowerPlanAMD') {
      $checkboxCustomPlan2.Checked = $false
    }

    if ($checkboxCustomPlan1.Checked) {
      if (!($Autorun)) {
        #update config
        update-config -setting 'usePowerPlan' -value 1
      }
              
      #imports power plan
      $p = Search-File '*mpwaresultimateperformance.pow'
      
      #generate new guid
      $guid = New-Guid 
      powercfg -import ([string]$p) $guid     
      powercfg /setactive $guid 
      if (!($Autorun)) {
        Custom-MsgBox -message 'Custom Power Plan Active!' -type None
      }
    }
   
          
    if ($checkboxCustomPlan2.Checked) {
      if (!($Autorun)) {
        #update config
        update-config -setting 'usePowerPlanAMD' -value 1
      }
              
      #imports power plan
      $p = Search-File '*mpwaresultimateperformanceAMD.pow'
      
      #generate new guid
      $guid = New-Guid 
      powercfg -import ([string]$p) $guid     
      powercfg /setactive $guid 
      if (!($Autorun)) {
        Custom-MsgBox -message 'Custom AMD Power Plan Active!' -type None
      }
    }
   
    if (!$Autorun) {
      if ($powerTextbox.Text -ne '') {

        $planPath = $powerTextbox.Text
        #generate new guid
        $guid = New-Guid 
        powercfg -import ([string]$planPath) $guid     
        powercfg /setactive $guid 

        Custom-MsgBox -message 'Imported Power Plan Active!' -type None
      
      }
    }
    


    if (!($Autorun)) {
      #loop through checkbox hashtable to update config
      $settings.GetEnumerator() | ForEach-Object {
            
        $settingName = $_.Key
        $checkbox = $_.Value
        #dont update config with options already checked
        if ($Global:enabledOptions -contains $settingName) {
          $checkbox.Checked = $false
        }
        
        if ($checkbox.Checked) {
          update-config -setting $settingName -value 1
        }
      }
    }
    
    $removed = $false
    if ($removeallPlans -or $checkboxALL.Checked) {
      $removed = $true
      $output = powercfg /L
      $powerPlans = @{}
      foreach ($line in $output) {
        # extract guid manually to avoid lang issues
        if ($line -match ':') {
          $parse = $line -split ':'
          $index = $parse[1].Trim().indexof('(')
          $guid = $parse[1].Trim().Substring(0, $index)
          #get name
          $start = $parse[1].IndexOf('(')
          $name = $parse[1].Substring($start).Trim('()*')
          $name = $name -replace '\)' , ''
          $powerPlans.Add($name, $guid)
        }
      }
      # delete all powerplans
      foreach ($plan in $powerPlans.GetEnumerator()) {
        Write-Status -Message "Removing $($plan.Key)..." -Type Output
        cmd /c "powercfg /delete $($plan.Value)" | Out-Null
      }
    }


    if ($checkedListBox.CheckedItems -and $removed -eq $false) {
      $powerPlans = @{}
      foreach ($line in $output) {
        foreach ($name in $checkedListBox.CheckedItems.GetEnumerator()) {
          if ($line -like "*$name*") {
            $parse = $line -split ':'
            $index = $parse[1].Trim().indexof('(')
            $guid = $parse[1].Trim().Substring(0, $index)
            #get name
            $start = $parse[1].IndexOf('(')
            $name = $parse[1].Substring($start).Trim('()*')
            $name = $name -replace '\)' , ''
            $powerPlans.Add($name, $guid)
          }
        }
      }
      foreach ($plan in $powerPlans.GetEnumerator()) {
        Write-Status -Message "Removing $($plan.Key)..." -Type Output
        cmd /c "powercfg /delete $($plan.Value)" | Out-Null
      }
    }
    if ($checkbox1.Checked) {
      #duplicate ultimate performance
      powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 | Out-Null
     
    }
    if ($checkbox2.Checked) {
      #duplicate max performance overlay
      powercfg -duplicatescheme ded574b5-45a0-4f42-8737-46345c09c238 | Out-Null  
    }    
    if ($checkbox3.Checked) {
      #duplicate high performance overlay
      powercfg -duplicatescheme 3af9b8d9-7c97-431d-ad78-34a8bfea439f | Out-Null

    }    
   

    function Disable-PowerSaving {
      param (
        [string]$name,
        [string]$instanceID
      )

      $key = 'HKLM\SYSTEM\ControlSet001\Enum'

      Write-Status -Message "Disabling Power Saving For $name" -Type Output
       
      Reg.exe add "$($key)\$instanceID\Device Parameters\WDF" /v 'IdleInWorkingState' /t REG_DWORD /d '0' /f
      #uncheck device manager ui
      try {
        $powerMgmt = Get-CimInstance MSPower_DeviceEnable -Namespace root\wmi | Where-Object { $_.InstanceName -like "*$instanceID*" }
        $powerMgmt.Enable = $false 
        Set-CimInstance -InputObject $powerMgmt -ErrorAction Stop
      }
      catch {
        Write-Status -Message 'No Power Saving For This Device, Reg Key Still Applied...' -Type Warning
      }

    }

    
    foreach ($rootNode in $treeView.Nodes) {
      if ($rootNode.Checked) {
        Disable-PowerSaving -name $rootNode.Text -instanceId $rootNode.Tag
      }

      #check child nodes
      foreach ($childNode in $rootNode.Nodes) {
        if ($childNode.Checked) {
          Disable-PowerSaving -name $childNode.Text -instanceId $childNode.Tag
        }
        foreach ($genUsbNode in $childNode.Nodes) {
          if ($genUsbNode.Checked) {
            Disable-PowerSaving -name $genUsbNode.Text -instanceId $genUsbNode.Tag
          }

          foreach ($deviceNode in $genUsbNode.Nodes) {
            if ($deviceNode.Checked) {
              Disable-PowerSaving -name $deviceNode.Text -instanceId $deviceNode.Tag
            }
          }
        }
      }
    }
       

    if ($checkboxRestore.Checked) {
      Write-Status -Message 'Restoring Default Power Plans...' -Type Output
      powercfg -restoredefaultschemes | Out-Null
    }
          
  }
      
}
Export-ModuleMember -Function import-powerplan






function import-reg {

  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
  )
    
    
    
    
  if ($AutoRun) {
    $result = [System.Windows.Forms.DialogResult]::OK
  }
  else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $form3 = New-Object System.Windows.Forms.Form
    $form3.Text = 'Registry Tweaks'
    $form3.Size = New-Object System.Drawing.Size(790, 700)
    $form3.StartPosition = 'CenterScreen'
    $form3.BackColor = 'Black'
    $form3.Font = New-Object System.Drawing.Font('Segoe UI', 8)

    
    $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
    $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

    # Override the form's paint event to apply the gradient
    $form3.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $form3.Width, $form3.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    #info button
    $url = 'https://github.com/MP7BDO/mpware/blob/main/features.md#registry-tweaks'
    $infobutton = New-Object Windows.Forms.Button
    $infobutton.Location = New-Object Drawing.Point(740, 10)
    $infobutton.Size = New-Object Drawing.Size(30, 30)
    $infobutton.Cursor = 'Hand'
    $infobutton.Add_Click({
        try {
          Start-Process $url -ErrorAction Stop
        }
        catch {
          Write-Status -Message 'No Internet Connected...' -Type Error
        }
            
      })
    $infobutton.BackColor = [System.Drawing.Color]::Transparent
    $image = [System.Drawing.Image]::FromFile('C:\Windows\System32\SecurityAndMaintenance.png')
    $resizedImage = New-Object System.Drawing.Bitmap $image, 24, 25
    $infobutton.Image = $resizedImage
    $infobutton.ImageAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $infobutton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $infobutton.FlatAppearance.BorderSize = 0
    $infobutton.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::Transparent
    $infobutton.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::Transparent
    $form3.Controls.Add($infobutton)



    $searchBox11 = New-Object System.Windows.Forms.TextBox
    $searchBox11.Location = New-Object System.Drawing.Point(10, 190)
    $searchBox11.Size = New-Object System.Drawing.Size(150, 20)
    $form3.Controls.Add($searchBox11)


    $pictureBox = New-Object System.Windows.Forms.PictureBox
    $pictureBox.Location = New-Object System.Drawing.Point(165, 190) 
    $pictureBox.Size = New-Object System.Drawing.Size(30, 20) 
    $pictureBox.BackColor = [System.Drawing.Color]::Transparent
    $pictureBox.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $pictureBox.Image = $null
    $form3.Controls.Add($pictureBox)


    #  $pictureBox2 = New-Object System.Windows.Forms.PictureBox
    #  $pictureBox2.Location = New-Object System.Drawing.Point(560, 190) 
    #  $pictureBox2.Size = New-Object System.Drawing.Size(30, 20)
    #  $pictureBox2.BackColor = [System.Drawing.Color]::Transparent
    #  $pictureBox2.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    #  $pictureBox2.Image = $image
    #  $form3.Controls.Add($pictureBox2)

    
    $label2 = New-Object System.Windows.Forms.Label
    $label2.Location = New-Object System.Drawing.Point(10, 10)
    $label2.Size = New-Object System.Drawing.Size(300, 20)
    $label2.Text = 'Mode: Run Selected Tweaks'
    $label2.ForeColor = 'White'
    $label2.BackColor = [System.Drawing.Color]::Transparent
    $label2.Font = New-Object System.Drawing.Font('Segoe UI', 12) 
    $form3.Controls.Add($label2)
    

    $checkedListBox11 = New-Object System.Windows.Forms.CheckedListBox
    $checkedListBox11.Location = New-Object System.Drawing.Point(10, 215)
    $checkedListBox11.Size = New-Object System.Drawing.Size(600, 435)
    $checkedListBox11.BackColor = 'Black'
    $checkedListBox11.ForeColor = 'White'
    $checkedListBox11.CheckOnClick = $true
    $checkedListBox11.ScrollAlwaysVisible = $true
    $Form3.Controls.Add($checkedListBox11)

    $r11 = Search-File '*RegTweaks.txt'
   
    $content = Get-Content $r11
    $Global:regOptions11 = $content -split "`n"
    $options11 = @()
    $archiveAppsTweak = $false
    foreach ($line in $regOptions11) {
      if ($line -like ';*') {
        $name = $line -split ';'
        $checkedListBox11.Items.Add($name[1].Trim(), $false) | Out-Null
        $options11 += $name[1].Trim()
        if ($name[1].Trim() -eq 'Disable Archive Apps') {
          $archiveAppsTweak = $true
        }
      }
      
    }
  
    if (!$archiveAppsTweak) {
      #add archive apps to win11 tweaks
      $regPath = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList'
      $items = (Get-ChildItem $regPath).Name
      foreach ($item in $items) {
        if ($item -like '*S-1-5-21*') {
          #extract sid
          $sid = ($item -split '\\')[-1]
        }
      }
      #create reg content 
      $disableArchiveApps = @"

; Disable Archive Apps
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\InstallService\Stubification\$sid]
"EnableAppOffloading"=dword:00000000
"@
      Add-Content -Path $r11 -Value $disableArchiveApps -Force | Out-Null

      #add to checkedlistbox
      $checkedListBox11.Items.Add('Disable Archive Apps', $false) | Out-Null
      $options11 += 'Disable Archive Apps'
    }
   

    # Add the listbox for selected items
    $selectedItemsBox = New-Object System.Windows.Forms.ListBox
    $selectedItemsBox.Location = New-Object System.Drawing.Point(10, 30)
    $selectedItemsBox.Size = New-Object System.Drawing.Size(420, 115)
    $selectedItemsBox.BackColor = 'Black'
    $selectedItemsBox.ForeColor = [System.Drawing.Color]::FromArgb(66, 245, 93)
    $selectedItemsBox.ScrollAlwaysVisible = $true
    $form3.Controls.Add($selectedItemsBox)


    $originalItems11 = $options11.Clone()
 
    $checkedStates11 = @{}


    foreach ($item in $originalItems11) {
      $checkedStates11[$item] = $false
    }

   


    $checkedListBox11.Add_ItemCheck({
        param($sender, $e)
        $item = $checkedListBox11.Items[$e.Index]
        $checkedStates11[$item] = $e.NewValue -eq 'Checked'
    
        # Update selected items listbox
        $selectedItemsBox.Items.Clear()
    
        foreach ($checkedItem in $checkedListBox11.CheckedItems) {
          #skip current item because the state hasnt changed yet
          if ($checkedItem -ne $item) {
            $selectedItemsBox.Items.Add("$checkedItem")
          }
        }

        # Add the item that triggered this event if it's being checked
        if ($e.NewValue -eq 'Checked') {
          $selectedItemsBox.Items.Add("$item")
        }


      })

    
   
    $searchBox11.Add_TextChanged({
        $searchText = $searchBox11.Text.ToLower()
        $checkedListBox11.Items.Clear()

        $sortedItems = $originalItems11 | Sort-Object {
          # return to original order when not searching
          if ([string]::IsNullOrWhiteSpace($searchText)) {
            return [array]::IndexOf($originalItems11, $_)
          }
          #starts with top priority
          if ($_.ToLower().StartsWith($searchText)) {
            return 0
          }
          #contains second priority
          if ($_.ToLower().Contains($searchText)) {
            return 1
          }
          #no match
          return 2
        }

        # keep checked state the same when adding back to list
        foreach ($item in $sortedItems) {
          $index = $checkedListBox11.Items.Add($item)
          $checkedListBox11.SetItemChecked($index, $checkedStates11[$item])
        }
      })


    $default = Create-ModernButton -Text 'Run All Tweaks' -Location (New-Object System.Drawing.Point(595, 95)) -Size (New-Object System.Drawing.Size(130, 35)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2
        
   
    $form3.Controls.Add($default)

    $Global:blackWallpaper = $false
    $Global:taskMgrOnTop = $false
    $Global:PowerModes = $false
    $Global:FTH = $false
    $Global:Terminal = $false
    $Global:memCompress = $false
    $Global:sleepstudy = $false
    $Global:widgets = $false
    $Global:storesettings = $false
    $Global:appactions = $false
    $Global:backupsettings = $false
    $Global:winai = $false
    $Global:DND = $false
    $Global:hardwareaccel = $false
    $Global:expandCalendar = $false

    $custom = Create-ModernButton -Text 'Run Custom Tweaks' -Location (New-Object System.Drawing.Point(435, 95)) -Size (New-Object System.Drawing.Size(130, 35)) -ClickAction {
      #build custom regtweak in temp dir

      #remove any previous custom reg file (just in case)
      Remove-Item "$tempDir\CustomTweaks.reg" -Force -ErrorAction SilentlyContinue | Out-Null

      #get 11 tweaaks
      $removeTweaks11 = @()
      foreach ($item in $checkedListBox11.CheckedItems.GetEnumerator()) {
        $removeTweaks11 += $item
      }
      #get tweaks 11
      $editedRegContent11 = @()
      $removeTweak = $false
        
      foreach ($line in $regOptions11) {
        #if line has comment check it 
        if ($line -like ';*') {
          #reset remove tweak
          $removeTweak = $false
          $name = $line -split ';'
          #if the name is in removeitems list then exclude the following lines till the next ";"
          if ($name[1].trim() -in $removeTweaks11) {
            $removeTweak = $true
          }
          else {
            #tweak not in list
            $editedRegContent11 += $line
            #keep track of some options for later
            if ($name[1].trim() -eq 'Set background black') {
              $Global:blackWallpaper = $true
            }

            if ($name[1].trim() -eq 'Task Manager Always On Top') {
              $Global:taskMgrOnTop = $true
            }

            if ($name[1].trim() -eq 'Respect Power Modes Search Indexer') {
              $Global:PowerModes = $true
            }

            if ($name[1].trim() -eq 'Disable Fault Tolerant Heap') {
              $Global:FTH = $true
            }

            if ($name[1].trim() -eq 'Black PowerShell Console') {
              $Global:Terminal = $true
            }

            if ($name[1].trim() -eq 'Disable Memory Compression') { 
              $Global:memCompress = $true
            }

            if ($name[1].trim() -eq 'Disable SleepStudy') { 
              $Global:sleepstudy = $true
            }

            if ($name[1].trim() -eq 'Disable windows widgets') { 
              $Global:widgets = $true
            }

            if ($name[1].trim() -eq 'Disable Store Settings') { 
              $Global:storesettings = $true
            }

            if ($name[1].trim() -eq 'Disable App Actions') { 
              $Global:appactions = $true
            }

            if ($name[1].trim() -eq 'Disable windows backup') {  
              $Global:backupsettings = $true
            }

            if ($name[1].trim() -eq 'Disable Windows AI') {   
              $Global:winai = $true
            }

            if ($name[1].trim() -eq 'Disable Do Not Disturb') {   
              $Global:DND = $true
            }

            if ($name[1].trim() -eq 'Turn on hardware accelerated gpu scheduling') {    
              $Global:hardwareaccel = $true
            }

            if ($name[1].trim() -eq 'Expand Calendar') {    
              $Global:expandCalendar = $true
            }
            
          }
        }
        else {
          if (!$removeTweak) {
            #tweak not in list
            $editedRegContent11 += $line
          }
        }
      }

      Add-Content "$tempDir\CustomTweaks.reg" -Value $editedRegContent11 -Force
    } -Visible $false -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2

   
    $form3.Controls.Add($custom)

    $selectedbttn = Create-ModernButton -Text 'Run Selected Tweaks' -Location (New-Object System.Drawing.Point(435, 95)) -Size (New-Object System.Drawing.Size(130, 35)) -ClickAction {
      
      #REVERSE LOGIC OF REMOVE TWEAKS

      #remove any previous custom reg file (just in case)
      Remove-Item "$tempDir\CustomTweaks.reg" -Force -ErrorAction SilentlyContinue | Out-Null

     
      #get 11 tweaaks
      $selectedTweaks11 = @()
      foreach ($item in $checkedListBox11.CheckedItems.GetEnumerator()) {
        $selectedTweaks11 += $item
      }
      #get tweaks 11
      $editedRegContent11 = @()
      $addTweak = $false
        
      foreach ($line in $regOptions11) {
        #if line has comment check it 
        if ($line -like ';*') {
          $name = $line -split ';'
          #if name is in addtweaks add the line and tweak until next ;
          if ($name[1].trim() -in $selectedTweaks11) {
            #add name
            $editedRegContent11 += $line
            $addTweak = $true
            #keep track of some options for later
            if ($name[1].trim() -eq 'Set background black') {
              $Global:blackWallpaper = $true
            }

            if ($name[1].trim() -eq 'Task Manager Always On Top') {
              $Global:taskMgrOnTop = $true
            }

            if ($name[1].trim() -eq 'Respect Power Modes Search Indexer') {
              $Global:PowerModes = $true
            }

            if ($name[1].trim() -eq 'Disable Fault Tolerant Heap') {
              $Global:FTH = $true
            }

            if ($name[1].trim() -eq 'Black PowerShell Console') {
              $Global:Terminal = $true
            }

            if ($name[1].trim() -eq 'Disable Memory Compression') { 
              $Global:memCompress = $true
            }

            if ($name[1].trim() -eq 'Disable SleepStudy') { 
              $Global:sleepstudy = $true
            }

            if ($name[1].trim() -eq 'Disable windows widgets') { 
              $Global:widgets = $true
            }

            if ($name[1].trim() -eq 'Disable Store Settings') { 
              $Global:storesettings = $true
            }

            if ($name[1].trim() -eq 'Disable App Actions') { 
              $Global:appactions = $true
            }

            if ($name[1].trim() -eq 'Disable windows backup') { 
              $Global:backupsettings = $true
            }

            if ($name[1].trim() -eq 'Disable Windows AI') {  
              $Global:winai = $true
            }

            if ($name[1].trim() -eq 'Disable Do Not Disturb') {   
              $Global:DND = $true
            }

            if ($name[1].trim() -eq 'Turn on hardware accelerated gpu scheduling') {   
              $Global:hardwareaccel = $true
            }

            if ($name[1].trim() -eq 'Expand Calendar') {    
              $Global:expandCalendar = $true
            }
          }
          else {
            #tweak is not in list
            $addTweak = $false
          }
        }
        else {
          if ($addTweak) {
            #add tweak
            $editedRegContent11 += $line
          }
        }
      }

      Add-Content "$tempDir\CustomTweaks.reg" -Value "Windows Registry Editor Version 5.00`r`n" -Force
      Add-Content "$tempDir\CustomTweaks.reg" -Value $editedRegContent11 -Force
    } -Visible $true -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2

 
    $form3.Controls.Add($selectedbttn)

    $changeModebttn = Create-ModernButton -Text 'Change Mode' -Location (New-Object System.Drawing.Point(435, 30)) -Size (New-Object System.Drawing.Size(90, 25)) -ClickAction {
      if ($changeModebttn.Tag -eq $false) {
        $label2.Text = 'Mode: Exclude Selected Tweaks'
        $selectedItemsBox.ForeColor = 'Red'
        $selectedbttn.Visible = $false
        $custom.Visible = $true
        $changeModebttn.Tag = $true
        # $changeModebttn.BackColor = [System.Drawing.Color]::FromArgb(20, 20, 20)
      }
      else {
        $label2.Text = 'Mode: Run Selected Tweaks'
        $selectedItemsBox.ForeColor = [System.Drawing.Color]::FromArgb(66, 245, 93) #light green
        $selectedbttn.Visible = $true
        $custom.Visible = $false
        $changeModebttn.Tag = $false
        # $changeModebttn.BackColor = [System.Drawing.Color]::FromArgb(45, 45, 45)
      }
    }
    $changeModebttn.Tag = $false

    $form3.Controls.Add($changeModebttn)

    $result = $form3.ShowDialog() 
  }
      
      
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    #update config
    if (!($Autorun)) {
      update-config -setting 'registryTweaks' -value 1
    }

    function WallpaperRefresh {
      #refresh wallpaper to apply black color on 24h2 using winapi
      Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public class WallpaperRefresh {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);
    
    [DllImport("user32.dll", CharSet=CharSet.Auto)]
    public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
'@

      $SPI_SETDESKWALLPAPER = 0x0014
      $SPIF_UPDATEINIFILE = 0x01
      $SPIF_SENDCHANGE = 0x02

      # set wallpaper blank
      $blankWallpaper = ''
      [WallpaperRefresh]::SystemParametersInfo($SPI_SETDESKWALLPAPER, 0, $blankWallpaper, $SPIF_UPDATEINIFILE -bor $SPIF_SENDCHANGE)

      #refresh wallpaper
      [WallpaperRefresh]::InvalidateRect(0, [IntPtr]::Zero, $true)
    }


    function UpdateVisuals {
      #run 5 times as multiple visual changes will be applied
      1..5 | ForEach-Object { 
        & RUNDLL32.EXE user32.dll, UpdatePerUserSystemParameters , 1 , True 
        Start-Sleep -Milliseconds 5
      } 
    }

    function MSIMode {
      #set gpu msi mode
      $instanceID = (Get-PnpDevice -Class Display).InstanceId
      Reg.exe add "HKLM\SYSTEM\ControlSet001\Enum\$instanceID\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties" /v 'MSISupported' /t REG_DWORD /d '1' /f *>$null
    }

    function PassExpire {
      $OS = Get-CimInstance Win32_OperatingSystem
      if ($OS.BuildNumber -gt 19045) {
        #disable password expire for 11
        net accounts /maxpwage:unlimited *>$null
      }
    }

    function TaskOnTopW11 {
      $OS = Get-CimInstance Win32_OperatingSystem
      if ($OS.BuildNumber -gt 19045) {
        #apply taskmanager always on top for win11
        $settingsFile = "$env:LOCALAPPDATA\Microsoft\Windows\TaskManager\settings.json"
        #create the file if user has never opened taskmanager
        if (!(Test-Path $settingsFile)) {
          $wshell = New-Object -ComObject WScript.Shell;
          $wshell.Run('taskmgr.exe', 0, $false) >$null
            
          Start-Sleep 3
          Stop-Process -Name 'Taskmgr' -Force -ErrorAction SilentlyContinue
          Start-Sleep 1
        }

        
      
        $jsonContent = Get-Content -Path $settingsFile -Raw | ConvertFrom-Json
        #add always ontop property
        $jsonContent | Add-Member -NotePropertyName 'AlwaysOnTop' -NotePropertyValue $true -Force
  
        $jsonContent | ConvertTo-Json -Depth 10 | Set-Content -Path $settingsFile
        
        
      }

    
    }

    function RespectPowerModes {
      $command = 'reg add `"HKLM\Software\Microsoft\Windows Search\Gather\Windows\SystemIndex`" /v `"RespectPowerModes`" /t REG_DWORD /d 1 /f'
      Run-Trusted -command $command
    }

    function Remove-FTH {
      Start-Process rundll32.exe -ArgumentList 'fthsvc.dll, FthSysprepSpecialize'
    }

    function Black-Console {
      function Set-ConsoleBlack {
        param (
          [string]$lnkPath
        )

        if (Test-Path $lnkPath) {
          $data = [System.IO.File]::ReadAllBytes($lnkPath)

          # Check if ConsoleDataBlock already exists (sig: 02 00 00 A0) 
          $sig = [byte[]](0x02, 0x00, 0x00, 0xA0)
          $existingOffset = -1
          for ($i = 4; $i -lt $data.Length - 4; $i++) {
            if ($data[$i] -eq $sig[0] -and $data[$i + 1] -eq $sig[1] -and
              $data[$i + 2] -eq $sig[2] -and $data[$i + 3] -eq $sig[3]) {
              $existingOffset = $i - 4
              break
            }
          }

          # Build ConsoleDataBlock (204 bytes / 0xCC) 
          function Write-LEUInt32 ($buf, $off, $val) {
            $buf[$off] = $val -band 0xFF
            $buf[$off + 1] = ($val -shr 8)  -band 0xFF
            $buf[$off + 2] = ($val -shr 16) -band 0xFF
            $buf[$off + 3] = ($val -shr 24) -band 0xFF
          }
          function Write-LEUInt16 ($buf, $off, $val) {
            $buf[$off] = $val -band 0xFF
            $buf[$off + 1] = ($val -shr 8) -band 0xFF
          }

          $block = New-Object byte[] 204

          Write-LEUInt32 $block 0x00 0xCC         # BlockSize = 204
          Write-LEUInt32 $block 0x04 0xA0000002   # BlockSignature
          Write-LEUInt16 $block 0x08 0x000F       # FillAttributes: fg=white(F) bg=black(0)
          Write-LEUInt16 $block 0x0A 0x00F0       # PopupFillAttributes: fg=black bg=white
          Write-LEUInt16 $block 0x0C 120          # ScreenBufferSizeX
          Write-LEUInt16 $block 0x0E 9000         # ScreenBufferSizeY (scroll buffer)
          Write-LEUInt16 $block 0x10 120          # WindowSizeX
          Write-LEUInt16 $block 0x12 30           # WindowSizeY
          Write-LEUInt16 $block 0x14 0            # WindowOriginX
          Write-LEUInt16 $block 0x16 0            # WindowOriginY
          # 0x18..0x1F unused (already zero)
          Write-LEUInt32 $block 0x20 0x00100000   # FontSize: height=16px width=0(auto)
          Write-LEUInt32 $block 0x24 0x00000036   # FontFamily: FF_MODERN|TMPF_TRUETYPE|TMPF_VECTOR|TMPF_FIXED_PITCH
          Write-LEUInt32 $block 0x28 400          # FontWeight: 400 = normal
          # FaceName at 0x2C: "Consolas" as UTF-16LE (64 bytes, already zero-padded)
          $faceBytes = [Text.Encoding]::Unicode.GetBytes('Consolas')
          [Array]::Copy($faceBytes, 0, $block, 0x2C, $faceBytes.Length)

          Write-LEUInt32 $block 0x6C 25           # CursorSize: 25 = small
          Write-LEUInt32 $block 0x70 0            # FullScreen: 0 = windowed
          Write-LEUInt32 $block 0x74 1            # QuickEdit
          Write-LEUInt32 $block 0x78 1            # InsertMode
          Write-LEUInt32 $block 0x7C 1            # AutoPosition
          Write-LEUInt32 $block 0x80 50           # HistoryBufferSize
          Write-LEUInt32 $block 0x84 4            # NumberOfHistoryBuffers
          Write-LEUInt32 $block 0x88 0            # HistoryNoDup

          # Color table at 0x8C: 16 x DWORD in BGR format
          $colorTable = @(
            0x000000,  # 0  Black
            0x800000,  # 1  Dark Blue
            0x008000,  # 2  Dark Green
            0x808000,  # 3  Dark Cyan
            0x000080,  # 4  Dark Red
            0x800080,  # 5  Dark Magenta
            0x008080,  # 6  Dark Yellow
            0xC0C0C0,  # 7  Gray
            0x808080,  # 8  Dark Gray
            0xFF0000,  # 9  Blue
            0x00FF00,  # 10 Green
            0xFFFF00,  # 11 Cyan
            0x0000FF,  # 12 Red
            0xFF00FF,  # 13 Magenta
            0x00FFFF,  # 14 Yellow
            0xFFFFFF   # 15 White
          )
          for ($i = 0; $i -lt 16; $i++) {
            Write-LEUInt32 $block (0x8C + $i * 4) $colorTable[$i]
          }


          if ($existingOffset -ge 0) {
            # Overwrite existing block in place (same size, safe)
            [System.Array]::Copy($block, 0, $data, $existingOffset, 204)
          }
          else {
            # Insert before the terminal 4-null-byte block at end of file
            $insertPos = $data.Length - 4
            $newData = New-Object byte[] ($data.Length + 204)
            [System.Array]::Copy($data, 0, $newData, 0, $insertPos)
            [System.Array]::Copy($block, 0, $newData, $insertPos, 204)
            [System.Array]::Copy($data, $insertPos, $newData, $insertPos + 204, 4)
            $data = $newData
          }

          [System.IO.File]::WriteAllBytes($lnkPath, $data)
        }
        
      }

      Set-ConsoleBlack "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Windows PowerShell\Windows PowerShell.lnk"
      Set-ConsoleBlack "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\System Tools\Command Prompt.lnk"
     
    }

    function TerminalSettings {
      $settings = "$env:localappdata\packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json"

      if (Test-Path $settings) {
        $jsonContent = Get-Content -Path $settings -Raw | ConvertFrom-Json
        $jsonContent | Add-Member -NotePropertyName 'alwaysShowTabs' -NotePropertyValue $false -Force
        $jsonContent | Add-Member -NotePropertyName 'showTabsInTitlebar' -NotePropertyValue $false -Force
        $jsonContent | ConvertTo-Json -Depth 10 | Set-Content -Path $settings
      }
      #set cmd and powershell to true black and white
      Black-Console

    }

    function Disable-MemCompress {
      $ramsize = (Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum / 1GB
      if ($ramsize -gt 8) {
        Disable-MMAgent -MemoryCompression
      }
    }

    function Disable-SleepStudy {
      wevtutil sl Microsoft-Windows-SleepStudy/Diagnostic /e:false
      wevtutil sl Microsoft-Windows-Kernel-Processor-Power/Diagnostic /e:false
      wevtutil sl Microsoft-Windows-UserModePowerService/Diagnostic /e:false
    }

    function Remove-CamDB {
      Stop-Service -Name 'camsvc' -Force -ErrorAction SilentlyContinue
      Start-Sleep 1
      $command = "Remove-item `"$env:ProgramData\Microsoft\Windows\CapabilityAccessManager\CapabilityConsentStorage.db*`" -Force"
      Run-Trusted -command $command
      Start-Sleep 1
      
    }

    function Disable-Widgets {
      Copy-Item (Get-Command reg.exe).Source "$tempDir\reg1.exe" -Force -EA 0
      & "$tempDir\reg1.exe" add 'HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' /v 'TaskbarDa' /t REG_DWORD /d '0' /f 
    }

    function Disable-StoreSettings {
      $storescript = Search-File '*Set-StoreSettings.ps1'
      & "$storescript"
    }

    function Disable-AppActions {
      $appactionsscript = Search-File '*Disable-AppActions.ps1'
      & "$appactionsscript"
    }

    function Restart-CDP {
      restart-service -name '*cdp*' -ErrorAction SilentlyContinue
      #Get-Service -Name 'CDP*' | Stop-Service -Force
      #Start-Sleep 1
      #Get-Service -Name 'CDP*' | Start-Service 
    }

    function Disable-CopilotKey {
      Copy-Item (Get-Command reg.exe).Source .\reg1.exe -Force -EA 0
      & .\reg1.exe add 'HKCU\Software\Microsoft\Windows\Shell\BrandedKey' /v 'BrandedKeyChoiceType' /t REG_SZ /d 'Search' /f
      & .\reg1.exe add 'HKCU\Software\Microsoft\Windows\Shell\BrandedKey' /v 'AppAumid' /t REG_SZ /d ' ' /f
      Start-Sleep 1
      Remove-Item .\reg1.exe -Force
    }


    function Refresh-DND {
      #stops and deletes the wpn (notifications service database)
      Get-Service '*wpn*' | Stop-Service -ErrorAction SilentlyContinue
      #Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Notifications\wpn*" -Force -Recurse -ErrorAction SilentlyContinue
      Get-Service '*wpn*' | Start-Service -ErrorAction SilentlyContinue
    }

    function AMD-HardwareAccel {
      Get-CimInstance -ClassName Win32_VideoController | Where-Object { $_.Name -match 'AMD|Radeon' }
    }


    function Expand-Calendar {
      $settingsDat = "$env:LOCALAPPDATA\Packages\Microsoft.Windows.ShellExperienceHost_cw5n1h2txyewy\Settings\settings.dat"
      if (Test-Path $settingsDat) {
        $regContent = @'
Windows Registry Editor Version 5.00

[HKEY_USERS\TEMP\LocalState]
"CalendarState"=hex(5f5e10b):01,bf,f7,ea,57,1a,bb,dc,01
'@

        stop-process -name ShellExperienceHost -Force -ErrorAction SilentlyContinue
    
        $attempts = 0
        do {
          reg load HKU\TEMP $settingsDat *>$null
          $attempts++
        }while ($attempts -le 60 -and $LASTEXITCODE -ne 0)
        New-Item "$tempDir\Expand.reg" -Value $regContent -Force | Out-Null
        regedit.exe /s "$tempDir\Expand.reg"
        Start-Sleep 1
        reg unload HKU\TEMP >$null
        Remove-Item "$tempDir\Expand.reg" -Force -ErrorAction SilentlyContinue
      }

      

    }
    
   
    if (Test-Path "$tempDir\CustomTweaks.reg") {
      #custom reg tweaks selected
      $regContent = Get-Content "$tempDir\CustomTweaks.reg" -Force
      Remove-Item "$([Environment]::GetFolderPath('Desktop'))\RegTweaks.reg" -Force -ErrorAction SilentlyContinue
      Set-Content "$([Environment]::GetFolderPath('Desktop'))\RegTweaks.reg" -Value $regContent -Force

      Write-Status -Message 'Applying Registry Tweaks...' -Type Output
      Remove-CamDB
      #run tweaks
      regedit.exe /s "$([Environment]::GetFolderPath('Desktop'))\RegTweaks.reg"
      Start-Sleep 2
      
      if ($Global:blackWallpaper) {
        WallpaperRefresh
      }

      if ($Global:taskMgrOnTop) {
        TaskOnTopW11
      }

      if ($Global:PowerModes) {
        RespectPowerModes
      }

      if ($Global:FTH) {
        Remove-FTH
      }

      if ($Global:Terminal) {
        TerminalSettings
      }

      if ($Global:memCompress) {
        Disable-MemCompress
      }

      if ($Global:sleepstudy) {
        Disable-SleepStudy
      }

      if ($Global:widgets) {
        Disable-Widgets
      }

      if ($Global:storesettings) {
        Disable-StoreSettings
      }

      if ($Global:appactions) {
        Disable-AppActions
      }

      if ($Global:backupsettings) {
        Restart-CDP
      }

      if ($Global:winai) {
        Disable-CopilotKey
      }

      if ($Global:DND) {
        Refresh-DND
      }

      if ($Global:expandCalendar) {
        Expand-Calendar
      }

      PassExpire
      MSIMode
      UpdateVisuals

      #prevent event log error from disabling uac
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\luafv' /v 'Start' /t REG_DWORD /d '4' /f
      
      Write-Status -Message 'Restarting Explorer...' -Type Output
      #final refresh 
      Restart-Explorer
      #cleanup
      Remove-Item "$tempDir\CustomTweaks.reg" -Force -ErrorAction SilentlyContinue
    }
    else {

     
      #add win 11 tweaks
      $reg11 = Search-File '*RegTweaks.txt'
      $regContent11 = Get-Content $reg11 -Force
      Set-Content "$tempDir\RegTweaks11.reg" -Value $regContent11 -Force | Out-Null
        
      #create full reg tweaks on desktop but run win10 and 11 seperate to avoid some keys not applying
      Set-Content "$([Environment]::GetFolderPath('Desktop'))\RegTweaks.reg" -Value $regContent11 -Force

      Write-Status -Message 'Applying Registry Tweaks...' -Type Output
      Remove-CamDB
      #run tweaks
      regedit.exe /s "$tempDir\RegTweaks11.reg"
      
      Start-Sleep 2
      
      WallpaperRefresh
      TaskOnTopW11
      PassExpire
      MSIMode
      UpdateVisuals
      RespectPowerModes
      Remove-FTH
      TerminalSettings
      Disable-MemCompress
      Disable-SleepStudy
      Disable-Widgets
      Disable-StoreSettings
      Disable-AppActions
      Restart-CDP
      Disable-CopilotKey
      Expand-Calendar
      Refresh-DND
      #prevent event log error from disabling uac
      Reg.exe add 'HKLM\SYSTEM\CurrentControlSet\Services\luafv' /v 'Start' /t REG_DWORD /d '4' /f
      
      Remove-Item "$tempDir\RegTweaks11.reg" -Force -ErrorAction SilentlyContinue
      
      Write-Status -Message 'Restarting Explorer...' -Type Output
      #final refresh 
      Restart-Explorer
    }

    
  
    if (!($Autorun)) {
      Custom-MsgBox -message 'Registry Tweaks Applied!' -type None
    }
        
  }
  
}
Export-ModuleMember -Function import-reg






function install-packs {
  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
  )
      
         
      
  if ($AutoRun) {
    $msgBoxInput = 'OK'
  }
  else {
    $msgBoxInput = Custom-MsgBox -message 'Install DX, C++ Packages and NET 3.5?' -type Question
  }
        
        
  switch ($msgBoxInput) {
        
    'OK' {
      #update config
      if (!($Autorun)) {
        update-config -setting 'installPackages' -value 1
      }
      
      Write-Status -Message 'Attempting to install...' -Type Output
     
      #abbodi1406 deleted github cant use this aio anymore
      <#
        $installDir = $PSScriptRoot 
        #install C++
        $ProgressPreference = 'SilentlyContinue'
        $url = 'https://api.github.com/repos/abbodi1406/vcredist/releases/latest'
        $response = Invoke-RestMethod -Uri $url -UseBasicParsing -ErrorAction Stop
        $version = $response.tag_name
        Invoke-RestMethod -Uri "https://github.com/abbodi1406/vcredist/releases/download/$version/VisualCppRedist_AIO_x86_x64.exe" -UseBasicParsing -OutFile "$installDir\VisualCppRedist_AIO_x86_x64.exe" 
        #>

      #try to install all the c++ vcredist
      try {
        $downloadLinks = @(
          'https://aka.ms/vc14/vc_redist.x86.exe'
          'https://aka.ms/vc14/vc_redist.x64.exe'
          'https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x86.exe'
          'https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x64.exe'
          'https://download.microsoft.com/download/1/6/5/165255E7-1014-4D0A-B094-B6A430A6BFFC/vcredist_x86.exe'
          'https://download.microsoft.com/download/1/6/5/165255E7-1014-4D0A-B094-B6A430A6BFFC/vcredist_x64.exe'
          'https://download.microsoft.com/download/5/D/8/5D8C65CB-C849-4025-8E95-C3966CAFD8AE/vcredist_x86.exe'
          'https://download.microsoft.com/download/5/D/8/5D8C65CB-C849-4025-8E95-C3966CAFD8AE/vcredist_x64.exe'
          'https://download.microsoft.com/download/9/3/f/93fcf1e7-e6a4-478b-96e7-d4b285925b00/vc_redist.x64.exe'
          'https://download.microsoft.com/download/9/3/f/93fcf1e7-e6a4-478b-96e7-d4b285925b00/vc_redist.x86.exe'
        )

        $vcPath = "$PSScriptroot\VCRedists"
        if (!(Test-Path $vcPath)) {
          New-Item $vcPath -ItemType Directory | Out-Null
        }
        $i = 1
        foreach ($link in $downloadLinks) {
          Get-FileFromWeb -URL $link -File "$vcPath\VCRedist($i).exe"
          $i++
        }

        Write-Status -Message "`nInstalling C++ VCRedists..." Output
        foreach ($file in (Get-ChildItem $vcPath).FullName) {
          Start-Process -FilePath $file -ArgumentList '/q /norestart' -NoNewWindow -Wait -ErrorAction SilentlyContinue
        }

      }
      catch {
        Write-Status -Message 'Unable to Download C++ VCRedists...Check your Internet Connection' -Type Error
        Write-Status -Message 'Attempting to Download VCRedists AIO...' Output
        try {
          $vcPath = "$PSScriptroot\VCRedistsAIO"
          if (!(Test-Path $vcPath)) {
            New-Item $vcPath -ItemType Directory | Out-Null
          }
          $url = 'https://api.github.com/repos/xyzsteven/VCRedistAIO/releases/latest'
          $response = Invoke-RestMethod -Uri $url -UseBasicParsing -ErrorAction Stop
          $uri = $response.assets.browser_download_url | ForEach-Object { if ($_ -like '*VCRedistAIO*.zip') { $_ } } 
          Get-FileFromWeb $uri -File "$vcPath\VCredistAIO.zip" 
          Expand-Archive "$vcPath\VCredistAIO.zip" -DestinationPath "$vcPath"
          $batPath = (Get-ChildItem $vcPath -Filter '*.bat' ).FullName
          Start-Process cmd.exe -ArgumentList "/c `"$batPath`"" -NoNewWindow -Wait
        }
        catch {
          Write-Status -Message 'Unable to Download C++ VCRedists AIO...Check your Internet Connection' -Type Error
        }
        
      }
        
      try {
        $installDir = $PSScriptRoot 
        #install directx
        $ProgressPreference = 'SilentlyContinue'
        $dir = New-Item -Path "$tempDir\DirectXRedist" -ItemType Directory -Force
        $DXPath = New-Item -Path "$tempDir\DirectXRedist\DX" -ItemType Directory -Force
        Invoke-RestMethod -Uri 'https://download.microsoft.com/download/8/4/A/84A35BF1-DAFE-4AE8-82AF-AD2AE20B6B14/directx_Jun2010_redist.exe' -UseBasicParsing -OutFile "$tempDir\DirectXRedist\DXinstaller.exe" -ErrorAction Stop
        Start-Process -FilePath "$tempDir\DirectXRedist\DXinstaller.exe" -ArgumentList "/Q /T:`"$DXPath`" /C" -WindowStyle Hidden -Wait
        #put pack path
        Move-Item $DXPath -Destination $installDir -Force 
        Remove-Item -Path $dir -Force -Recurse
        Write-Status -Message 'Installing DirectX...' -Type Output
    
        #dirty fix for dxinstaller bug
        Start-Process "$installDir\DX\DXSETUP.exe" -ArgumentList '/silent'
        $wshell = New-Object -ComObject wscript.shell
        Start-Sleep 1
        #get title of all open windows
        $openWindows = Get-Process | Where-Object { $_.MainWindowTitle -ne '' } | Select-Object MainWindowTitle
        foreach ($window in $openWindows) {
          #if the dxinstaller is open press enter to close it and run with other command
          if ($window -like '*DirectX*') {
            $wshell.SendKeys('~')
            Start-Process "$installDir\DX\DXSETUP.exe" -ArgumentList '/quiet' -Wait
          }

        }
      }
      catch {
        Write-Status -Message 'Unable to Install DirectX...' Error
      }
    
    
      $netfx = Get-WindowsOptionalFeature -online | where-object { $_.featurename -eq 'NetFx3' }
      if ($netfx.State -ne 'Enabled') {
        if (Test-Path "$PSScriptroot\NETFX3.cab") {
          Write-Status -Message 'Installing NetFx3.5...' Output
          Dism /online /enable-feature /featurename:NetFX3 /All /Source:"$PSScriptroot\NETFX3.cab" /LimitAccess
        }
        else {
          Write-Status -Message "Unable to Find NetFx3 Cab File for Enablement in $PSScriptroot..." Output
        }
      }

      
      
      Write-Status -Message 'Cleaning up...[Running Background Tasks]' -Type Output
   
      $burntToast = Search-Directory -filter '*BurntToast'
      #steal icon from startmenu resources
      $exeImage = 'C:\Windows\SystemApps\MicrosoftWindows.Client.Core_cw5n1h2txyewy\StartMenu\Assets\FileIcons\32\exe.scale-400.png'
      $ngenPath = [System.IO.Path]::Combine([Runtime.InteropServices.RuntimeEnvironment]::GetRuntimeDirectory(), 'ngen.exe')
      $command = "Import-Module -name $burntToast; New-BurntToastNotification  -Text 'Ngen Process' , 'Running' -applogo $exeImage; [AppDomain]::CurrentDomain.GetAssemblies() | ForEach-Object { Start-process $ngenPath -ArgumentList `"install `$_.Location /silent /nologo`" -WindowStyle Hidden }; Start-process $ngenPath -ArgumentList 'update /silent /nologo' -WindowStyle Hidden -Wait; New-BurntToastNotification  -Text 'Ngen Process' , 'Complete' -applogo $exeImage" 
      Start-Process powershell -ArgumentList "-noprofile -windowstyle hidden -c $command"   

      #$command = "Import-Module -name $burntToast; New-BurntToastNotification  -Text 'DISM Process' , 'Running' -applogo $exeImage; Start-Process dism.exe -ArgumentList '/online /Cleanup-Image /StartComponentCleanup /ResetBase' -WindowStyle Hidden -Wait; New-BurntToastNotification  -Text 'DISM Process' , 'Complete' -applogo $exeImage"
      # Start-Process powershell -ArgumentList "-noprofile -windowstyle hidden -c $command" 
          
      if (!($Autorun)) {
        Custom-MsgBox -message 'Packages Installed!' -type None
      }
          
    }
        
    'Cancel' {}
        
  }
}
Export-ModuleMember -Function install-packs

function OptionalTweaks {
  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
    , [Parameter(mandatory = $false)] [bool]$opblackTheme = $false
    , [Parameter(mandatory = $false)] [bool]$opROFSW = $false 
    , [Parameter(mandatory = $false)] [bool]$optransTaskbar = $false
    , [Parameter(mandatory = $false)] [bool]$opremoveMouseSoundSchemes = $false 
    , [Parameter(mandatory = $false)] [bool]$opremoveRecycle = $false
    , [Parameter(mandatory = $false)] [bool]$opblockRazerAsus = $false
    , [Parameter(mandatory = $false)] [bool]$opremoveNetworkIcon = $false 
    , [Parameter(mandatory = $false)] [bool]$opnoDriversInUpdate = $false
    , [Parameter(mandatory = $false)] [bool]$connewFiles = $false
    , [Parameter(mandatory = $false)] [bool]$conmorePS = $false
    , [Parameter(mandatory = $false)] [bool]$consnipping = $false
    , [Parameter(mandatory = $false)] [bool]$conshutdown = $false
    , [Parameter(mandatory = $false)] [bool]$conrunAsAdmin = $false
    , [Parameter(mandatory = $false)] [bool]$conpsCmd = $false 
    , [Parameter(mandatory = $false)] [bool]$conkillTasks = $false 
    , [Parameter(mandatory = $false)] [bool]$conpermDel = $false
    , [Parameter(mandatory = $false)] [bool]$conTakeOwn = $false
    , [Parameter(mandatory = $false)] [bool]$conFavorites = $false
    , [Parameter(mandatory = $false)] [bool]$conCustomizeFolder = $false
    , [Parameter(mandatory = $false)] [bool]$conGiveAccess = $false
    , [Parameter(mandatory = $false)] [bool]$conOpenTerm = $false
    , [Parameter(mandatory = $false)] [bool]$conRestorePrev = $false
    , [Parameter(mandatory = $false)] [bool]$conPrint = $false
    , [Parameter(mandatory = $false)] [bool]$conSend = $false
    , [Parameter(mandatory = $false)] [bool]$conShare = $false
    , [Parameter(mandatory = $false)] [bool]$conPersonalize = $false
    , [Parameter(mandatory = $false)] [bool]$conDisplay = $false
    , [Parameter(mandatory = $false)] [bool]$opSecUpdatesOnly = $false
    , [Parameter(mandatory = $false)] [bool]$conExtractAll = $false
    , [Parameter(mandatory = $false)] [bool]$oppauseUpdates = $false
    , [Parameter(mandatory = $false)] [bool]$conTroubleshootComp = $false
    , [Parameter(mandatory = $false)] [bool]$conIncludeLibrary = $false
    , [Parameter(mandatory = $false)] [bool]$opStopOSUpgrade = $false
    , [Parameter(mandatory = $false)] [bool]$opDisablePowerShellLogs = $false
    , [Parameter(mandatory = $false)] [bool]$opNoGUIBoot = $false
    , [Parameter(mandatory = $false)] [bool]$opGameBarPopup = $false
    , [Parameter(mandatory = $false)] [bool]$opFastShutdownRestart = $false
    , [Parameter(mandatory = $false)] [bool]$opHideUserInStart = $false
    , [Parameter(mandatory = $false)] [bool]$opBetterW32Time = $false
    , [Parameter(mandatory = $false)] [bool]$opModernCursor = $false
    , [Parameter(mandatory = $false)] [bool]$opDarkAccents = $false
    , [Parameter(mandatory = $false)] [bool]$opNoMouseAccel = $false
    , [Parameter(mandatory = $false)] [bool]$opDisableDeviceEncryption = $false
    , [Parameter(mandatory = $false)] [bool]$opClassicAccents = $false
    , [Parameter(mandatory = $false)] [bool]$conPersonalizeClassic = $false
    , [Parameter(mandatory = $false)] [bool]$dialogAppUninstall = $false
    , [Parameter(mandatory = $false)] [bool]$dialogMergeConflicts = $false
    , [Parameter(mandatory = $false)] [bool]$dialogSyncedFileWarn = $false
    , [Parameter(mandatory = $false)] [bool]$dialogMSConfig = $false
    , [Parameter(mandatory = $false)] [bool]$dialogForAllItems = $false
    , [Parameter(mandatory = $false)] [bool]$dialogTerminalTabs = $false
    , [Parameter(mandatory = $false)] [bool]$dialogPhotosApp = $false
    , [Parameter(mandatory = $false)] [bool]$opStartMenuShortcutClean = $false
    , [Parameter(mandatory = $false)] [bool]$opStartMenuShortcuts = $false
  )
        
      
  #create checkboxes
  $checkbox2 = new-object System.Windows.Forms.checkbox
  $checkbox4 = new-object System.Windows.Forms.checkbox
  $checkbox8 = new-object System.Windows.Forms.checkbox
  $checkbox13 = new-object System.Windows.Forms.checkbox
  $checkbox14 = new-object System.Windows.Forms.checkbox
  $checkbox15 = new-object System.Windows.Forms.checkbox
  $checkbox16 = new-object System.Windows.Forms.checkbox
  $checkbox17 = new-object System.Windows.Forms.checkbox
  $checkbox18 = new-object System.Windows.Forms.checkbox
  $checkbox19 = new-object System.Windows.Forms.checkbox
  $checkbox20 = new-object System.Windows.Forms.checkbox
  $checkbox26 = new-object System.Windows.Forms.checkbox
  $checkbox23 = new-object System.Windows.Forms.checkbox
  $checkbox24 = new-object System.Windows.Forms.checkbox
  $checkbox29 = new-object System.Windows.Forms.checkbox
  $checkbox31 = new-object System.Windows.Forms.checkbox
  $checkbox33 = new-object System.Windows.Forms.checkbox
  $checkbox34 = new-object System.Windows.Forms.checkbox
  $checkbox35 = new-object System.Windows.Forms.checkbox
  $checkbox36 = new-object System.Windows.Forms.checkbox
  $checkbox37 = new-object System.Windows.Forms.checkbox    
  $checkbox38 = new-object System.Windows.Forms.checkbox 
  $checkbox39 = new-object System.Windows.Forms.checkbox
  $checkbox40 = new-object System.Windows.Forms.checkbox
  $checkbox41 = new-object System.Windows.Forms.checkbox
  $checkbox42 = new-object System.Windows.Forms.checkbox
  $checkbox43 = new-object System.Windows.Forms.checkbox
  $checkbox44 = new-object System.Windows.Forms.checkbox
  $checkbox45 = new-object System.Windows.Forms.checkbox
  $checkbox46 = new-object System.Windows.Forms.checkbox
  $checkbox47 = new-object System.Windows.Forms.checkbox
  $checkbox48 = new-object System.Windows.Forms.checkbox
  $checkbox49 = new-object System.Windows.Forms.checkbox
  $checkbox50 = new-object System.Windows.Forms.checkbox
  $checkbox51 = new-object System.Windows.Forms.checkbox
  $checkbox52 = new-object System.Windows.Forms.checkbox
  $checkbox54 = new-object System.Windows.Forms.checkbox
  $checkbox55 = new-object System.Windows.Forms.checkbox
  $checkbox57 = new-object System.Windows.Forms.checkbox
  $checkbox58 = new-object System.Windows.Forms.checkbox
  $checkbox59 = new-object System.Windows.Forms.checkbox
  $checkbox60 = new-object System.Windows.Forms.checkbox
  $checkbox61 = new-object System.Windows.Forms.checkbox 
  $checkbox62 = new-object System.Windows.Forms.checkbox
  $checkbox63 = new-object System.Windows.Forms.checkbox
  $checkbox64 = new-object System.Windows.Forms.checkbox
  $checkbox65 = new-object System.Windows.Forms.checkbox
  $checkbox66 = new-object System.Windows.Forms.checkbox
  $checkbox67 = new-object System.Windows.Forms.checkbox
  $checkbox68 = new-object System.Windows.Forms.checkbox
  $checkbox69 = new-object System.Windows.Forms.checkbox
  $checkbox70 = new-object System.Windows.Forms.checkbox
  $checkbox71 = new-object System.Windows.Forms.checkbox
  $checkbox72 = new-object System.Windows.Forms.checkbox
  $checkbox73 = new-object System.Windows.Forms.checkbox
  $checkbox74 = new-object System.Windows.Forms.checkbox
  

  #hashtable for updating config
  $settings = @{}
  $settings['opblackTheme'] = $checkbox2
  $settings['opROFSW'] = $checkbox4
  $settings['optransTaskbar'] = $checkbox8
  $settings['opblockRazerAsus'] = $checkbox13
  $settings['connewFiles'] = $checkbox14
  $settings['conmorePS'] = $checkbox15
  $settings['consnipping'] = $checkbox16
  $settings['conshutdown'] = $checkbox17
  $settings['conrunAsAdmin'] = $checkbox18
  $settings['conpsCmd'] = $checkbox19
  $settings['conkillTasks'] = $checkbox20
  $settings['conpermDel'] = $checkbox26
  $settings['opremoveNetworkIcon'] = $checkbox23
  $settings['opnoDriversInUpdate'] = $checkbox29
  $settings['opremoveMouseSoundSchemes'] = $checkbox31
  $settings['opremoveRecycle'] = $checkbox33
  $settings['conTakeOwn'] = $checkbox34
  $settings['conFavorites'] = $checkbox35
  $settings['conCustomizeFolder'] = $checkbox36
  $settings['conGiveAccess'] = $checkbox37
  $settings['conOpenTerm'] = $checkbox38
  $settings['conRestorePrev'] = $checkbox39
  $settings['conPrint'] = $checkbox40
  $settings['conSend'] = $checkbox41
  $settings['conShare'] = $checkbox42
  $settings['conPersonalize'] = $checkbox43
  $settings['conDisplay'] = $checkbox44
  $settings['opSecUpdatesOnly'] = $checkbox45
  $settings['conExtractAll'] = $checkbox46
  $settings['oppauseUpdates'] = $checkbox47
  $settings['conTroubleshootComp'] = $checkbox48
  $settings['conIncludeLibrary'] = $checkbox49
  $settings['opStopOSUpgrade'] = $checkbox50
  $settings['opDisablePowerShellLogs'] = $checkbox51
  $settings['opNoGUIBoot'] = $checkbox52
  $settings['opGameBarPopup'] = $checkbox54
  $settings['opFastShutdownRestart'] = $checkbox55
  $settings['opHideUserInStart'] = $checkbox57
  $settings['opBetterW32Time'] = $checkbox58
  $settings['opModernCursor'] = $checkbox59
  $settings['opDarkAccents'] = $checkbox60
  $settings['opNoMouseAccel'] = $checkbox61
  $settings['opDisableDeviceEncryption'] = $checkbox62
  $settings['opClassicAccents'] = $checkbox63
  $settings['conPersonalizeClassic'] = $checkbox65
  $settings['dialogAppUninstall'] = $checkbox66
  $settings['dialogMergeConflicts'] = $checkbox67
  $settings['dialogSyncedFileWarn'] = $checkbox68
  $settings['dialogMSConfig'] = $checkbox69
  $settings['dialogForAllItems'] = $checkbox70
  $settings['dialogTerminalTabs'] = $checkbox71
  $settings['dialogPhotosApp'] = $checkbox72
  $settings['opStartMenuShortcutClean'] = $checkbox73
  $settings['opStartMenuShortcuts'] = $checkbox74

  if ($AutoRun) {
    $result = [System.Windows.Forms.DialogResult]::OK
    #setting options
    $checkbox2.Checked = $opblackTheme  
    $checkbox4.Checked = $opROFSW  
    $checkbox8.Checked = $optransTaskbar
    $checkbox13.Checked = $opblockRazerAsus
    $checkbox14.Checked = $connewFiles
    $checkbox15.Checked = $conmorePS
    $checkbox16.Checked = $consnipping
    $checkbox17.Checked = $conshutdown
    $checkbox18.Checked = $conrunAsAdmin
    $checkbox19.Checked = $conpsCmd
    $checkbox20.Checked = $conkillTasks
    $checkbox26.Checked = $conpermDel
    $checkbox23.Checked = $opremoveNetworkIcon
    $checkbox29.Checked = $opnoDriversInUpdate
    $checkbox31.Checked = $opremoveMouseSoundSchemes
    $checkbox33.Checked = $opremoveRecycle
    $checkbox34.Checked = $conTakeOwn
    $checkbox35.Checked = $conFavorites
    $checkbox36.Checked = $conCustomizeFolder
    $checkbox37.Checked = $conGiveAccess
    $checkbox38.Checked = $conOpenTerm
    $checkbox39.Checked = $conRestorePrev
    $checkbox40.Checked = $conPrint
    $checkbox41.Checked = $conSend
    $checkbox42.Checked = $conShare
    $checkbox43.Checked = $conPersonalize
    $checkbox44.Checked = $conDisplay
    $checkbox45.Checked = $opSecUpdatesOnly
    $checkbox46.Checked = $conExtractAll
    $checkbox47.Checked = $oppauseUpdates
    $checkbox48.Checked = $conTroubleshootComp
    $checkbox49.Checked = $conIncludeLibrary
    $checkbox50.Checked = $opStopOSUpgrade
    $checkbox51.Checked = $opDisablePowerShellLogs
    $checkbox52.Checked = $opNoGUIBoot
    $checkbox54.Checked = $opGameBarPopup
    $checkbox55.Checked = $opFastShutdownRestart
    $checkbox57.Checked = $opHideUserInStart
    $checkbox58.Checked = $opBetterW32Time
    $checkbox59.Checked = $opModernCursor
    $checkbox60.Checked = $opDarkAccents
    $checkbox61.Checked = $opNoMouseAccel
    $checkbox62.Checked = $opDisableDeviceEncryption
    $checkbox63.Checked = $opClassicAccents
    $checkbox65.Checked = $conPersonalizeClassic
    $checkbox66.Checked = $dialogAppUninstall
    $checkbox67.Checked = $dialogMergeConflicts
    $checkbox68.Checked = $dialogSyncedFileWarn
    $checkbox69.Checked = $dialogMSConfig
    $checkbox70.Checked = $dialogForAllItems
    $checkbox71.Checked = $dialogTerminalTabs
    $checkbox72.Checked = $dialogPhotosApp
    $checkbox73.Checked = $opStartMenuShortcutClean
    $checkbox74.Checked = $opStartMenuShortcuts

  }
  else {
    [void] [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
    [void] [System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')
    [System.Windows.Forms.Application]::EnableVisualStyles()

    # Set the size of your form
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Optional Tweaks'
    $form.Size = New-Object System.Drawing.Size(800, 600)
    $form.StartPosition = 'CenterScreen'
    $form.BackColor = 'Black'
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 8)

    $type = $form.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($form, $true, $null)

    # Sidebar Panel
    $sidebarPanel = New-Object System.Windows.Forms.Panel
    $sidebarPanel.Location = New-Object System.Drawing.Point(0, 0)
    $sidebarPanel.Size = New-Object System.Drawing.Size(150, $form.ClientSize.Height)
    $sidebarPanel.BackColor = 'Black'

    $type = $sidebarPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($sidebarPanel, $true, $null)

    # Sidebar Buttons
    $generalBtn = Create-ModernButton -Text 'General' -Location (New-Object System.Drawing.Point(15, 10)) -Size (New-Object System.Drawing.Size(130, 40)) -ClickAction {
      $generalPanel.Visible = $true
      $contextMenuPanel.Visible = $false
      $dialogPanel.Visible = $false
      $generalPanel.Controls.Add($CancelButton)
      $generalPanel.Controls.Add($OKButton)
      $generalBtn.Tag = 'Active'
      $contextMenuBtn.Tag = 'Inactive'
      $dialogbttn.Tag = 'Inactive'
      $generalBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $contextMenuBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $dialogbttn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
    } -r 47 -g 49 -b 58 
  
    $generalBtn.Tag = 'Inactive'
    $sidebarPanel.Controls.Add($generalBtn)

    $contextMenuBtn = Create-ModernButton -Text 'Context Menu' -Location (New-Object System.Drawing.Point(15, 60)) -Size (New-Object System.Drawing.Size(130, 40)) -ClickAction {
      $generalPanel.Visible = $false
      $contextMenuPanel.Visible = $true
      $dialogPanel.Visible = $false
      $contextmenuPanel.Controls.Add($CancelButton)
      $contextMenuPanel.Controls.Add($OKButton)
      $contextMenuBtn.Tag = 'Active'
      $generalBtn.Tag = 'Inactive'
      $dialogbttn.Tag = 'Inactive'
      $contextMenuBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $generalBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $dialogbttn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
    } -r 47 -g 49 -b 58
  
    $contextMenuBtn.Tag = 'Inactive'
    $sidebarPanel.Controls.Add($contextMenuBtn)

    $dialogbttn = Create-ModernButton -Text 'Dialogs' -Location (New-Object System.Drawing.Point(15, 110)) -Size (New-Object System.Drawing.Size(130, 40)) -ClickAction {
      $generalPanel.Visible = $false
      $contextMenuPanel.Visible = $false
      $dialogPanel.Visible = $true
      $dialogPanel.Controls.Add($CancelButton)
      $dialogPanel.Controls.Add($OKButton)
      $contextMenuBtn.Tag = 'Inactive'
      $generalBtn.Tag = 'Inactive'
      $dialogbttn.Tag = 'Active'
      $contextMenuBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $generalBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $dialogbttn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
    } -r 47 -g 49 -b 58

    $dialogbttn.Tag = 'Inactive'
    $sidebarPanel.Controls.Add($dialogbttn)

    $form.Controls.Add($sidebarPanel)


    $url = 'https://github.com/MP7BDO/mpware/blob/main/features.md#optional-tweaks'
    $infobutton = New-Object Windows.Forms.Button
    $infobutton.Location = New-Object Drawing.Point(5, 530) # Adjusted to bottom-left of sidebar
    $infobutton.Size = New-Object Drawing.Size(30, 27)
    $infobutton.Cursor = 'Hand'
    $infobutton.Add_Click({
        try {
          Start-Process $url -ErrorAction Stop
        }
        catch {
          Write-Status -Message 'No Internet Connected...' -Type Error
        }
      })
    $infobutton.BackColor = 'Black'
    $image = [System.Drawing.Image]::FromFile('C:\Windows\System32\SecurityAndMaintenance.png')
    $resizedImage = New-Object System.Drawing.Bitmap $image, 24, 25
    $infobutton.Image = $resizedImage
    $infobutton.ImageAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $infobutton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $infobutton.FlatAppearance.BorderSize = 0
    $sidebarPanel.Controls.Add($infobutton)


    $resetCheckedBttn = New-Object Windows.Forms.Button
    $resetCheckedBttn.Location = New-Object Drawing.Point(45, 530) # Adjusted to bottom-left of sidebar
    $resetCheckedBttn.Size = New-Object Drawing.Size(30, 27)
    $resetCheckedBttn.Cursor = 'Hand'
    $resetCheckedBttn.Add_Click({
        $Global:enabledOptions = @()
        function Get-AllControls($parent) {
          foreach ($control in $parent.Controls) {
            $control
            if ($control.Controls.Count -gt 0) {
              Get-AllControls $control
            }
          }
        }
        Get-AllControls $form | Where-Object { $_ -is [System.Windows.Forms.CheckBox] } | ForEach-Object { 
          $_.Checked = $false 
          $_.ForeColor = 'White'
        }
        
      })
    $resetCheckedBttn.BackColor = 'Black'
    $resetCheckedBttn.Text = 'X'
    $resetCheckedBttn.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $resetCheckedBttn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $resetCheckedBttn.FlatAppearance.BorderSize = 0
    $sidebarPanel.Controls.Add($resetCheckedBttn)

    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($resetCheckedBttn, 'Reset currently checked tweaks')

    # Main Content Panel
    $contentPanel = New-Object System.Windows.Forms.Panel
    $contentPanel.Location = New-Object System.Drawing.Point(160, 0)
    $contentPanel.Size = New-Object System.Drawing.Size(625, 600)
    # $contentPanel.BackColor = [System.Drawing.Color]::FromArgb(65, 65, 65)
    $form.Controls.Add($contentPanel)

    $type = $contentPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($contentPanel, $true, $null)

    # General Panel
    $generalPanel = New-Object System.Windows.Forms.Panel
    $generalPanel.Location = New-Object System.Drawing.Point(0, 0)
    $generalPanel.Size = New-Object System.Drawing.Size(625, $form.ClientSize.Height)
    # $generalPanel.BackColor = [System.Drawing.Color]::FromArgb(65, 65, 65)
    $generalPanel.Visible = $true
    $contentPanel.Controls.Add($generalPanel)

    $type = $generalPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($generalPanel, $true, $null)

    $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
    $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

    # Override the form's paint event to apply the gradient
    $generalPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $generalPanel.Width, $generalPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    # Context Menu Panel
    $contextMenuPanel = New-Object System.Windows.Forms.Panel
    $contextMenuPanel.Location = New-Object System.Drawing.Point(0, 0)
    $contextMenuPanel.Size = New-Object System.Drawing.Size(625, $form.ClientSize.Height)
    # $contextMenuPanel.BackColor = [System.Drawing.Color]::FromArgb(65, 65, 65)
    $contextMenuPanel.Visible = $false
    $contentPanel.Controls.Add($contextMenuPanel)

    $type = $contextMenuPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($contextMenuPanel, $true, $null)

    # Override the form's paint event to apply the gradient
    $contextMenuPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $contextMenuPanel.Width, $contextMenuPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    $dialogpanel = New-Object System.Windows.Forms.Panel
    $dialogpanel.Location = New-Object System.Drawing.Point(0, 0)
    $dialogpanel.Size = New-Object System.Drawing.Size(625, $form.ClientSize.Height)
    $dialogpanel.Visible = $false
    $contentPanel.Controls.Add($dialogpanel)

    $type = $dialogpanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($dialogpanel, $true, $null)

    # Override the form's paint event to apply the gradient
    $dialogpanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $dialogpanel.Width, $dialogpanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    # Labels
    $label1 = New-Object System.Windows.Forms.Label
    $label1.Location = New-Object System.Drawing.Point(10, 10)
    $label1.Size = New-Object System.Drawing.Size(200, 20)
    $label1.Text = 'General'
    $label1.ForeColor = 'White'
    $label1.BackColor = [System.Drawing.Color]::Transparent
    $label1.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $generalPanel.Controls.Add($label1)

    $label2 = New-Object System.Windows.Forms.Label
    $label2.Location = New-Object System.Drawing.Point(20, 10)
    $label2.Size = New-Object System.Drawing.Size(200, 20)
    $label2.Text = 'Context Menu'
    $label2.ForeColor = 'White'
    $label2.BackColor = [System.Drawing.Color]::Transparent
    $label2.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $contextMenuPanel.Controls.Add($label2)

    $label3 = New-Object System.Windows.Forms.Label
    $label3.Location = New-Object System.Drawing.Point(270, 10)
    $label3.Size = New-Object System.Drawing.Size(200, 20)
    $label3.Text = ''
    $label3.ForeColor = 'White'
    $label3.BackColor = [System.Drawing.Color]::Transparent
    $label3.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $contextMenuPanel.Controls.Add($label3)

    $label4 = New-Object System.Windows.Forms.Label
    $label4.Location = New-Object System.Drawing.Point(20, 10)
    $label4.Size = New-Object System.Drawing.Size(200, 30)
    $label4.Text = 'Disable Dialog Popups'
    $label4.ForeColor = 'White'
    $label4.BackColor = [System.Drawing.Color]::Transparent
    $label4.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $dialogpanel.Controls.Add($label4)

    $visualGroupBox = New-Object System.Windows.Forms.GroupBox
    $visualGroupBox.Location = New-Object System.Drawing.Size(20, 40)
    $visualGroupBox.Size = New-Object System.Drawing.Size(260, 250)
    $visualGroupBox.Text = 'Visual Changes'
    $visualGroupBox.ForeColor = [System.Drawing.Color]::FromArgb(175, 195, 255)
    $visualGroupBox.BackColor = [System.Drawing.Color]::Transparent
    $generalPanel.Controls.Add($visualGroupBox)

    # $visualgroupBox.Add_Paint({
    #     param($sender, $e)
    #     $pen = New-Object System.Drawing.Pen($sender.ForeColor) # Use ForeColor (text color) for the border
    #     $textHeight = $sender.Font.Height + 2
    #     $e.Graphics.DrawRectangle($pen, 0, $textHeight, $sender.Width - 1, $sender.Height - $textHeight - 1)
    #     $pen.Dispose()
    #   })
    
    $updateGroupBox = New-Object System.Windows.Forms.GroupBox
    $updateGroupBox.Location = New-Object System.Drawing.Size(290, 40)
    $updateGroupBox.Size = New-Object System.Drawing.Size(260, 250)
    $updateGroupBox.Text = 'Windows Update'
    $updateGroupBox.ForeColor = [System.Drawing.Color]::FromArgb(175, 195, 255)
    $updateGroupBox.BackColor = [System.Drawing.Color]::Transparent
    $generalPanel.Controls.Add($updateGroupBox)
    
    $miscGroupBox = New-Object System.Windows.Forms.GroupBox
    $miscGroupBox.Location = New-Object System.Drawing.Size(20, 295)
    $miscGroupBox.Size = New-Object System.Drawing.Size(550, 200)
    $miscGroupBox.Text = 'Miscellaneous'
    $miscGroupBox.ForeColor = [System.Drawing.Color]::FromArgb(175, 195, 255)
    $miscGroupBox.BackColor = [System.Drawing.Color]::Transparent
    $generalPanel.Controls.Add($miscGroupBox)
    
    # Visual Changes Checkboxes
    $checkbox2.Location = New-Object System.Drawing.Size(10, 20)
    $checkbox2.Size = New-Object System.Drawing.Size(120, 30)
    $checkbox2.Text = 'Black Theme'
    $checkbox2.ForeColor = 'White'
    $visualGroupBox.Controls.Add($checkbox2)
    
    $checkbox8.Location = New-Object System.Drawing.Size(10, 45)
    $checkbox8.Size = New-Object System.Drawing.Size(200, 30)
    $checkbox8.Text = 'Transparent TaskBar'
    $checkbox8.ForeColor = 'White'
    $visualGroupBox.Controls.Add($checkbox8)
    
    
    $checkbox23.Location = New-Object System.Drawing.Size(10, 70)
    $checkbox23.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox23.Text = 'Remove Network Icon From File Explorer'
    $checkbox23.ForeColor = 'White'
    $visualGroupBox.Controls.Add($checkbox23)
    
    $checkbox33.Location = New-Object System.Drawing.Size(10, 95)
    $checkbox33.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox33.Text = 'Remove Recycle Bin Name'
    $checkbox33.ForeColor = 'White'
    $visualGroupBox.Controls.Add($checkbox33)
    
    $checkbox31.Location = New-Object System.Drawing.Size(10, 120)
    $checkbox31.Size = New-Object System.Drawing.Size(210, 30)
    $checkbox31.Text = 'Remove Mouse and Sound Schemes'
    $checkbox31.ForeColor = 'White'
    $checkbox31.Checked = $false
    $visualGroupBox.Controls.Add($checkbox31)
    
    
    $checkbox57.Location = New-Object System.Drawing.Size(10, 145)
    $checkbox57.Size = New-Object System.Drawing.Size(230, 30)
    $checkbox57.Text = 'Hide User Tile In Start Menu'
    $checkbox57.ForeColor = 'White'
    $checkbox57.Checked = $false
    $visualGroupBox.Controls.Add($checkbox57)

    $checkbox59.Location = New-Object System.Drawing.Size(10, 170)
    $checkbox59.Size = New-Object System.Drawing.Size(230, 30)
    $checkbox59.Text = 'Modern Cursor Scheme'
    $checkbox59.ForeColor = 'White'
    $checkbox59.Checked = $false
    $visualGroupBox.Controls.Add($checkbox59)

    $checkbox60.Location = New-Object System.Drawing.Size(10, 195)
    $checkbox60.Size = New-Object System.Drawing.Size(230, 30)
    $checkbox60.Text = 'Enable Dark Accents'
    $checkbox60.ForeColor = 'White'
    $checkbox60.Checked = $false
    $visualGroupBox.Controls.Add($checkbox60)

    $checkbox63.Location = New-Object System.Drawing.Size(10, 220)
    $checkbox63.Size = New-Object System.Drawing.Size(230, 30)
    $checkbox63.Text = 'Enable Classic Accents'
    $checkbox63.ForeColor = 'White'
    $checkbox63.Checked = $false
    $visualGroupBox.Controls.Add($checkbox63)
    
    # Windows Update Checkboxes
    $checkbox29.Location = New-Object System.Drawing.Size(10, 20)
    $checkbox29.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox29.Text = 'Do not include drivers in Windows Update'
    $checkbox29.ForeColor = 'White'
    $checkbox29.Checked = $false
    $updateGroupBox.Controls.Add($checkbox29)
    
    $checkbox45.Location = New-Object System.Drawing.Size(10, 45)
    $checkbox45.Size = New-Object System.Drawing.Size(210, 30)
    $checkbox45.Text = 'Security Updates Only'
    $checkbox45.ForeColor = 'White'
    $checkbox45.Checked = $false
    $updateGroupBox.Controls.Add($checkbox45)
    
    $checkbox47.Location = New-Object System.Drawing.Size(10, 70)
    $checkbox47.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox47.Text = 'Pause Updates for 1 Year'
    $checkbox47.ForeColor = 'White'
    $checkbox47.Checked = $false
    $updateGroupBox.Controls.Add($checkbox47)
    
    $checkbox50.Location = New-Object System.Drawing.Size(10, 95)
    $checkbox50.Size = New-Object System.Drawing.Size(210, 30)
    $checkbox50.Text = 'Prevent OS Upgrade'
    $checkbox50.ForeColor = 'White'
    $checkbox50.Checked = $false
    $updateGroupBox.Controls.Add($checkbox50)
    
    # Miscellaneous Checkboxes
    $checkbox4.Location = New-Object System.Drawing.Size(10, 20)
    $checkbox4.Size = New-Object System.Drawing.Size(210, 30)
    $checkbox4.Text = 'Remove Open File Security Warning'
    $checkbox4.ForeColor = 'White'
    $checkbox4.Checked = $false
    $miscGroupBox.Controls.Add($checkbox4)

    
    $checkbox13.Location = New-Object System.Drawing.Size(10, 45)
    $checkbox13.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox13.Text = 'Block Razer and ASUS Download Servers'
    $checkbox13.ForeColor = 'White'
    $checkbox13.Checked = $false
    $miscGroupBox.Controls.Add($checkbox13)
    
    $checkbox51.Location = New-Object System.Drawing.Size(10, 95)
    $checkbox51.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox51.Text = 'Disable PowerShell Logging'
    $checkbox51.ForeColor = 'White'
    $checkbox51.Checked = $false
    $miscGroupBox.Controls.Add($checkbox51)
    
    $checkbox52.Location = New-Object System.Drawing.Size(10, 120)
    $checkbox52.Size = New-Object System.Drawing.Size(210, 30)
    $checkbox52.Text = 'Enable No GUI Boot'
    $checkbox52.ForeColor = 'White'
    $checkbox52.Checked = $false
    $miscGroupBox.Controls.Add($checkbox52)
    
    $checkbox54.Location = New-Object System.Drawing.Size(270, 20)
    $checkbox54.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox54.Text = 'Disable Game Bar Popup'
    $checkbox54.ForeColor = 'White'
    $checkbox54.Checked = $false
    $miscGroupBox.Controls.Add($checkbox54)
    
    $checkbox55.Location = New-Object System.Drawing.Size(270, 45)
    $checkbox55.Size = New-Object System.Drawing.Size(220, 30)
    $checkbox55.Text = 'Enable Fast Shutdown/Restart'
    $checkbox55.ForeColor = 'White'
    $checkbox55.Checked = $false
    $miscGroupBox.Controls.Add($checkbox55)
    
    $checkbox58.Location = New-Object System.Drawing.Size(270, 70)
    $checkbox58.Size = New-Object System.Drawing.Size(260, 30)
    $checkbox58.Text = 'Use More Accurate Time Server for System Clock'
    $checkbox58.ForeColor = 'White'
    $checkbox58.Checked = $false
    $miscGroupBox.Controls.Add($checkbox58)

    $checkbox61.Location = New-Object System.Drawing.Size(270, 95)
    $checkbox61.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox61.Text = 'No Mouse Accel on Desktop'
    $checkbox61.ForeColor = 'White'
    $checkbox61.Checked = $false
    $miscGroupBox.Controls.Add($checkbox61)

    $checkbox62.Location = New-Object System.Drawing.Size(270, 120)
    $checkbox62.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox62.Text = 'Disable Device Encryption'
    $checkbox62.ForeColor = 'White'
    $checkbox62.Checked = $false
    $miscGroupBox.Controls.Add($checkbox62)

    $checkbox73.Location = New-Object System.Drawing.Size(270, 145)
    $checkbox73.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox73.Text = 'Cleanup 3rd Party App Start Menu Shortcuts'
    $checkbox73.ForeColor = 'White'
    $checkbox73.Checked = $false
    $miscGroupBox.Controls.Add($checkbox73)

    $checkbox74.Location = New-Object System.Drawing.Size(10, 145)
    $checkbox74.Size = New-Object System.Drawing.Size(240, 30)
    $checkbox74.Text = 'Create Shortcut to Start Menu Locations'
    $checkbox74.ForeColor = 'White'
    $checkbox74.Checked = $false
    $miscGroupBox.Controls.Add($checkbox74)


    # Context Menu Checkboxes
    $checkbox14.Location = New-Object System.Drawing.Size(20, 40)
    $checkbox14.Size = New-Object System.Drawing.Size(225, 20)
    $checkbox14.Text = "Additional files to `New` Menu"
    $checkbox14.ForeColor = 'White'
    $checkbox14.Checked = $false
    $form.Controls.Add($checkbox14)
    $contextMenuPanel.Controls.Add($checkbox14)

    $checkbox15.Location = New-Object System.Drawing.Size(20, 70)
    $checkbox15.Size = New-Object System.Drawing.Size(190, 20)
    $checkbox15.Text = 'Additional ps1 options'
    $checkbox15.ForeColor = 'White'
    $checkbox15.Checked = $false
    $form.Controls.Add($checkbox15)
    $contextMenuPanel.Controls.Add($checkbox15)

    $checkbox16.Location = New-Object System.Drawing.Size(20, 100)
    $checkbox16.Size = New-Object System.Drawing.Size(190, 20)
    $checkbox16.Text = 'Snipping Tool'
    $checkbox16.ForeColor = 'White'
    $checkbox16.Checked = $false
    $form.Controls.Add($checkbox16)
    $contextMenuPanel.Controls.Add($checkbox16)

    $checkbox17.Location = New-Object System.Drawing.Size(20, 130)
    $checkbox17.Size = New-Object System.Drawing.Size(190, 20)
    $checkbox17.Text = 'Shutdown'
    $checkbox17.ForeColor = 'White'
    $checkbox17.Checked = $false
    $form.Controls.Add($checkbox17)
    $contextMenuPanel.Controls.Add($checkbox17)

    $checkbox18.Location = New-Object System.Drawing.Size(20, 160)
    $checkbox18.Size = New-Object System.Drawing.Size(250, 20)
    $checkbox18.Text = 'Run as Admin for ps1,bat,vbs files'
    $checkbox18.ForeColor = 'White'
    $checkbox18.Checked = $false
    $form.Controls.Add($checkbox18)
    $contextMenuPanel.Controls.Add($checkbox18)

    $checkbox19.Location = New-Object System.Drawing.Size(20, 190)
    $checkbox19.Size = New-Object System.Drawing.Size(250, 20)
    $checkbox19.Text = 'Powershell and Cmd'
    $checkbox19.ForeColor = 'White'
    $checkbox19.Checked = $false
    $form.Controls.Add($checkbox19)
    $contextMenuPanel.Controls.Add($checkbox19)

    $checkbox20.Location = New-Object System.Drawing.Size(20, 220)
    $checkbox20.Size = New-Object System.Drawing.Size(250, 20)
    $checkbox20.Text = 'Kill not Responding Tasks'
    $checkbox20.ForeColor = 'White'
    $checkbox20.Checked = $false
    $form.Controls.Add($checkbox20)
    $contextMenuPanel.Controls.Add($checkbox20)

    $checkbox26.Location = New-Object System.Drawing.Size(20, 250)
    $checkbox26.Size = New-Object System.Drawing.Size(250, 20)
    $checkbox26.Text = 'Delete Permanently'
    $checkbox26.ForeColor = 'White'
    $checkbox26.Checked = $false
    $form.Controls.Add($checkbox26)
    $contextMenuPanel.Controls.Add($checkbox26)

    $checkbox34.Location = New-Object System.Drawing.Size(20, 280)
    $checkbox34.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox34.Text = 'Take Ownership'
    $checkbox34.ForeColor = 'White'
    $checkbox34.Checked = $false
    $form.Controls.Add($checkbox34)
    $contextMenuPanel.Controls.Add($checkbox34)

    $checkbox35.Location = New-Object System.Drawing.Size(270, 40)
    $checkbox35.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox35.Text = 'Add to Favorites'
    $checkbox35.ForeColor = 'White'
    $checkbox35.Checked = $false
    $form.Controls.Add($checkbox35)
    $contextMenuPanel.Controls.Add($checkbox35)

    $checkbox36.Location = New-Object System.Drawing.Size(270, 70)
    $checkbox36.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox36.Text = 'Customize this Folder'
    $checkbox36.ForeColor = 'White'
    $checkbox36.Checked = $false
    $form.Controls.Add($checkbox36)
    $contextMenuPanel.Controls.Add($checkbox36)

    $checkbox37.Location = New-Object System.Drawing.Size(270, 100)
    $checkbox37.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox37.Text = 'Give Access to'
    $checkbox37.ForeColor = 'White'
    $checkbox37.Checked = $false
    $form.Controls.Add($checkbox37)
    $contextMenuPanel.Controls.Add($checkbox37)

    $checkbox38.Location = New-Object System.Drawing.Size(270, 130)
    $checkbox38.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox38.Text = 'Open in Terminal (Win 11)'
    $checkbox38.ForeColor = 'White'
    $checkbox38.Checked = $false
    $form.Controls.Add($checkbox38)
    $contextMenuPanel.Controls.Add($checkbox38)

    $checkbox39.Location = New-Object System.Drawing.Size(270, 160)
    $checkbox39.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox39.Text = 'Restore Previous Versions'
    $checkbox39.ForeColor = 'White'
    $checkbox39.Checked = $false
    $form.Controls.Add($checkbox39)
    $contextMenuPanel.Controls.Add($checkbox39)

    $checkbox40.Location = New-Object System.Drawing.Size(270, 190)
    $checkbox40.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox40.Text = 'Print'
    $checkbox40.ForeColor = 'White'
    $checkbox40.Checked = $false
    $form.Controls.Add($checkbox40)
    $contextMenuPanel.Controls.Add($checkbox40)

    $checkbox41.Location = New-Object System.Drawing.Size(270, 220)
    $checkbox41.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox41.Text = 'Send to'
    $checkbox41.ForeColor = 'White'
    $checkbox41.Checked = $false
    $form.Controls.Add($checkbox41)
    $contextMenuPanel.Controls.Add($checkbox41)

    $checkbox42.Location = New-Object System.Drawing.Size(270, 250)
    $checkbox42.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox42.Text = 'Share'
    $checkbox42.ForeColor = 'White'
    $checkbox42.Checked = $false
    $form.Controls.Add($checkbox42)
    $contextMenuPanel.Controls.Add($checkbox42)

    $checkbox43.Location = New-Object System.Drawing.Size(270, 280)
    $checkbox43.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox43.Text = 'Personalize (Desktop)'
    $checkbox43.ForeColor = 'White'
    $checkbox43.Checked = $false
    $form.Controls.Add($checkbox43)
    $contextMenuPanel.Controls.Add($checkbox43)

    $checkbox44.Location = New-Object System.Drawing.Size(270, 310)
    $checkbox44.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox44.Text = 'Display (Desktop)'
    $checkbox44.ForeColor = 'White'
    $checkbox44.Checked = $false
    $form.Controls.Add($checkbox44)
    $contextMenuPanel.Controls.Add($checkbox44)

    $checkbox46.Location = New-Object System.Drawing.Size(270, 340)
    $checkbox46.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox46.Text = 'Extract All for Archive Files'
    $checkbox46.ForeColor = 'White'
    $checkbox46.Checked = $false
    $form.Controls.Add($checkbox46)
    $contextMenuPanel.Controls.Add($checkbox46)

    $checkbox48.Location = New-Object System.Drawing.Size(270, 370)
    $checkbox48.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox48.Text = 'Troubleshoot Compatibility'
    $checkbox48.ForeColor = 'White'
    $checkbox48.Checked = $false
    $form.Controls.Add($checkbox48)
    $contextMenuPanel.Controls.Add($checkbox48)

    $checkbox49.Location = New-Object System.Drawing.Size(270, 400)
    $checkbox49.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox49.Text = 'Include in Library'
    $checkbox49.ForeColor = 'White'
    $checkbox49.Checked = $false
    $form.Controls.Add($checkbox49)
    $contextMenuPanel.Controls.Add($checkbox49)

    $checkbox65.Location = New-Object System.Drawing.Size(20, 310)
    $checkbox65.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox65.Text = 'Legacy Control Panel Settings'
    $checkbox65.ForeColor = 'White'
    $checkbox65.Checked = $false
    $form.Controls.Add($checkbox65)
    $contextMenuPanel.Controls.Add($checkbox65)

    $checkbox17.Location = New-Object System.Drawing.Size(20, 40)
    $checkbox18.Location = New-Object System.Drawing.Size(20, 70)
    $checkbox20.Location = New-Object System.Drawing.Size(20, 100)
    @(
      $checkbox14, $checkbox15, $checkbox16, $checkbox19, $checkbox26, $checkbox34,
      $checkbox35, $checkbox36, $checkbox37, $checkbox38, $checkbox39, $checkbox40,
      $checkbox41, $checkbox42, $checkbox43, $checkbox44, $checkbox46, $checkbox48,
      $checkbox49, $checkbox65
    ) | ForEach-Object {
      $_.Checked = $false
      $_.Visible = $false
    }


    $checkbox66.Location = New-Object System.Drawing.Size(20, 50)
    $checkbox66.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox66.Text = 'Do not show uninstall app warning'
    $checkbox66.ForeColor = 'White'
    $checkbox66.Checked = $false
    $form.Controls.Add($checkbox66)
    $dialogpanel.Controls.Add($checkbox66)
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($checkbox66, 'Do not show the uninstall app warning in control panel (appwiz.cpl)')

    $checkbox67.Location = New-Object System.Drawing.Size(20, 80)
    $checkbox67.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox67.Text = 'Hide merge conflicts in Explorer'
    $checkbox67.ForeColor = 'White'
    $checkbox67.Checked = $false
    $form.Controls.Add($checkbox67)
    $dialogpanel.Controls.Add($checkbox67)
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($checkbox67, 'Do not show the merge conflict warning dialog for files and folders in explorer')

    $checkbox68.Location = New-Object System.Drawing.Size(20, 110)
    $checkbox68.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox68.Text = 'Do not show delete synced file warning'
    $checkbox68.ForeColor = 'White'
    $checkbox68.Checked = $false
    $form.Controls.Add($checkbox68)
    $dialogpanel.Controls.Add($checkbox68)
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($checkbox68, 'Do not show delete file/folder warning when its synced by OneDrive')

    $checkbox69.Location = New-Object System.Drawing.Size(20, 140)
    $checkbox69.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox69.Text = 'Do not show restart required in MSConfig'
    $checkbox69.ForeColor = 'White'
    $checkbox69.Checked = $false
    $form.Controls.Add($checkbox69)
    $dialogpanel.Controls.Add($checkbox69)
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($checkbox69, 'Do not show restart required dialog when changing settings in MSConfig')

    $checkbox70.Location = New-Object System.Drawing.Size(20, 170)
    $checkbox70.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox70.Text = 'Check "Do this for all items" in Explorer'
    $checkbox70.ForeColor = 'White'
    $checkbox70.Checked = $false
    $form.Controls.Add($checkbox70)
    $dialogpanel.Controls.Add($checkbox70)
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($checkbox70, 'Check do this for all items in explorer when performing an action on multiple files/folders')

    $checkbox71.Location = New-Object System.Drawing.Size(20, 200)
    $checkbox71.Size = New-Object System.Drawing.Size(280, 30)
    $checkbox71.Text = 'Do not warn when closing multiple tabs in Terminal'
    $checkbox71.ForeColor = 'White'
    $checkbox71.Checked = $false
    $form.Controls.Add($checkbox71)
    $dialogpanel.Controls.Add($checkbox71)
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($checkbox71, 'Do not warn when closing multiple tabs in Terminal')

    $checkbox72.Location = New-Object System.Drawing.Size(20, 230)
    $checkbox72.Size = New-Object System.Drawing.Size(280, 30)
    $checkbox72.Text = 'Do not show delete photo warning in Photos App'
    $checkbox72.ForeColor = 'White'
    $checkbox72.Checked = $false
    $form.Controls.Add($checkbox72)
    $dialogpanel.Controls.Add($checkbox72)
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($checkbox72, 'Do not show delete file/photo warning in Photos App')

    foreach ($setting in $settings.GetEnumerator()) {
      if ($Global:enabledOptions -contains $setting.key) {
        $setting.value.ForeColor = [System.Drawing.Color]::Gray
        $setting.value.checked = $true
      }
    }


    $OKButton = Create-ModernButton -Text 'OK' -Location (New-Object System.Drawing.Point(350, 520)) -Size (New-Object System.Drawing.Size(120, 27)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2

    # OK and Cancel Buttons
    <#
    $OKButton = New-Object System.Windows.Forms.Button
    $OKButton.Location = New-Object System.Drawing.Point(340, 520)
    $OKButton.Size = New-Object System.Drawing.Size(100, 23)
    $OKButton.Text = 'OK'
    $OKButton.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $OKButton.ForeColor = [System.Drawing.Color]::White
    $OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.AcceptButton = $OKButton
    #>
    $generalPanel.Controls.Add($OKButton)
   
    $CancelButton = Create-ModernButton -Text 'Cancel' -Location (New-Object System.Drawing.Point(480, 520)) -Size (New-Object System.Drawing.Size(120, 27)) -DialogResult ([System.Windows.Forms.DialogResult]::Cancel) -borderSize 2
    <#
    $CancelButton = New-Object System.Windows.Forms.Button
    $CancelButton.Location = New-Object System.Drawing.Point(450, 520)
    $CancelButton.Size = New-Object System.Drawing.Size(100, 23)
    $CancelButton.Text = 'Cancel'
    $CancelButton.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    $CancelButton.ForeColor = [System.Drawing.Color]::White
    $CancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.CancelButton = $CancelButton
    #>
    $generalPanel.Controls.Add($CancelButton)
    
    $contextMenuPanel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }

    $dialogpanel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }
  


    # Activate the form
    $form.Add_Shown({ $form.Activate() })
    $result = $form.ShowDialog()
  }
      
      
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
      
    if (!($Autorun)) {
      #loop through checkbox hashtable to update config
      $settings.GetEnumerator() | ForEach-Object {
            
        $settingName = $_.Key
        $checkbox = $_.Value
        #dont update config with options already checked
        if ($Global:enabledOptions -contains $settingName) {
          $checkbox.Checked = $false
        }
        
        if ($checkbox.Checked) {
          update-config -setting $settingName -value 1
        }
      }
    } 
      
    if ($checkbox2.Checked) {
      Write-Status -Message 'Applying Black Theme...' -Type Output
      #ensure transparency is disabled since on some new builds it blocks the black color
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' /v 'EnableTransparency' /t REG_DWORD /d '0' /f

    
      $path = Search-File '*BlackTheme.reg'      
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist @('/s', $path)
      
              
      #setting lockscreen to black
      reg.exe delete 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System' /v 'DisableLogonBackgroundImage' /f *>$null
      
      $path = Search-File '*Black.jpg'
      Move-Item $path -Destination 'C:\Windows' -Force
      
      New-Item -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP' -Force
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP' -Name 'LockScreenImagePath' -Value 'C:\Windows\Black.jpg' -Force
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP' -Name 'LockScreenImageStatus' -Value 1

      #change user pfp to black themed

      #if user is using a ms account the method is different to change the pfp
      #this will only change for this pc not the actual account 
      $user = Get-LocalUser -Name $env:UserName 
      if ($user.PrincipalSource -eq 'MicrosoftAccount') {
        $msaBlackPfp = Search-Directory '*blackPfpMSAccount'
        $script = Search-File '*BlackPfpMSAccount.ps1'
        $command = "&$script -pfpPath $msablackpfp"
        Run-Trusted -command $command
        
      }
      else {
        $userPfps = Search-Directory '*blackUserPics'
        $pfps = (Get-ChildItem -Path $userPfps).FullName
        #backup default pics
        if (!(Test-Path "$env:USERPROFILE\zBackup")) {
          New-Item "$env:USERPROFILE\zBackup" -ItemType Directory | Out-Null
        }
        $backup = New-Item "$env:USERPROFILE\zBackup\defaultUserPics" -ItemType Directory 
        $defaultUserPics = (Get-ChildItem -Path "$env:ProgramData\Microsoft\User Account Pictures" -Exclude '*.dat').FullName
        foreach ($pfp in $defaultUserPics) {
          Move-Item -Path $pfp -Destination $backup.FullName -Force 
        }
        #add black pics to multiple locations so that it updates all
        foreach ($blackPfp in $pfps) {
          Copy-Item $blackPfp -Destination "$env:ProgramData\Microsoft\User Account Pictures" -Force
        }
      
        $publicFolder = New-Item -Path "C:\Users\Public\AccountPictures\$env:USERNAME" -ItemType Directory -Force
        $userSID = Get-CimInstance Win32_UserAccount | Select-Object SID -First 1
        $regPath = New-Item -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AccountPicture\Users' -Name $userSID.SID -Force
        foreach ($blackPfp in $pfps) {
          $file = Copy-Item $blackPfp -Destination $publicFolder.FullName -Force -PassThru
          if ($file.FullName -match '\d+\.*') {
            $junk, $size = $file.FullName -split '-'
            $size = $size -replace '.png' , ''
          }
          else {
            $size = '448'
          }
          New-ItemProperty -Path "registry::$($regPath.Name)" -Name "Image$size" -Value $file.FullName -Force
        }
      }
      
      
     
    }

    
            
    if ($checkbox4.Checked) {
      Write-Status -Message 'Disabling Blocked Files...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Internet Explorer\Security' /V 'DisableSecuritySettingsCheck' /T 'REG_DWORD' /D '00000001' /F
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3' /V '1806' /T 'REG_DWORD' /D '00000000' /F
      Reg.exe add 'HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3' /V '1806' /T 'REG_DWORD' /D '00000000' /F
      
    }
   
   
    if ($checkbox8.checked) {
      Write-Status -Message 'Applying Transparent Taskbar...' -Type Output
      $transTB = Search-File '*bundle.msixbundle'
      Add-AppxPackage $transTB
      #fix not working on startup
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v 'EnableFullTrustStartupTasks' /t REG_DWORD /d '2' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v 'EnableUwpStartupTasks' /t REG_DWORD /d '2' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v 'SupportFullTrustStartupTasks' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' /v 'SupportUwpStartupTasks' /t REG_DWORD /d '1' /f
      #clear explorer and shell temp cache to run ttb.exe from admin context
      taskkill /f /im explorer.exe *>$null
      taskkill /f /im shellexperiencehost.exe *>$null
      Remove-Item "$env:LOCALAPPDATA\Packages\Microsoft.Windows.ShellExperienceHost_cw5n1h2txyewy\TempState*" -Force -ErrorAction SilentlyContinue
      Start-Process explorer.exe
      Start-Process ttb.exe
      
    }
      

            
   
    if ($checkbox13.Checked) {
      Write-Status -Message 'Blocking Razer and ASUS Downloads via Hosts File...' -Type Output
      
      $hosts = 'C:\Windows\System32\drivers\etc\hosts'
      
      Add-Content -Path $hosts -Value '0.0.0.0 synapse3ui-common.razerzone.com
      0.0.0.0 bespoke-analytics.razerapi.com
      0.0.0.0 discovery.razerapi.com
      0.0.0.0 manifest.razerapi.com
      0.0.0.0 cdn.razersynapse.com
      0.0.0.0 assets.razerzone.com
      0.0.0.0 assets2.razerzone.com
      0.0.0.0 deals-assets-cdn.razerzone.com
      0.0.0.0 synapse-3-webservice.razerzone.com
      0.0.0.0 albedozero.razerapi.com
      0.0.0.0 gms.razersynapse.com
      0.0.0.0 fs.razersynapse.com
      0.0.0.0 id.razer.com' -Force
      
      Add-Content -Path $hosts -Value '0.0.0.0 liveupdate01s.asus.com
      0.0.0.0 asusactivateservice.azurewebsites.net
      0.0.0.0 rog-live-service.asus.com
      0.0.0.0 dlcdn-rogboxbu1.asus.com
      0.0.0.0 dlcdn-rogboxbu2.asus.com
      0.0.0.0 mymessage.asus.com
      0.0.0.0 gaming-config.asus.com
      0.0.0.0 rog-content-platform.asus.com
      0.0.0.0 nomos.asus.com
      0.0.0.0 dlcdnrog.asus.com
      0.0.0.0 account.asus.com' -Force
      
    }
      
    if ($checkbox14.Checked) {
      Write-Status -Message 'Adding bat,ps1, and reg to New File Menu...' -Type Output
      
      #run both to fix 24h2
      $path = Search-File '*newMenu11.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path" -Wait
      $path = Search-File '*newMenu.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path" -Wait

    }
    if ($checkbox15.Checked) {
      Write-Status -Message 'Adding Additional Options to ps1 Files...' -Type Output  
      
      $path = Search-File '*ps1Options.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path" -Wait
    }
    if ($checkbox16.Checked) {
      Write-Status -Message 'Adding Snipping Tool to Context Menu...' -Type Output  
     
      $path = Search-File '*Snipping.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path" -Wait
      
     
    }
    if ($checkbox17.Checked) {
      Write-Status -Message 'Adding Shutdown and Restart to Context Menu...' -Type Output  
  
      $path = Search-File '*Shutdown.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path" -Wait
      
    }
    if ($checkbox18.Checked) {
      Write-Status -Message 'Adding Run as Admin for ps1, bat, vbs files to Context Menu...' -Type Output  
      
      $path = Search-File '*runAsAdmin.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path" -Wait
    }
    if ($checkbox19.Checked) {
      Write-Status -Message 'Adding PowerShell and CMD to Context Menu...' -Type Output  
     
      $path = Search-File '*powershellCmd.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path" -Wait
      
    }
    if ($checkbox20.Checked) {
      Write-Status -Message 'Adding Kill Not Responding Tasks to Context Menu...' -Type Output  
    
      $path = Search-File '*killTasks.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path" -Wait
      
    }
      
    if ($checkbox26.Checked) {
      Write-Status -Message 'Adding Delete Permanently to Context Menu...' -Type Output  
     
      $path = Search-File '*superdel.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path"
      
    }

    if ($checkbox65.Checked) {
      Write-Status -Message 'Adding Legacy Settings to Context Menu...' -Type Output  
      
      $path = Search-File '*LegacySettings.reg'
      Start-Process -filepath "$env:windir\regedit.exe" -Argumentlist "/s $path"
      
    }
      
      
      
    if ($checkbox23.Checked) {
      Write-Status -Message 'Removing Network Icon From File Explorer...' -Type Output
      Reg.exe add 'HKCU\Software\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}' /v 'System.IsPinnedToNameSpaceTree' /t REG_DWORD /d '0' /f
      
    }
      
    if ($checkbox29.Checked) {
      Write-Status -Message 'Excluding Drivers From Windows Update...' -Type Output
   
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' /v 'ExcludeWUDriversInQualityUpdate' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'ExcludeWUDriversInQualityUpdate' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' /v 'SearchOrderConfig' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\WindowsUpdate\UpdatePolicy\PolicyState' /v 'ExcludeWUDrivers' /t REG_DWORD /d '1' /f
      Write-Status -Message 'Updating Policy...' -Type Output
    
      gpupdate /force
    }
      
      
      
    if ($checkbox31.Checked) {
      Write-Status -Message 'Removing Mouse and Sound Schemes...' -Type Output
    
      Reg.exe add 'HKCU\AppEvents\Schemes' /ve /t REG_SZ /d '.None' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\.Default\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\.Default\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\CriticalBatteryAlarm\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\CriticalBatteryAlarm\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\DeviceConnect\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\DeviceConnect\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\DeviceDisconnect\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\DeviceDisconnect\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\DeviceFail\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\DeviceFail\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\FaxBeep\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\FaxBeep\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\LowBatteryAlarm\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\LowBatteryAlarm\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\MailBeep\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\MailBeep\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\MessageNudge\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\MessageNudge\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.Default\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.Default\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.IM\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.IM\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.Mail\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.Mail\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.Proximity\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.Proximity\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.Reminder\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.Reminder\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.SMS\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\Notification.SMS\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\ProximityConnection\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\ProximityConnection\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\SystemAsterisk\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\SystemAsterisk\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\SystemExclamation\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\SystemExclamation\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\SystemHand\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\SystemHand\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\SystemNotification\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\SystemNotification\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\.Default\WindowsUAC\.Current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\.Default\WindowsUAC\.Current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\sapisvr\DisNumbersSound\.current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\sapisvr\DisNumbersSound\.current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\sapisvr\HubOffSound\.current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\sapisvr\HubOffSound\.current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\sapisvr\HubOnSound\.current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\sapisvr\HubOnSound\.current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\sapisvr\HubSleepSound\.current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\sapisvr\HubSleepSound\.current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\sapisvr\MisrecoSound\.current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\sapisvr\MisrecoSound\.current' /f
      Reg.exe delete 'HKCU\AppEvents\Schemes\Apps\sapisvr\PanelSound\.current' /f
      Reg.exe add 'HKCU\AppEvents\Schemes\Apps\sapisvr\PanelSound\.current' /f
      Reg.exe add 'HKCU\Control Panel\Cursors' /v 'ContactVisualization' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\Control Panel\Cursors' /v 'GestureVisualization' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\Control Panel\Cursors' /v 'Scheme Source' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\Control Panel\Cursors' /ve /t REG_SZ /d ' ' /f
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'AppStarting' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'Arrow' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'Crosshair' -Force -ErrorAction SilentlyContinue
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'Hand' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'IBeam' -Force -ErrorAction SilentlyContinue
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'No' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'NWPen' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'SizeAll' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'SizeNESW' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'SizeNS' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'SizeNWSE' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'SizeWE' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'UpArrow' -Force
      Clear-ItemProperty -Path 'registry::HKCU\Control Panel\Cursors' -Name 'Wait' -Force
      
    }
      
      
      
    if ($checkbox33.Checked) {
      Write-Status -Message 'Removing Recycle Bin Icon Text...' -Type Output
      Reg.exe add 'HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CLSID\{645FF040-5081-101B-9F08-00AA002F954E}' /ve /t REG_SZ /d ' ' /f
      
    }
      
   
    if ($checkbox34.Checked) {
      Write-Status -Message 'Adding Take Ownership to Context Menu...' -Type Output
      Reg.exe add 'HKCR\*\shell\runas' /ve /t REG_SZ /d 'Take Ownership' /f
      Reg.exe add 'HKCR\*\shell\runas\command' /ve /t REG_SZ /d 'cmd.exe /c takeown /f \"%1\" && icacls \"%1\" /grant *S-1-5-32-544:F' /f
      Reg.exe add 'HKCR\*\shell\runas\command' /v 'IsolatedCommand' /t REG_SZ /d 'cmd.exe /c takeown /f \"%1\" && icacls \"%1\" /grant *S-1-5-32-544:F' /f
      Reg.exe add 'HKCR\Directory\shell\runas' /ve /t REG_SZ /d 'Take Ownership' /f
      Reg.exe add 'HKCR\Directory\shell\runas\command' /ve /t REG_SZ /d 'cmd.exe /c takeown /f \"%1\" /r /d y && icacls \"%1\" /grant *S-1-5-32-544:F /t' /f
      Reg.exe add 'HKCR\Directory\shell\runas\command' /v 'IsolatedCommand' /t REG_SZ /d 'cmd.exe /c takeown /f \"%1\" /r /d y && icacls \"%1\" /grant *S-1-5-32-544:F /t' /f

     


    }

    if ($checkbox35.Checked) {
      Write-Status -Message 'Removing Add to Favorites from Context Menu...' -Type Output
      Reg.exe delete 'HKCR\*\shell\pintohomefile' /f

    }

    if ($checkbox36.Checked) {
      Write-Status -Message 'Removing Customize this Folder from Context Menu...' -Type Output
      Reg.exe delete 'HKCR\Directory\shellex\PropertySheetHandlers\{ef43ecfe-2ab9-4632-bf21-58909dd177f0}' /f
      Reg.exe delete 'HKCR\Drive\shellex\PropertySheetHandlers\{ef43ecfe-2ab9-4632-bf21-58909dd177f0}' /f
      #policies
      Reg.exe delete 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' /v 'NoCustomizeThisFolder' /f >$null 2>&1
      Reg.exe delete 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' /v 'NoCustomizeWebView' /f >$null 2>&1
      Reg.exe delete 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' /v 'ClassicShell' /f >$null 2>&1
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' /v 'NoCustomizeThisFolder' /t REG_DWORD /d '1' /f
      Reg.exe delete 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' /v 'NoCustomizeWebView' /f >$null 2>&1
      Reg.exe delete 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' /v 'ClassicShell' /f >$null 2>&1
    }

    if ($checkbox37.Checked) {
      Write-Status -Message 'Removing Give Access To from Context Menu...' -Type Output
      Reg.exe delete 'HKCR\*\shellex\ContextMenuHandlers\Sharing' /f
      Reg.exe delete 'HKCR\Directory\Background\shellex\ContextMenuHandlers\Sharing' /f
      Reg.exe delete 'HKCR\Directory\shellex\ContextMenuHandlers\Sharing' /f
      Reg.exe delete 'HKCR\Drive\shellex\ContextMenuHandlers\Sharing' /f
      Reg.exe delete 'HKCR\LibraryFolder\background\shellex\ContextMenuHandlers\Sharing' /f
      Reg.exe delete 'HKCR\UserLibraryFolder\shellex\ContextMenuHandlers\Sharing' /f
    }

    if ($checkbox38.Checked) {
      Write-Status -Message 'Removing Open Terminal from Context Menu...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' /v '{9F156763-7844-4DC4-B2B1-901F640F5155}' /t REG_SZ /d `"`" /f
    }

    if ($checkbox39.Checked) {
      Write-Status -Message 'Removing Restore Previous Versions from Context Menu...' -Type Output
      Reg.exe delete 'HKCR\AllFilesystemObjects\shellex\ContextMenuHandlers\{596AB062-B4D2-4215-9F74-E9109B0A8153}' /f
      Reg.exe delete 'HKCR\CLSID\{450D8FBA-AD25-11D0-98A8-0800361B1103}\shellex\ContextMenuHandlers\{596AB062-B4D2-4215-9F74-E9109B0A8153}' /f
      Reg.exe delete 'HKCR\Directory\shellex\ContextMenuHandlers\{596AB062-B4D2-4215-9F74-E9109B0A8153}' /f
      Reg.exe delete 'HKCR\Drive\shellex\ContextMenuHandlers\{596AB062-B4D2-4215-9F74-E9109B0A8153}' /f
      Reg.exe delete 'HKCR\AllFilesystemObjects\shellex\PropertySheetHandlers\{596AB062-B4D2-4215-9F74-E9109B0A8153}' /f
      Reg.exe delete 'HKCR\CLSID\{450D8FBA-AD25-11D0-98A8-0800361B1103}\shellex\PropertySheetHandlers\{596AB062-B4D2-4215-9F74-E9109B0A8153}' /f
      Reg.exe delete 'HKCR\Directory\shellex\PropertySheetHandlers\{596AB062-B4D2-4215-9F74-E9109B0A8153}' /f
      Reg.exe delete 'HKCR\Drive\shellex\PropertySheetHandlers\{596AB062-B4D2-4215-9F74-E9109B0A8153}' /f
      #policies
      Reg.exe delete 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer' /v 'NoPreviousVersionsPage' /f >$null 2>&1
      Reg.exe delete 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' /v 'NoPreviousVersionsPage' /f >$null 2>&1
      Reg.exe delete 'HKLM\SOFTWARE\Policies\Microsoft\PreviousVersions' /v 'DisableLocalPage' /f >$null 2>&1
      Reg.exe delete 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer' /v 'NoPreviousVersionsPage' /f >$null 2>&1
      Reg.exe delete 'HKCU\Software\Policies\Microsoft\PreviousVersions' /v 'DisableLocalPage' /f >$null 2>&1
     
    }

    if ($checkbox40.Checked) {
      Write-Status -Message 'Removing Print from Context Menu...' -Type Output
      Reg.exe add 'HKCR\SystemFileAssociations\image\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\batfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\cmdfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\docxfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\fonfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\htmlfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\inffile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\inifile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\JSEFile\Shell\Print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\otffile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\pfmfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\regfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\rtffile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\ttcfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\ttffile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\txtfile\shell\print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\VBEFile\Shell\Print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\VBSFile\Shell\Print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
      Reg.exe add 'HKCR\WSFFile\Shell\Print' /v 'ProgrammaticAccessOnly' /t REG_SZ /d `"`" /f
    }

    if ($checkbox41.Checked) {
      Write-Status -Message 'Removing Send To from Context Menu...' -Type Output
      Reg.exe delete 'HKCR\AllFilesystemObjects\shellex\ContextMenuHandlers\SendTo' /f
      Reg.exe delete 'HKCR\UserLibraryFolder\shellex\ContextMenuHandlers\SendTo' /f
    }

    if ($checkbox42.Checked) {
      Write-Status -Message 'Removing Share from Context Menu...' -Type Output
      Reg.exe delete 'HKCR\AllFilesystemObjects\shellex\ContextMenuHandlers\ModernSharing' /f
      Reg.exe delete 'HKCR\*\shellex\ContextMenuHandlers\ModernSharing' /f
    }

    if ($checkbox43.Checked) {
      Write-Status -Message 'Removing Personalize from Context Menu...' -Type Output
      $command = "Remove-Item -Path 'registry::HKCR\DesktopBackground\Shell\Personalize' -Recurse -Force"
      Run-Trusted -command $command
      Start-Sleep 2
    }

    if ($checkbox44.Checked) {
      Write-Status -Message 'Removing Display from Context Menu...' -Type Output
      $command = "Remove-Item -Path 'registry::HKCR\DesktopBackground\Shell\Display' -Recurse -Force"
      Run-Trusted -command $command
      Start-Sleep 2
    }

    if ($checkbox46.Checked) {
      Write-Status -Message 'Removing Extract All from Context Menu...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' /v '{b8cdcb65-b1bf-4b42-9428-1dfdb7ee92af}' /t REG_SZ /f
      Reg.exe add 'HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' /v '{b8cdcb65-b1bf-4b42-9428-1dfdb7ee92af}' /t REG_SZ /f
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' /v '{EE07CEF5-3441-4CFB-870A-4002C724783A}' /t REG_SZ /f
      Reg.exe add 'HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' /v '{EE07CEF5-3441-4CFB-870A-4002C724783A}' /t REG_SZ /f
    }

    if ($checkbox45.Checked) {
      Write-Status -Message 'Disabling All Update Types Except for Security...' -Type Output
     
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'SetAllowOptionalContent' /t REG_DWORD /d '0' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DeferFeatureUpdates' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DeferFeatureUpdatesPeriodInDays' /t REG_DWORD /d '730' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DeferQualityUpdates' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DeferQualityUpdatesPeriodInDays' /t REG_DWORD /d '730' /f >$null

      $excludedClassifications = @(
        '{e6cf1350-c01b-414d-a61f-263d3d4dd9f9}', # Critical Updates
        '{e0789628-ce08-4437-be74-2495b842f43b}', # Definition Updates
        '{b54e7d24-7add-49f4-88bb-9837d47477fb}', # Feature Packs
        '{68c5b0a3-d1a6-4553-ae49-01d3a7827828}', # Service Packs
        '{b4832bd8-e735-4766-9727-7d0ffa644277}', # Tools
        '{28bc8804-5382-4bae-93aa-13c905f28542}', # Update Rollups
        '{cd5ffd1e-e257-4a05-9d88-c83a7125d4c9}', # Updates
        '{0f1afbec-90ef-4651-9e37-030fedc944c8}', # Non-critical
        '{ebfc1fc5-71a4-4f7b-9aca-3b9a503104a0}', # Drivers
        '{9920c092-3d99-4a1b-865a-673135c5a4fc}'   # Feature Updates
      ) -join ';'
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeUpdateClassifications' -Value $excludedClassifications -Type String -Force
      Write-Status -Message 'Updating Policy...' -Type Output
      gpupdate /force
    }

    if ($checkbox47.Checked) {
      Write-Status -Message 'Pausing Updates for 1 Year...' -Type Output
      #pause for 1 year
      $pause = (Get-Date).AddDays(365) 
      $today = Get-Date
      $today = $today.ToUniversalTime().ToString( 'yyyy-MM-ddTHH:mm:ssZ' )
      $pause = $pause.ToUniversalTime().ToString( 'yyyy-MM-ddTHH:mm:ssZ' ) 
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'PauseUpdatesExpiryTime' -Value $pause -Force
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'PauseFeatureUpdatesEndTime' -Value $pause -Force
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'PauseFeatureUpdatesStartTime' -Value $today -Force
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'PauseQualityUpdatesEndTime' -Value $pause -Force
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'PauseQualityUpdatesStartTime' -Value $today -Force
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'PauseUpdatesStartTime' -Value $today -Force
      Set-Service -Name wuauserv -StartupType Manual -ErrorAction SilentlyContinue
      Set-Service -Name UsoSvc -StartupType Manual -ErrorAction SilentlyContinue
      Set-Service -Name WaaSMedicSvc -StartupType Manual -ErrorAction SilentlyContinue
      $Tasks =
      '\Microsoft\Windows\InstallService\*',
      '\Microsoft\Windows\UpdateOrchestrator\*',
      '\Microsoft\Windows\UpdateAssistant\*',
      '\Microsoft\Windows\WaaSMedic\*',
      '\Microsoft\Windows\WindowsUpdate\*',
      '\Microsoft\WindowsUpdate\*'

      foreach ($Task in $Tasks) {
        Get-ScheduledTask -TaskPath $Task | Disable-ScheduledTask -ErrorAction SilentlyContinue
      }
      #ensure pause really works
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'SetAllowOptionalContent' /t REG_DWORD /d '0' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DeferFeatureUpdates' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DeferFeatureUpdatesPeriodInDays' /t REG_DWORD /d '365' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DeferQualityUpdates' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'DeferQualityUpdatesPeriodInDays' /t REG_DWORD /d '365' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'ExcludeWUDriversInQualityUpdate' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' /v 'ExcludeWUDriversInQualityUpdate' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Device Metadata' /v 'PreventDeviceMetadataFromNetwork' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' /v 'DontPromptForWindowsUpdate' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' /v 'DontSearchWindowsUpdate' /t REG_DWORD /d '1' /f >$null
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' /v 'DriverUpdateWizardWuSearchEnabled' /t REG_DWORD /d '0' /f >$null

      $excludedClassifications = @(
        '{e6cf1350-c01b-414d-a61f-263d3d4dd9f9}', # Critical Updates
        '{e0789628-ce08-4437-be74-2495b842f43b}', # Definition Updates
        '{b54e7d24-7add-49f4-88bb-9837d47477fb}', # Feature Packs
        '{68c5b0a3-d1a6-4553-ae49-01d3a7827828}', # Service Packs
        '{b4832bd8-e735-4766-9727-7d0ffa644277}', # Tools
        '{28bc8804-5382-4bae-93aa-13c905f28542}', # Update Rollups
        '{cd5ffd1e-e257-4a05-9d88-c83a7125d4c9}', # Updates
        '{0f1afbec-90ef-4651-9e37-030fedc944c8}', # Non-critical
        '{ebfc1fc5-71a4-4f7b-9aca-3b9a503104a0}', # Drivers
        '{9920c092-3d99-4a1b-865a-673135c5a4fc}'   # Feature Updates
      ) -join ';'
      Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeUpdateClassifications' -Value $excludedClassifications -Type String -Force

    }


    if ($checkbox48.Checked) {
      Write-Status -Message 'Removing Troubleshoot Compatibility from Context Menu...' -Type Output
      #remove troubleshoot comp
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' /v '{1d27f844-3a1f-4410-85ac-14651078412d}' /t REG_SZ /d ' ' /f *>$null
    }

    if ($checkbox49.Checked) {
      Write-Status -Message 'Removing Include in Library from Context Menu...' -Type Output
      #remove include in library
      Reg.exe delete 'HKCR\Folder\ShellEx\ContextMenuHandlers\Library Location' /f *>$null
      Reg.exe delete 'HKLM\SOFTWARE\Classes\Folder\ShellEx\ContextMenuHandlers\Library Location' /f *>$null
    }


    if ($checkbox50.Checked) {
      Write-Status -Message 'Preventing Windows Update from Upgrading Versions...' -Type Output
      #get current os and build
      $buildVer = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').DisplayVersion
      $winName = ((Get-CimInstance Win32_OperatingSystem).Caption).Substring(10, 10)

      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'ProductVersion' /t REG_SZ /d $winName /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'TargetReleaseVersion' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' /v 'TargetReleaseVersionInfo' /t REG_SZ /d $buildVer /f
      gpupdate /force *>$null
    }

    if ($checkbox51.Checked) {
      Write-Status -Message 'Disabling PowerShell Logging...' -Type Output
      Set-PSReadlineOption -HistorySaveStyle SaveNothing
      (Get-PSReadLineOption).HistorySavePath | Remove-Item -Force -ErrorAction SilentlyContinue
    }

    if ($checkbox52.Checked) {
      Write-Status -Message 'Enabling No GUI Boot...' -Type Output
      bcdedit /set '{globalsettings}' bootuxdisabled on
    }


    if ($checkbox54.Checked) {
      Write-Status -Message 'Disabling Game Bar Popup when Xbox App is Uninstalled...' -Type Output
      #hide gamebar popup credits aveyo

      Set-ItemProperty 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' 0 -type dword -force -ea 0
      Set-ItemProperty 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 0 -type dword -force -ea 0

      'ms-gamebar', 'ms-gamebarservices', 'ms-gamingoverlay' | ForEach-Object {
        #create new reg keys for each handler
        if (!(test-path "Registry::HKCR\$_\shell")) { 
          New-Item "Registry::HKCR\$_\shell" -force >'' 
        }
        if (!(test-path "Registry::HKCR\$_\shell\open")) { 
          New-Item "Registry::HKCR\$_\shell\open" -force >'' 
        }
        if (!(test-path "Registry::HKCR\$_\shell\open\command")) { 
          New-Item "Registry::HKCR\$_\shell\open\command" -force >'' 
        }

        Set-ItemProperty "Registry::HKCR\$_" '(Default)' "URL:$_" -force
        Set-ItemProperty "Registry::HKCR\$_" 'URL Protocol' '' -force
        #add noopenwith and systray.exe to hide popup
        Set-ItemProperty "Registry::HKCR\$_" 'NoOpenWith' '' -force
        Set-ItemProperty "Registry::HKCR\$_\shell\open\command" '(Default)' "`"$env:SystemRoot\System32\systray.exe`"" -force
      }
    }

    if ($checkbox55.Checked) {
      Write-Status -Message 'Enabling Faster Shutdowns and Restarts By Ending Services Sooner...' -Type Output
      Reg.exe add 'HKCU\Control Panel\Desktop' /v 'WaitToKillAppTimeout' /t REG_SZ /d '1500' /f *>$null
      Reg.exe add 'HKCU\Control Panel\Desktop' /v 'AutoEndTasks' /t REG_SZ /d '1' /f *>$null
      Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control' /v 'WaitToKillServiceTimeout' /t REG_SZ /d '1500' /f *>$null
    }

 
    if ($checkbox57.Checked) {
      Write-Status -Message 'Hiding User Tile In Start Menu...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Microsoft\PolicyManager\default\Start\HideUserTile' /v 'value' /t REG_DWORD /d '1' /f
    }

    if ($checkbox58.Checked) {
      Write-Status -Message 'Using More Accurate and Reliable Time Server...' -Type Output
      Start-Service W32Time -ErrorAction SilentlyContinue
      Start-Process w32tm.exe -ArgumentList '/config /syncfromflags:manual /manualpeerlist:"0.pool.ntp.org 1.pool.ntp.org 2.pool.ntp.org 3.pool.ntp.org"' -WindowStyle Hidden
      Start-Process w32tm.exe -ArgumentList '/config /update' -WindowStyle Hidden
      Start-Process w32tm.exe -ArgumentList '/resync' -WindowStyle Hidden
    }

    if ($checkbox59.Checked) {
      Write-Status -Message 'Applying Modern Cursor Scheme...' -Type Output
      $cursorPath = "$env:systemroot\Cursors\Fluent Cursor"
      New-Item $cursorPath -Force -ItemType Directory | Out-Null
      $modernCursors = Search-Directory '*ModernCursors'
      Get-ChildItem $modernCursors -Exclude '*.reg' | Foreach-Object {
        Copy-Item $_.FullName -Destination $cursorPath -Force
      }
      #apply cursor scheme
      regedit.exe /s "$modernCursors\ModernCursorScheme.reg" *>$null
      #update cursors without having to restart
      $WinAPI = Add-Type -Name WinAPI -NameSpace System -passThru -memberDefinition '
[DllImport("user32.dll")]
 public static extern bool SystemParametersInfo(
    uint uiAction,
    uint uiParam ,
    int pvParam ,
    uint fWinIni
 );
'
      $WinAPI::SystemParametersInfo(0x0057, 0, $null, 0)
    }

    if ($checkbox60.Checked) {
      Write-Status -Message 'Enabling Dark Accents...' -Type Output
      $OS = Get-CimInstance Win32_OperatingSystem
      if ($OS.BuildNumber -gt 19045) {
        $glyphAccent = Search-File '*AccentColorizer-E11.exe'
      }
      $accentColorizer = Search-File '*AccentColorizer.exe'

      #run and apply accent colorizer
      Start-Process $accentColorizer 
      Start-Sleep 1
      $openWindows = Get-Process | Where-Object { $_.MainWindowTitle -like 'AccentColorizer.exe*' } 
      if ($openWindows) {
        Write-Status -Message 'Visual C++ Packages Not Installed...' -Type Error
        Write-Status -Message 'Please Install Neccessary Packages Under the Install Section of mpware...' -Type Output
      }
      else {
        #needs to be applied on startup
        $startUpFolder = [System.Environment]::GetFolderPath('Startup')
        Copy-Item $accentColorizer -Destination $startUpFolder -Force | Out-Null
      }

      if ($glyphAccent) {
        #only needs to be ran once then its applied 
        #modifies svg resource files (icons) in the file explorer appx dir
        Stop-Process -name 'AccentColorizer' -Force -ErrorAction SilentlyContinue
        Start-Process $glyphAccent 
        Start-Sleep 2
        Start-Process $glyphAccent -ArgumentList '-apply'
        Start-Sleep 5
        Stop-Process -Name 'AccentColorizer-E11' -Force -ErrorAction SilentlyContinue
      }
        
      
    }


    if ($checkbox61.Checked) {
      Write-Status -Message 'Getting Scaling Value...' -Type Output
      $dpi = (Get-ItemProperty 'HKCU:\Control Panel\Desktop\WindowMetrics' -Name AppliedDPI -ErrorAction SilentlyContinue).AppliedDPI
      if ($dpi) {
        $scaling = ($dpi / 96) * 100
      }
      Write-Status -Message "Scaling Set to $scaling%..." -Type Output
      Write-Status -Message 'If This is Not Your Desired Value Change it in Display Settings, Restart PC, and Run this Again' -Type Warning

      switch ($scaling) {
        100 {
          Write-Status -Message 'Setting Mouse up for 100% Monitor Scaling...' -Type Output
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseSensitivity' /t REG_SZ /d '10' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseSpeed' /t REG_SZ /d '0' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseThreshold1' /t REG_SZ /d '0' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseThreshold2' /t REG_SZ /d '0' /f
          Reg.exe delete 'HKCU\Control Panel\Mouse' /v 'SmoothMouseXCurve' /f *>$null
          Reg.exe delete 'HKCU\Control Panel\Mouse' /v 'SmoothMouseYCurve' /f *>$null
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'Win8DpiScaling' /t REG_DWORD /d '0' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'LogPixels' /t REG_DWORD /d '96' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'EnablePerProcessSystemDPI' /t REG_DWORD /d '0' /f
        }
        125 {
          Write-Status -Message 'Setting Mouse up for 125% Monitor Scaling...' -Type Output
          $SmoothMouseXCurve = [byte[]](
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00
          )
    
          $SmoothMouseYCurve = [byte[]](
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x38, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0xA8, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0xE0, 0x00, 0x00, 0x00, 0x00, 0x00
          )
          Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'SmoothMouseXCurve' -Value $SmoothMouseXCurve -Type Binary -Force
          Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'SmoothMouseYCurve' -Value $SmoothMouseYCurve -Type Binary -Force
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseSensitivity' /t REG_SZ /d '10' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseSpeed' /t REG_SZ /d '1' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseThreshold1' /t REG_SZ /d '6' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseThreshold2' /t REG_SZ /d '10' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'Win8DpiScaling' /t REG_DWORD /d '0' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'LogPixels' /t REG_DWORD /d '120' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'EnablePerProcessSystemDPI' /t REG_DWORD /d '1' /f
        }
    
        150 {
          Write-Status -Message 'Setting Mouse up for 150% Monitor Scaling...' -Type Output
          $SmoothMouseXCurve = [byte[]](
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x30, 0x33, 0x13, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x60, 0x66, 0x26, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x90, 0x99, 0x39, 0x00, 0x00, 0x00, 0x00, 0x00,
            0xC0, 0xCC, 0x4C, 0x00, 0x00, 0x00, 0x00, 0x00
          )
    
          $SmoothMouseYCurve = [byte[]](
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x38, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0xA8, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0xE0, 0x00, 0x00, 0x00, 0x00, 0x00
          )
          Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'SmoothMouseXCurve' -Value $SmoothMouseXCurve -Type Binary -Force
          Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'SmoothMouseYCurve' -Value $SmoothMouseYCurve -Type Binary -Force
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseSensitivity' /t REG_SZ /d '10' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseSpeed' /t REG_SZ /d '1' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseThreshold1' /t REG_SZ /d '6' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseThreshold2' /t REG_SZ /d '10' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'Win8DpiScaling' /t REG_DWORD /d '0' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'LogPixels' /t REG_DWORD /d '144' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'EnablePerProcessSystemDPI' /t REG_DWORD /d '1' /f
        }

        200 {
          Write-Status -Message 'Setting Mouse up for 200% Monitor Scaling...' -Type Output
          $SmoothMouseXCurve = [byte[]](
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x90, 0x99, 0x19, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x20, 0x33, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00,
            0xB0, 0xCC, 0x4C, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x40, 0x66, 0x66, 0x00, 0x00, 0x00, 0x00, 0x00
          )
    
          $SmoothMouseYCurve = [byte[]](
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x38, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0xA8, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0xE0, 0x00, 0x00, 0x00, 0x00, 0x00
          )
          Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'SmoothMouseXCurve' -Value $SmoothMouseXCurve -Type Binary -Force
          Set-ItemProperty -Path 'HKCU:\Control Panel\Mouse' -Name 'SmoothMouseYCurve' -Value $SmoothMouseYCurve -Type Binary -Force
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseSensitivity' /t REG_SZ /d '10' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseSpeed' /t REG_SZ /d '1' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseThreshold1' /t REG_SZ /d '6' /f
          Reg.exe add 'HKCU\Control Panel\Mouse' /v 'MouseThreshold2' /t REG_SZ /d '10' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'Win8DpiScaling' /t REG_DWORD /d '0' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'LogPixels' /t REG_DWORD /d '192' /f
          Reg.exe add 'HKCU\Control Panel\Desktop' /v 'EnablePerProcessSystemDPI' /t REG_DWORD /d '1' /f
        }

        default {
          Write-Status -Message 'Scaling Value Not Supported...Must be 100, 125, 150, or 200' -Type Warning
        }


      }

    }

    if ($checkbox62.Checked) {
      Write-Status -Message 'Disabling Device Encryption...' -Type Output
    
      $drives = Get-BitLockerVolume | Where-Object { $_.ProtectionStatus -eq 'On' -or $_.VolumeStatus -ne 'FullyDecrypted' } 
      if ($drives) {
        Write-Status -Message 'BitLocker Enabled... Disabling BitLocker [This may take a while and Disk Usage WILL be high while decrypting]' -Type Warning
        foreach ($drive in $drives) {
          Disable-BitLocker -MountPoint $drive.MountPoint -ErrorAction SilentlyContinue | Out-Null
        }
      }
      
      $command = "
    Reg add 'HKLM\SYSTEM\ControlSet001\Services\BDESVC' /v 'Start' /t REG_DWORD /d '4' /f
    Reg add 'HKLM\SYSTEM\ControlSet001\Control\BitLocker' /v 'PreventDeviceEncryption' /t REG_DWORD /d '1' /f
    Reg add 'HKLM\SYSTEM\ControlSet001\Control\BitlockerStatus' /v 'BootStatus' /t REG_DWORD /d '0' /f
    Reg add 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\BitLocker' /v 'IsBdeDriverPresent' /t REG_DWORD /d '0' /f
    "
      Run-Trusted -command $command
    }

    if ($checkbox63.Checked) {
      Write-Status -Message 'Enabling Classic Accents...' -Type Output
      $colors = @{
        'ButtonFace'          = '212 208 200'
        'ButtonShadow'        = '160 160 160'
        'ButtonDkShadow'      = '105 105 105'
        'ButtonLight'         = '227 227 227'
        'ButtonHilight'       = '211 208 200'
        'ButtonText'          = '0 0 0'
        'ButtonAlternateFace' = '0 0 0'
        'Menu'                = '213 208 200'
        'MenuText'            = '0 0 0'
        'MenuBar'             = '212 208 200'
        'MenuHilight'         = '10 36 107'
        'Hilight'             = '10 36 107'
        'HilightText'         = '255 255 255'
        'HotTrackingColor'    = '10 36 107'
        'GrayText'            = '109 109 109'
        'Scrollbar'           = '200 200 200'
        'WindowFrame'         = '100 100 100'
        'ActiveBorder'        = '180 180 180'
        'InactiveBorder'      = '244 247 252'
        'AppWorkspace'        = '171 171 171'
        'InfoText'            = '0 0 0'
        'InfoWindow'          = '255 255 225'
      }

      $regPath = 'HKCU:\Control Panel\Colors'

      foreach ($key in $colors.Keys) {
        Set-ItemProperty -Path $regPath -Name $key -Value $colors[$key] -Force -ErrorAction SilentlyContinue
      }

      Write-Status -Message 'Restart or Sign Out to Apply!' -Type Output
    }

    if ($checkbox66.Checked) {
      Write-Status -Message 'Hiding Are you sure you want to uninstall this app dialog...' -Type Output
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\DontShowMeThisDialogAgain' /v '{948e51fb-0a48-44f0-86ac-33c36def540c}' /t REG_SZ /d 'NO' /f >$null
    }
    
    if ($checkbox67.Checked) {
      Write-Status -Message 'Hiding merge conflicts dialog...' -Type Output
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' /v 'HideMergeConflicts' /t REG_DWORD /d '1' /f >$null
    }

    if ($checkbox68.Checked) {
      Write-Status -Message 'Hiding delete synced file warning dialog...' -Type Output
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\SyncRootManager' /v 'DoNotShowAgain' /t REG_DWORD /d '1' /f >$null
    }

    if ($checkbox69.Checked) {
      Write-Status -Message 'Hiding settings change requires restart in MSConfig...' -Type Output
      Reg.exe add 'HKCU\Software\Microsoft\Shared Tools\MsConfig' /v 'NoRebootUI' /t REG_DWORD /d '1' /f >$null
    }

    if ($checkbox70.Checked) {
      Write-Status -Message 'Enabling Do For All items in Explorer...' -Type Output
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager' /v 'ConfirmationCheckBoxDoForAll' /t REG_DWORD /d '1' /f >$null
    }

    if ($checkbox71.Checked) {
      Write-Status -Message 'Hiding warn when closing multiple tabs in Terminal...' -Type Output
      $settings = "$env:localappdata\packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json"

      if (Test-Path $settings) {
        $jsonContent = Get-Content -Path $settings -Raw | ConvertFrom-Json
        $jsonContent | Add-Member -NotePropertyName 'confirmCloseAllTabs' -NotePropertyValue $false -Force
        $jsonContent | ConvertTo-Json -Depth 10 | Set-Content -Path $settings
      }
    }

    if ($checkbox72.Checked) {
      Write-Status -Message 'Hiding delete file warning in Photos App...' -Type Output
      $uwpPhotosSettings = "$env:LOCALAPPDATA\Packages\Microsoft.Windows.Photos_8wekyb3d8bbwe\Settings\settings.dat"
      taskkill.exe /im Photos.exe /f *>$null
      [GC]::Collect()
      reg.exe unload 'HKU\TEMP' *>$null
      reg.exe load 'HKU\TEMP' $uwpPhotosSettings *>$null
      $regContent = @'
      Windows Registry Editor Version 5.00
      [HKEY_USERS\TEMP\LocalState]
      "DeleteConfirmationDialogStatus"=hex(5f5e10b):01,3c,82,63,f2,31,e0,dc,01
'@
      $regContent | Out-File "$tempDir\PhotosSettings.reg" -Force >$null
      reg.exe import "$tempDir\PhotosSettings.reg" *>$null
      reg.exe unload 'HKU\TEMP' *>$null
      Remove-Item "$tempDir\PhotosSettings.reg"
    }

    if ($checkbox73.Checked) {
      Write-Status -Message 'Moving 3rd party app shortcuts out of their sub directory...' -Type Output
      $startMenuPaths = @(
        "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"
        "$env:ProgramData\Microsoft\Windows\Start Menu\Programs"
      )
      #system dirs dont move the shortcuts out of
      $excludedDirs = @(
        'Accessibility'
        'Accessories'
        'Administrative Tools'
        'Maintenance'
        'Startup'
        'System Tools'
        'Windows PowerShell'
        'Microsoft Office Tools'
      )

      foreach ($startMenuPath in $startMenuPaths) {
        #get all the directories for 3rd party apps
        $dirs = Get-ChildItem $startMenuPath -Directory | Where-Object { $excludedDirs -notcontains $_.Name }
        foreach ($dir in $dirs) {
          #get all the shortcuts in the dir
          $files = Get-ChildItem $dir.FullName -File -Filter '*.lnk'
          if ($files) {
            foreach ($file in $files) {
              #move to root
              Move-Item $file.FullName -Destination $startMenuPath -Force
            }
          }
          Remove-Item $dir.FullName -Recurse -Force
        }
      }

    }

    if ($checkbox74.Checked) {
      Write-Status -Message 'Creating shortcut to both start menu locations...' -Type Output
      $vbsScript = @"
Dim shell,command
command = "powershell.exe -ep bypass -nop -windowstyle hidden -c ""explorer ""$env:APPDATA\Microsoft\Windows\Start Menu\Programs"";explorer ""$env:ProgramData\Microsoft\Windows\Start Menu\Programs"""
Set shell = CreateObject("WScript.Shell")
shell.Run command,0
"@

      $file = New-Item "$env:ProgramData\SilentStartMenuDir.vbs" -Value $vbsScript -Force

      $WshShell = New-Object -comObject WScript.Shell
      $Shortcut = $WshShell.CreateShortcut("$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Shortcuts.lnk")
      $Shortcut.TargetPath = 'wscript.exe'
      $Shortcut.Arguments = $file.FullName
      $Shortcut.IconLocation = '%SystemRoot%\System32\SHELL32.dll, -16769'
      $Shortcut.Save()
    }

    
    if (test-path 'C:\UltimateContextMenu') {
      $ogLocation = $Global:folder
      Move-item 'C:\UltimateContextMenu' -Destination $ogLocation
    }
                         
  }
            
      
      
}
Export-ModuleMember -Function OptionalTweaks








function remove-tasks {

  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
    # ,[Parameter(mandatory=$false)] $setting 
  )
      
     
    
  if ($Autorun) {
    $msgBoxInput = 'OK'
  }
  else {
    $msgBoxInput = Custom-MsgBox -message 'Remove ALL Scheduled Tasks?' -type Question
  }
      
      
  switch ($msgBoxInput) {
      
    'OK' {
        
      if (!($Autorun)) {
        update-config -setting 'scheduledTasks' -value 1
      }
      Write-Status -Message 'Removing Scheduled Tasks...' -Type Output
      
      Get-ScheduledTask -TaskPath '*' | 
      Where-Object { $_.TaskName -notin @('SvcRestartTask', 'MsCtfMonitor') } | 
      Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue
      
    }
      
    'Cancel' {}
      
  }
      
      
      
}
Export-ModuleMember -Function remove-tasks







function update-config([String]$setting, $value) {
  $currentConfig = Get-Content -Path "$env:USERPROFILE\mpware-config.cfg" -Force
  $newConfig = @()
  foreach ($line in $currentConfig) {
    if ($line -notmatch '#') {
      $settingName = "\b$setting\b"
      if ($line -match $settingName) {
        $newConfig += "$setting = $value" 
      }
      else {
        $newConfig += $line
      }
    }
    else {
      $newConfig += $line
    }
      
  }
  $newConfig | Out-File -FilePath "$env:USERPROFILE\mpware-config.cfg" -Force
}
Export-ModuleMember -Function update-config




function W11Tweaks {
  param (
    [Parameter(mandatory = $false)] [bool]$Autorun = $false
    , [Parameter(mandatory = $false)] [bool]$removeEdges = $false
    , [Parameter(mandatory = $false)] [bool]$win10TaskbarStartmenu = $false
    , [Parameter(mandatory = $false)] [bool]$win10explorer = $false
    , [Parameter(mandatory = $false)] [bool]$servicesManual = $false
    , [Parameter(mandatory = $false)] [bool]$showTrayIcons = $false
    , [Parameter(mandatory = $false)] [bool]$enableOpenShell = $false 
    , [Parameter(mandatory = $false)] [bool]$win10Recycle = $false
    , [Parameter(mandatory = $false)] [bool]$win10Snipping = $false
    , [Parameter(mandatory = $false)] [bool]$win10TaskMgr = $false
    , [Parameter(mandatory = $false)] [bool]$win10Notepad = $false
    , [Parameter(mandatory = $false)] [bool]$win10Icons = $false
    , [Parameter(mandatory = $false)] [bool]$win10Sounds = $false
    , [Parameter(mandatory = $false)] [bool]$darkWinver = $false
    , [Parameter(mandatory = $false)] [bool]$removeQuickSettingTiles = $false
    , [Parameter(mandatory = $false)] [bool]$disableNotepadTabs = $false
    , [Parameter(mandatory = $false)] [bool]$hideSettingsAds = $false
    , [Parameter(mandatory = $false)] [bool]$smallTaskbarIcons = $false
    , [Parameter(mandatory = $false)] [bool]$maxMouseThrottle = $false
    , [Parameter(mandatory = $false)] [bool]$newStartMenu = $false
    , [Parameter(mandatory = $false)] [bool]$revertNewStart = $false
  )
      
   
      
  $checkbox2 = new-object System.Windows.Forms.checkbox
  $checkbox4 = new-object System.Windows.Forms.checkbox
  $checkbox6 = new-object System.Windows.Forms.checkbox
  $checkbox3 = new-object System.Windows.Forms.checkbox
  $checkbox5 = new-object System.Windows.Forms.checkbox
  $checkbox7 = new-object System.Windows.Forms.checkbox
  $checkbox9 = new-object System.Windows.Forms.checkbox
  $checkbox13 = new-object System.Windows.Forms.checkbox
  $checkbox15 = new-object System.Windows.Forms.checkbox
  $checkbox17 = new-object System.Windows.Forms.checkbox
  $checkbox19 = new-object System.Windows.Forms.checkbox
  $checkbox20 = new-object System.Windows.Forms.checkbox
  $checkbox21 = new-object System.Windows.Forms.checkbox
  $checkbox22 = new-object System.Windows.Forms.checkbox
  $checkbox24 = new-object System.Windows.Forms.checkbox
  $checkbox26 = new-object System.Windows.Forms.checkbox
  $checkbox28 = new-object System.Windows.Forms.checkbox
  $checkbox29 = new-object System.Windows.Forms.checkbox
  $checkbox30 = new-object System.Windows.Forms.checkbox
  $checkbox31 = new-object System.Windows.Forms.checkbox
      
  $settings = @{}
    
  $settings['removeEdges'] = $checkbox2
  $settings['win10TaskbarStartmenu'] = $checkbox4
  $settings['win10Explorer'] = $checkbox6
  $settings['servicesManual'] = $checkbox3
  $settings['showTrayIcons'] = $checkbox5
  $settings['enableOpenShell'] = $checkbox7 
  $settings['win10Recycle'] = $checkbox9
  $settings['win10Snipping'] = $checkbox13
  $settings['win10TaskMgr'] = $checkbox15
  $settings['win10Notepad'] = $checkbox17
  $settings['win10Icons'] = $checkbox19
  $settings['win10Sounds'] = $checkbox20
  $settings['darkWinver'] = $checkbox21
  $settings['removeQuickSettingTiles'] = $checkbox22
  $settings['disableNotepadTabs'] = $checkbox24
  $settings['hideSettingsAds'] = $checkbox26
  $settings['smallTaskbarIcons'] = $checkbox28
  $settings['maxMouseThrottle'] = $checkbox29
  $settings['newStartMenu'] = $checkbox30
  $settings['revertNewStart'] = $checkbox31

      
  if ($Autorun) {
    $result = [System.Windows.Forms.DialogResult]::OK
    $checkbox2.Checked = $removeEdges
    $checkbox4.Checked = $win10taskbar
    $checkbox6.Checked = $win10explorer
    $checkbox3.Checked = $servicesManual
    $checkbox5.Checked = $showTrayIcons
    $checkbox7.Checked = $enableOpenShell
    $checkbox9.Checked = $win10Recycle
    $checkbox13.Checked = $win10Snipping
    $checkbox15.Checked = $win10TaskMgr
    $checkbox17.Checked = $win10Notepad
    $checkbox19.Checked = $win10Icons
    $checkbox20.Checked = $win10Sounds
    $checkbox21.Checked = $darkWinver
    $checkbox22.Checked = $removeQuickSettingTiles
    $checkbox24.Checked = $disableNotepadTabs
    $checkbox26.Checked = $hideSettingsAds
    $checkbox28.Checked = $smallTaskbarIcons
    $checkbox29.Checked = $maxMouseThrottle
    $checkbox30.Checked = $newStartMenu
    $checkbox31.Checked = $revertNewStart
  }
  else {
      
    [void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
    [void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')
    [System.Windows.Forms.Application]::EnableVisualStyles()

    # Create a form
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Windows 11 Tweaks'
    $form.Size = New-Object System.Drawing.Size(550, 520)
    $form.StartPosition = 'CenterScreen'
    $form.BackColor = 'Black'
    $form.Font = New-Object System.Drawing.Font('Segoe UI', 8)

    # Sidebar Panel
    $sidebarPanel = New-Object System.Windows.Forms.Panel
    $sidebarPanel.Location = New-Object System.Drawing.Point(0, 0)
    $sidebarPanel.Size = New-Object System.Drawing.Size(150, $form.ClientSize.Height)
    $sidebarPanel.BackColor = 'Black'

    $patchExplorerBtn = Create-ModernButton -Text 'Patch Explorer' -Location (New-Object Drawing.Point(15, 10)) -Size (New-Object System.Drawing.Size(130, 40)) -ClickAction {
      $patchExplorerPanel.Visible = $true
      $win10Panel.Visible = $false
      $miscPanel.Visible = $false
      $patchExplorerPanel.controls.add($OKButton)
      $patchExplorerPanel.controls.add($CancelButton)
      $patchExplorerBtn.Tag = 'Active'
      $win10Btn.Tag = 'Inactive'
      $miscBtn.Tag = 'Inactive'
      $patchExplorerPanel.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $win10Btn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $miscBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
    } -r 47 -g 49 -b 58 

    # Sidebar Buttons with Rounded Corners and Mouse-Over Effect
    <#
    $patchExplorerBtn = New-Object System.Windows.Forms.Button
    $patchExplorerBtn.Location = New-Object System.Drawing.Point(10, 10)
    $patchExplorerBtn.Size = New-Object System.Drawing.Size(130, 40)
    $patchExplorerBtn.Text = 'Patch Explorer'
    $patchExplorerBtn.ForeColor = 'White'
    $patchExplorerBtn.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51) # Initial inactive color
    $patchExplorerBtn.FlatAppearance.BorderSize = 0
    $patchExplorerBtn.FlatStyle = [System.Windows.Forms.FlatStyle]::Standard
    $patchExplorerBtn.Tag = 'Inactive' # Initial state
    $patchExplorerBtn.Add_MouseEnter({ $this.BackColor = [System.Drawing.Color]::FromArgb(90, 90, 90) })
    $patchExplorerBtn.Add_MouseLeave({
        if ($this.Tag -eq 'Active') { $this.BackColor = [System.Drawing.Color]::FromArgb(74, 74, 74) }
        else { $this.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51) }
      })
        #>
    $sidebarPanel.Controls.Add($patchExplorerBtn)

    $win10Btn = Create-ModernButton -Text 'Windows 10' -Location (New-Object Drawing.Point(15, 60)) -Size (New-Object System.Drawing.Size(130, 40)) -ClickAction {
      $patchExplorerPanel.Visible = $false
      $win10Panel.Visible = $true
      $miscPanel.Visible = $false
      $win10Panel.controls.add($OKButton)
      $win10Panel.controls.add($CancelButton)
      $patchExplorerBtn.Tag = 'Inactive'
      $win10Btn.Tag = 'Active'
      $miscBtn.Tag = 'Inactive'
      $patchExplorerPanel.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $win10Btn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
      $miscBtn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
    } -r 47 -g 49 -b 58 
    <#
    $win10Btn = New-Object System.Windows.Forms.Button
    $win10Btn.Location = New-Object System.Drawing.Point(10, 60)
    $win10Btn.Size = New-Object System.Drawing.Size(130, 40)
    $win10Btn.Text = 'Windows 10'
    $win10Btn.ForeColor = 'White'
    $win10Btn.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51) # Initial inactive color
    $win10Btn.FlatAppearance.BorderSize = 0
    $win10Btn.FlatStyle = [System.Windows.Forms.FlatStyle]::Standard
    $win10Btn.Tag = 'Inactive' # Initial state
    $win10Btn.Add_MouseEnter({ $this.BackColor = [System.Drawing.Color]::FromArgb(90, 90, 90) })
    $win10Btn.Add_MouseLeave({
        if ($this.Tag -eq 'Active') { $this.BackColor = [System.Drawing.Color]::FromArgb(74, 74, 74) }
        else { $this.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51) }
      })
      #>
    $sidebarPanel.Controls.Add($win10Btn)

    $miscBtn = Create-ModernButton -Text 'Misc' -Location (New-Object Drawing.Point(15, 110)) -Size (New-Object System.Drawing.Size(130, 40)) -ClickAction {
      $patchExplorerPanel.Visible = $false
      $win10Panel.Visible = $false
      $miscPanel.Visible = $true
      $miscPanel.controls.add($OKButton)
      $miscPanel.controls.add($CancelButton)
      $patchExplorerBtn.Tag = 'Inactive'
      $win10Btn.Tag = 'Inactive'
      $miscBtn.Tag = 'Active'
      $patchExplorerPanel.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $win10Btn.BackColor = [System.Drawing.Color]::FromArgb(47, 49, 58)
      $miscBtn.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
    } -r 47 -g 49 -b 58 
    <#
    $miscBtn = New-Object System.Windows.Forms.Button
    $miscBtn.Location = New-Object System.Drawing.Point(10, 110)
    $miscBtn.Size = New-Object System.Drawing.Size(130, 40)
    $miscBtn.Text = 'Misc'
    $miscBtn.ForeColor = 'White'
    $miscBtn.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51) # Initial inactive color
    $miscBtn.FlatAppearance.BorderSize = 0
    $miscBtn.FlatStyle = [System.Windows.Forms.FlatStyle]::Standard
    $miscBtn.Tag = 'Inactive' # Initial state
    $miscBtn.Add_MouseEnter({ $this.BackColor = [System.Drawing.Color]::FromArgb(90, 90, 90) })
    $miscBtn.Add_MouseLeave({
        if ($this.Tag -eq 'Active') { $this.BackColor = [System.Drawing.Color]::FromArgb(74, 74, 74) }
        else { $this.BackColor = [System.Drawing.Color]::FromArgb(51, 51, 51) }
      })
      #>
    $sidebarPanel.Controls.Add($miscBtn)

    # Info Button (Moved to Bottom-Left of Sidebar)
    $url = 'https://github.com/MP7BDO/mpware/blob/main/features.md#windows-11-tweaks'
    $infobutton = New-Object Windows.Forms.Button
    $infobutton.Location = New-Object Drawing.Point(5, 445)    
    $infobutton.Size = New-Object Drawing.Size(30, 27)
    $infobutton.Cursor = 'Hand'
    $infobutton.Add_Click({
        try {
          Start-Process $url -ErrorAction Stop
        }
        catch {
          Write-Status -Message 'No Internet Connected...' -Type Error
        }
      })
    $infobutton.BackColor = 'Black'
    $image = [System.Drawing.Image]::FromFile('C:\Windows\System32\SecurityAndMaintenance.png')
    $resizedImage = New-Object System.Drawing.Bitmap $image, 24, 25
    $infobutton.Image = $resizedImage
    $infobutton.ImageAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $infobutton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $infobutton.FlatAppearance.BorderSize = 0
    $sidebarPanel.Controls.Add($infobutton)

    $resetCheckedBttn = New-Object Windows.Forms.Button
    $resetCheckedBttn.Location = New-Object Drawing.Point(45, 445) 
    $resetCheckedBttn.Size = New-Object Drawing.Size(30, 27)
    $resetCheckedBttn.Cursor = 'Hand'
    $resetCheckedBttn.Add_Click({
        $Global:enabledOptions = @()
        function Get-AllControls($parent) {
          foreach ($control in $parent.Controls) {
            $control
            if ($control.Controls.Count -gt 0) {
              Get-AllControls $control
            }
          }
        }
        Get-AllControls $form | Where-Object { $_ -is [System.Windows.Forms.CheckBox] } | ForEach-Object { 
          $_.Checked = $false 
          $_.ForeColor = 'White'
        }
        
      })
    $resetCheckedBttn.BackColor = 'Black'
    $resetCheckedBttn.Text = 'X'
    $resetCheckedBttn.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $resetCheckedBttn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $resetCheckedBttn.FlatAppearance.BorderSize = 0
    $sidebarPanel.Controls.Add($resetCheckedBttn)

    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($resetCheckedBttn, 'Reset currently checked tweaks')

    $form.Controls.Add($sidebarPanel)

    # Main Content Panel
    $contentPanel = New-Object System.Windows.Forms.Panel
    $contentPanel.Location = New-Object System.Drawing.Point(160, 0)
    $contentPanel.Size = New-Object System.Drawing.Size(380, 520)     
   
    $form.Controls.Add($contentPanel)

    $type = $contentPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($contentPanel, $true, $null)

    # Patch Explorer Panel
    $patchExplorerPanel = New-Object System.Windows.Forms.Panel
    $patchExplorerPanel.Location = New-Object System.Drawing.Point(0, 0)
    $patchExplorerPanel.Size = New-Object System.Drawing.Size(380, 520)   
  
    $patchExplorerPanel.Visible = $true
    $contentPanel.Controls.Add($patchExplorerPanel)

    $type = $patchExplorerPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($patchExplorerPanel, $true, $null)

    $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
    $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

    # Override the form's paint event to apply the gradient
    $patchExplorerPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $patchExplorerPanel.Width, $patchExplorerPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })


    # Windows 10 Panel
    $win10Panel = New-Object System.Windows.Forms.Panel
    $win10Panel.Location = New-Object System.Drawing.Point(0, 0)
    $win10Panel.Size = New-Object System.Drawing.Size(380, 520)     
  
    $win10Panel.Visible = $false
    $contentPanel.Controls.Add($win10Panel)

    $type = $win10Panel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($win10Panel, $true, $null)

    

    # Override the form's paint event to apply the gradient
    $win10Panel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $win10Panel.Width, $win10Panel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })

    # Misc Panel
    $miscPanel = New-Object System.Windows.Forms.Panel
    $miscPanel.Location = New-Object System.Drawing.Point(0, 0)
    $miscPanel.Size = New-Object System.Drawing.Size(380, 520)   
    $miscPanel.Visible = $false
    $contentPanel.Controls.Add($miscPanel)

    $type = $miscPanel.GetType()
    $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
    $propInfo.SetValue($miscPanel, $true, $null)
    
    # Override the form's paint event to apply the gradient
    $miscPanel.Add_Paint({
        param($sender, $e)
        $rect = New-Object System.Drawing.Rectangle(0, 0, $miscPanel.Width, $miscPanel.Height)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
          $rect, 
          $startColor, 
          $endColor, 
          [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
        )
        $e.Graphics.FillRectangle($brush, $rect)
        $brush.Dispose()
      })


    # Labels
    $label1 = New-Object System.Windows.Forms.Label
    $label1.Location = New-Object System.Drawing.Point(10, 10)
    $label1.Size = New-Object System.Drawing.Size(200, 20)
    $label1.Text = 'Patch Explorer'
    $label1.ForeColor = 'White'
    $label1.BackColor = [System.Drawing.Color]::Transparent
    $label1.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $patchExplorerPanel.Controls.Add($label1)

    $label2 = New-Object System.Windows.Forms.Label
    $label2.Location = New-Object System.Drawing.Point(10, 10)
    $label2.Size = New-Object System.Drawing.Size(200, 20)
    $label2.Text = 'Windows 10'
    $label2.ForeColor = 'White'
    $label2.BackColor = [System.Drawing.Color]::Transparent
    $label2.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $win10Panel.Controls.Add($label2)

    $label3 = New-Object System.Windows.Forms.Label
    $label3.Location = New-Object System.Drawing.Point(10, 10)
    $label3.Size = New-Object System.Drawing.Size(200, 20)
    $label3.Text = 'Misc'
    $label3.ForeColor = 'White'
    $label3.BackColor = [System.Drawing.Color]::Transparent
    $label3.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $miscPanel.Controls.Add($label3)

    # Patch Explorer Checkboxes

    $checkbox2.Location = New-Object System.Drawing.Point(20, 40)
    $checkbox2.Size = New-Object System.Drawing.Size(200, 30)
    $checkbox2.Text = 'Remove Rounded Edges'
    $checkbox2.ForeColor = 'White'
    $checkbox2.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $patchExplorerPanel.Controls.Add($checkbox2)


    $checkbox4.Location = New-Object System.Drawing.Point(20, 70)
    $checkbox4.Size = New-Object System.Drawing.Size(360, 30)
    $checkbox4.Text = 'Enable Windows 10 TaskBar and StartMenu (ExplorerPatcher)'
    $checkbox4.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox4.ForeColor = 'White'
    $patchExplorerPanel.Controls.Add($checkbox4)


    $checkbox6.Location = New-Object System.Drawing.Point(20, 100)
    $checkbox6.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox6.Text = 'Enable Windows 10 File Explorer'
    $checkbox6.ForeColor = 'White'
    $checkbox6.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $patchExplorerPanel.Controls.Add($checkbox6)


    $checkbox7.Location = New-Object System.Drawing.Point(20, 130)
    $checkbox7.Size = New-Object System.Drawing.Size(350, 30)
    $checkbox7.Text = 'Replace Start Menu and Search with OpenShell'
    $checkbox7.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox7.ForeColor = 'White'
    $patchExplorerPanel.Controls.Add($checkbox7)

    # Windows 10 Checkboxes

    $checkbox9.Location = New-Object System.Drawing.Point(20, 40)
    $checkbox9.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox9.Text = 'Restore Windows 10 Recycle Bin Icon'
    $checkbox9.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox9.ForeColor = 'White'
    $win10Panel.Controls.Add($checkbox9)

 
    $checkbox13.Location = New-Object System.Drawing.Point(20, 70)
    $checkbox13.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox13.Text = 'Restore Windows 10 Snipping Tool'
    $checkbox13.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox13.ForeColor = 'White'
    $win10Panel.Controls.Add($checkbox13)

    $checkbox15.Location = New-Object System.Drawing.Point(20, 100)
    $checkbox15.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox15.Text = 'Restore Windows 10 Task Manager'
    $checkbox15.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox15.ForeColor = 'White'
    $win10Panel.Controls.Add($checkbox15)


    $checkbox17.Location = New-Object System.Drawing.Point(20, 130)
    $checkbox17.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox17.Text = 'Restore Windows 10 Notepad'
    $checkbox17.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox17.ForeColor = 'White'
    $win10Panel.Controls.Add($checkbox17)

    $checkbox19.Location = New-Object System.Drawing.Point(20, 160)
    $checkbox19.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox19.Text = 'Restore Windows 10 Icons'
    $checkbox19.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox19.ForeColor = 'White'
    $win10Panel.Controls.Add($checkbox19)

    $checkbox20.Location = New-Object System.Drawing.Point(20, 190)
    $checkbox20.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox20.Text = 'Restore Windows 10 Sounds'
    $checkbox20.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox20.ForeColor = 'White'
    $win10Panel.Controls.Add($checkbox20)

    # Misc Checkboxes

    $checkbox3.Location = New-Object System.Drawing.Point(20, 40)
    $checkbox3.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox3.Text = 'Set all Services to Manual'
    $checkbox3.ForeColor = 'White'
    $checkbox3.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $miscPanel.Controls.Add($checkbox3)

    $checkbox5.Location = New-Object System.Drawing.Point(20, 70)
    $checkbox5.Size = New-Object System.Drawing.Size(250, 30)
    $checkbox5.Text = 'Show all Taskbar Tray Icons'
    $checkbox5.ForeColor = 'White'
    $checkbox5.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $miscPanel.Controls.Add($checkbox5)

    $checkbox21.Location = New-Object System.Drawing.Point(20, 100)
    $checkbox21.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox21.Text = 'Dark Winver'
    $checkbox21.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox21.ForeColor = 'White'
    $miscPanel.Controls.Add($checkbox21)

    $checkbox22.Location = New-Object System.Drawing.Point(20, 130)
    $checkbox22.Size = New-Object System.Drawing.Size(300, 30)
    $checkbox22.Text = 'Remove Quick Setting Tiles (24H2+)'
    $checkbox22.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox22.ForeColor = 'White'
    $miscPanel.Controls.Add($checkbox22)


    $checkbox24.Location = New-Object System.Drawing.Point(20, 160)
    $checkbox24.Size = New-Object System.Drawing.Size(360, 30)
    $checkbox24.Text = 'Disable Notepad Tabs and Rewrite'
    $checkbox24.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox24.ForeColor = 'White'
    $miscPanel.Controls.Add($checkbox24)


    $checkbox26.Location = New-Object System.Drawing.Point(20, 190)
    $checkbox26.Size = New-Object System.Drawing.Size(360, 30)
    $checkbox26.Text = 'Hide Ads In Settings'
    $checkbox26.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox26.ForeColor = 'White'
    $miscPanel.Controls.Add($checkbox26)



    $checkbox28.Location = New-Object System.Drawing.Point(20, 220)
    $checkbox28.Size = New-Object System.Drawing.Size(360, 30)
    $checkbox28.Text = 'Small Taskbar Icons'
    $checkbox28.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox28.ForeColor = 'White'
    $miscPanel.Controls.Add($checkbox28)

    $checkbox29.Location = New-Object System.Drawing.Point(20, 250)
    $checkbox29.Size = New-Object System.Drawing.Size(360, 30)
    $checkbox29.Text = 'Set Background Mouse Throttle to 50hz'
    $checkbox29.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox29.ForeColor = 'White'
    $miscPanel.Controls.Add($checkbox29)

    $checkbox30.Location = New-Object System.Drawing.Point(20, 280)
    $checkbox30.Size = New-Object System.Drawing.Size(360, 30)
    $checkbox30.Text = 'Enable New Start Menu (25H2)'
    $checkbox30.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox30.ForeColor = 'White'
    $miscPanel.Controls.Add($checkbox30)

    $checkbox31.Location = New-Object System.Drawing.Point(20, 310)
    $checkbox31.Size = New-Object System.Drawing.Size(360, 30)
    $checkbox31.Text = 'Revert New 25H2 Start Menu'
    $checkbox31.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $checkbox31.ForeColor = 'White'
    $miscPanel.Controls.Add($checkbox31)

    foreach ($setting in $settings.GetEnumerator()) {
      if ($Global:enabledOptions -contains $setting.key) {
        $setting.value.ForeColor = [System.Drawing.Color]::Gray
        $setting.value.checked = $true
      }
    }


    $OKButton = Create-ModernButton -Text 'OK' -Location (New-Object Drawing.Point(140, 440)) -Size (New-Object Drawing.Size(100, 27)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2

    $patchExplorerPanel.controls.add($OKButton)

    $CancelButton = Create-ModernButton -Text 'Cancel' -Location (New-Object Drawing.Point(250, 440)) -Size (New-Object Drawing.Size(100, 27)) -DialogResult ([System.Windows.Forms.DialogResult]::Cancel) -borderSize 2

    $patchExplorerPanel.controls.add($CancelButton)
  


    $patchExplorerPanel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }

    $win10Panel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }

    $miscPanel.Controls | Where-Object { $_.GetType().Name -eq 'CheckBox' } | ForEach-Object {
      $_.BackColor = [System.Drawing.Color]::Transparent
    }

    # Activate the form
    $form.Add_Shown({ $form.Activate() })
    $result = $form.ShowDialog()
      
  }
      
      
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
      
    if (!($Autorun)) {
      #loop through checkbox hashtable to update config
      $settings.GetEnumerator() | ForEach-Object {
            
        $settingName = $_.Key
        $checkbox = $_.Value
        #dont update config with options already checked
        if ($Global:enabledOptions -contains $settingName) {
          $checkbox.Checked = $false
        }
        
        if ($checkbox.Checked) {
          update-config -setting $settingName -value 1
        }
      }
    }
      
    if ($checkbox2.Checked) {
      Write-Status -Message 'Disabling Rounded Edges...' -Type Output
      #disable rounded edges
      $path = Search-File '*win11-toggle-rounded-corners.exe'
      Start-Process $path -ArgumentList '--autostart --disable' -WindowStyle Hidden -Wait

      #apply on startup
      $newDir = New-Item -Path 'C:\Program Files\DisableRoundedEdges' -ItemType Directory -Force
      Move-Item -Path $path -Destination $newDir.FullName -Force
      
      #create shortcut
      $WshShell = New-Object -comObject WScript.Shell
      $Shortcut = $WshShell.CreateShortcut('C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\win11-toggle-rounded-corners.lnk')
      $Shortcut.TargetPath = 'C:\Program Files\DisableRoundedEdges\win11-toggle-rounded-corners.exe'
      $Shortcut.Arguments = '--autostart --disable'
      $Shortcut.Save()
      
    }
      
    if ($checkbox4.Checked) {
      if (!(Test-Path -Path "$systemDrive\Program Files\ExplorerPatcher\ep_setup.exe" -ErrorAction SilentlyContinue)) {
        #install explorer patcher
        try {
          # get latest release
          $releasesUrl = 'https://api.github.com/repos/valinet/ExplorerPatcher/releases/latest'
          $release = Invoke-RestMethod -Uri $releasesUrl 
          # create download url
          $downloadUrl = $release.assets | Where-Object { $_.name -eq 'ep_setup.exe' } | Select-Object -ExpandProperty browser_download_url

          # download setup
          Remove-Item -Path "$tempDir\setup.exe" -Force -ErrorAction SilentlyContinue
          Invoke-WebRequest -Uri $downloadUrl -OutFile "$tempDir\setup.exe" 

        }
        catch {
          Write-Status -Message 'This tweak requires Internet Connection' -Type Error
        }
        #disable notis
        Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Microsoft.Windows.Explorer' /v 'Enabled' /t REG_DWORD /d '0' /f
        #install explorer patcher 
        Write-Status -Message 'Installing Explorer Patcher...' -Type Output
        Start-Process "$tempDir\setup.exe" -WindowStyle Hidden -Wait 
      }
      
      Write-Status -Message 'Applying Explorer Patcher Settings...' -Type Output
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' /v 'Start_ShowClassicMode' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' /v 'TaskbarAl' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\Software\ExplorerPatcher' /v 'TaskbarGlomLevel' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\Software\ExplorerPatcher' /v 'MMTaskbarGlomLevel' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\Software\ExplorerPatcher' /v 'HideControlCenterButton' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer' /v 'DisableNotificationCenter' /t REG_DWORD /d '1' /f
    }
      
      
    if ($checkbox6.Checked) {
      Write-Status -Message 'Enabling Windows 10 File Explorer Ribbon...' -Type Output
      Reg.exe add 'HKCU\Software\Classes\CLSID\{2aa9162e-c906-4dd9-ad0b-3d24a8eef5a0}' /ve /t REG_SZ /d 'CLSID_ItemsViewAdapter' /f >$null
      Reg.exe add 'HKCU\Software\Classes\CLSID\{2aa9162e-c906-4dd9-ad0b-3d24a8eef5a0}\InProcServer32' /ve /t REG_SZ /d 'C:\Windows\System32\Windows.UI.FileExplorer.dll_' /f >$null
      Reg.exe add 'HKCU\Software\Classes\CLSID\{2aa9162e-c906-4dd9-ad0b-3d24a8eef5a0}\InProcServer32' /v 'ThreadingModel' /t REG_SZ /d 'Apartment' /f >$null
      Reg.exe add 'HKCU\Software\Classes\CLSID\{6480100b-5a83-4d1e-9f69-8ae5a88e9a33}' /ve /t REG_SZ /d 'File Explorer Xaml Island View Adapter' /f >$null
      Reg.exe add 'HKCU\Software\Classes\CLSID\{6480100b-5a83-4d1e-9f69-8ae5a88e9a33}\InProcServer32' /ve /t REG_SZ /d 'C:\Windows\System32\Windows.UI.FileExplorer.dll_' /f >$null
      Reg.exe add 'HKCU\Software\Classes\CLSID\{6480100b-5a83-4d1e-9f69-8ae5a88e9a33}\InProcServer32' /v 'ThreadingModel' /t REG_SZ /d 'Apartment' /f >$null
      Reg.exe add 'HKCU\Software\Microsoft\Internet Explorer\Toolbar\ShellBrowser' /v 'ITBar7Layout' /t REG_BINARY /d '13000000000000000000000020000000100001000000000001000000010700005e01000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000' /f >$null
      #stop explorer and then open to apply minimized ribbon reg keys
      Stop-Process -Name explorer -Force
      while (!(Get-Process -Name explorer -ErrorAction SilentlyContinue)) {
        Start-Sleep 1
      }
      Start-process explorer.exe -args 'shell:::{20D04FE0-3AEA-1069-A2D8-08002B30309D}'
      Start-Sleep 1
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Ribbon' /v 'MinimizedStateTabletModeOn' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Ribbon' /v 'MinimizedStateTabletModeOff' /t REG_DWORD /d '1' /f
      Stop-Process -Name explorer -Force
    }

      
      
      
    if ($checkbox3.Checked) {
      #set all services to manual (that are allowed)
      $services = Get-Service
      $servicesKeep = @(
        'AudioEndpointBuilder',
        'Audiosrv',
        'EventLog',
        'SysMain',
        'Themes',
        'WSearch',
        'NVDisplay.ContainerLocalSystem',
        'WlanSvc',
        'BFE', 
        'BrokerInfrastructure', 
        'CoreMessagingRegistrar', 
        'Dnscache', 
        'LSM', 
        'mpssvc', 
        'RpcEptMapper', 
        'Schedule', 
        'SystemEventsBroker', 
        'StateRepository', 
        'TextInputManagementService', 
        'sppsvc'
      )
      foreach ($service in $services) { 
        if ($service.StartType -like '*Auto*') {
          if ($servicesKeep -notcontains $service.Name) {
            try {
              Set-Service -Name $service.Name -StartupType Manual -ErrorAction Stop
            }
            catch {
              $regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$($service.Name)"
              Set-ItemProperty -Path $regPath -Name 'Start' -Value 3 -ErrorAction SilentlyContinue
            }
              
          }         
        }
      }
      Write-Status -Message 'Services Set to Manual...' -Type Output
    }
    
    
    
    if ($checkbox5.Checked) {
      #show all current tray icons
      Write-Status -Message 'Showing All Apps on Taskbar' -Type Output
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer' /v 'EnableAutoTray' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\TrayNotify' /v 'SystemTrayChevronVisibility' /t REG_DWORD /d '0' /f
      $keys = Get-ChildItem -Path 'registry::HKEY_CURRENT_USER\Control Panel\NotifyIconSettings' -Recurse -Force
      foreach ($key in $keys) {
        Set-ItemProperty -Path "registry::$key" -Name 'IsPromoted' -Value 1 -Force

      }
      #create task to update task tray on log on

      #create updater script
      $scriptContent = @"
`$keys = Get-ChildItem -Path 'registry::HKEY_CURRENT_USER\Control Panel\NotifyIconSettings' -Recurse -Force

foreach (`$key in `$keys) {
    #if the value is set to 0 do not set it to 1
    #set 1 when no reg key is there (new apps)
    if ((Get-ItemProperty -Path "registry::`$key").IsPromoted -eq 0) {
    }
    else {
        Set-ItemProperty -Path "registry::`$key" -Name 'IsPromoted' -Value 1 -Force
    }
}
"@

      $scriptPath = "$env:ProgramData\UpdateTaskTrayIcons.ps1"
      Set-Content -Path $scriptPath -Value $scriptContent -Force

      $vbsScriptContent = @"
Dim shell,command
command = "powershell.exe -ep bypass -c ""$env:ProgramData\UpdateTaskTrayIcons.ps1"""
Set shell = CreateObject("WScript.Shell")
shell.Run command,0
"@
      $vbsPath = "$env:ProgramData\UpdateTaskTraySilent.vbs"
      Set-Content -Path $vbsPath -Value $vbsScriptContent -Force

      #get username and sid
      $currentUserName = $env:COMPUTERNAME + '\' + $env:USERNAME
      $username = Get-LocalUser -Name $env:USERNAME | Select-Object -ExpandProperty sid

      $content = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Date>2024-05-20T12:59:50.8741407</Date>
    <Author>$currentUserName</Author>
    <URI>\UpdateTaskTray</URI>
  </RegistrationInfo>
   <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>$username</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>true</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>true</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>false</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>true</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT72H</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>wscript.exe</Command>
      <Arguments>C:\ProgramData\UpdateTaskTraySilent.vbs</Arguments>
    </Exec>
  </Actions>
</Task>
"@
      Set-Content -Path "$tempDir\UpdateTaskTray" -Value $content -Force

      schtasks /Create /XML "$tempDir\UpdateTaskTray" /TN '\UpdateTaskTray' /F | Out-Null 

      Remove-Item -Path "$tempDir\UpdateTaskTray" -Force -ErrorAction SilentlyContinue
      Write-Status -Message 'Update Task Tray Created...New Apps Will Be Shown Upon Restarting' -Type Output
     
    }
    
    
    if ($checkbox7.Checked) {
      Write-Status -Message 'Installing Open Shell...' -Type Output
      #install openshell startmenu only
      $setup = Search-File '*OpenShellSetup.exe'
      Start-Process $setup -ArgumentList '/qn ADDLOCAL=StartMenu'
      Write-Status -Message 'Disabling Windows Indexing...' -Type Output
     
      Get-Service -Name WSearch | Set-Service -StartupType Disabled
    
      #import custom settings
      $regContent = @'
Windows Registry Editor Version 5.00

[HKEY_CURRENT_USER\Software\OpenShell\StartMenu\Settings]
"MenuStyle"="Win7"
"ShiftWin"="Nothing"
"ControlPanelCategories"=dword:00000000
"ProgramsStyle"="Inline"
"AllProgramsMetro"=dword:00000000
"FoldersFirst"=dword:00000000
"OpenPrograms"=dword:00000000
"ProgramsMenuDelay"=dword:000000c8
"HideProgramsMetro"=dword:00000001
"PinnedPrograms"="PinnedItems"
"RecentPrograms"="None"
"EnableJumplists"=dword:00000000
"JumplistKeys"="Open"
"ShutdownCommand"="CommandRestart"
"HybridShutdown"=dword:00000000
"StartScreenShortcut"=dword:00000000
"MainSortZA"=dword:00000000
"MainSortOnce"=dword:00000000
"HighlightNew"=dword:00000000
"CheckWinUpdates"=dword:00000000
"MenuDelay"=dword:000000c8
"SplitMenuDelay"=dword:000000c8
"EnableDragDrop"=dword:00000000
"ScrollType"="NoScroll"
"SameSizeColumns"=dword:00000001
"SingleClickFolders"=dword:00000001
"OpenTruePath"=dword:00000001
"EnableAccessibility"=dword:00000001
"ShowNextToTaskbar"=dword:00000001
"DelayIcons"=dword:00000000
"BoldSettings"=dword:00000000
"EnableAccelerators"=dword:00000000
"SearchBox"="Normal"
"SearchPrograms"=dword:00000001
"SearchInternet"=dword:00000000
"MoreResults"=dword:00000000
"InvertMetroIcons"=dword:00000000
"AlignToWorkArea"=dword:00000000
"MainMenuAnimate"=dword:00000000
"MainMenuAnimation"="None"
"SubMenuAnimation"="None"
"NumericSort"=dword:00000001
"FontSmoothing"="Default"
"MenuShadow"=dword:00000000
"EnableGlass"=dword:00000000
"GlassOverride"=dword:00000001
"GlassColor"=dword:00191919
"GlassOpacity"=dword:00000000
"SkinC1"="Full Glass"
"SkinVariationC1"=""
"SkinOptionsC1"=hex(7):43,00,41,00,50,00,54,00,49,00,4f,00,4e,00,3d,00,31,00,\
  00,00,55,00,53,00,45,00,52,00,5f,00,49,00,4d,00,41,00,47,00,45,00,3d,00,30,\
  00,00,00,55,00,53,00,45,00,52,00,5f,00,4e,00,41,00,4d,00,45,00,3d,00,30,00,\
  00,00,43,00,45,00,4e,00,54,00,45,00,52,00,5f,00,4e,00,41,00,4d,00,45,00,3d,\
  00,30,00,00,00,53,00,4d,00,41,00,4c,00,4c,00,5f,00,49,00,43,00,4f,00,4e,00,\
  53,00,3d,00,30,00,00,00,4c,00,41,00,52,00,47,00,45,00,5f,00,46,00,4f,00,4e,\
  00,54,00,3d,00,30,00,00,00,49,00,43,00,4f,00,4e,00,5f,00,46,00,52,00,41,00,\
  4d,00,45,00,53,00,3d,00,31,00,00,00,4f,00,50,00,41,00,51,00,55,00,45,00,3d,\
  00,30,00,00,00,00,00
"SkinW7"="Immersive"
"SkinVariationW7"=""
"SkinOptionsW7"=hex(7):4c,00,49,00,47,00,48,00,54,00,3d,00,30,00,00,00,44,00,\
  41,00,52,00,4b,00,3d,00,31,00,00,00,41,00,55,00,54,00,4f,00,3d,00,30,00,00,\
  00,55,00,53,00,45,00,52,00,5f,00,49,00,4d,00,41,00,47,00,45,00,3d,00,30,00,\
  00,00,55,00,53,00,45,00,52,00,5f,00,4e,00,41,00,4d,00,45,00,3d,00,30,00,00,\
  00,43,00,45,00,4e,00,54,00,45,00,52,00,5f,00,4e,00,41,00,4d,00,45,00,3d,00,\
  30,00,00,00,53,00,4d,00,41,00,4c,00,4c,00,5f,00,49,00,43,00,4f,00,4e,00,53,\
  00,3d,00,31,00,00,00,4f,00,50,00,41,00,51,00,55,00,45,00,3d,00,31,00,00,00,\
  44,00,49,00,53,00,41,00,42,00,4c,00,45,00,5f,00,4d,00,41,00,53,00,4b,00,3d,\
  00,30,00,00,00,42,00,4c,00,41,00,43,00,4b,00,5f,00,54,00,45,00,58,00,54,00,\
  3d,00,30,00,00,00,42,00,4c,00,41,00,43,00,4b,00,5f,00,46,00,52,00,41,00,4d,\
  00,45,00,53,00,3d,00,30,00,00,00,54,00,52,00,41,00,4e,00,53,00,50,00,41,00,\
  52,00,45,00,4e,00,54,00,5f,00,4c,00,45,00,53,00,53,00,3d,00,30,00,00,00,54,\
  00,52,00,41,00,4e,00,53,00,50,00,41,00,52,00,45,00,4e,00,54,00,5f,00,4d,00,\
  4f,00,52,00,45,00,3d,00,31,00,00,00,00,00
"EnableStartButton"=dword:00000000
"StartButtonType"="AeroButton"
"CustomTaskbar"=dword:00000000
"TaskbarLook"="Opaque"
"TaskbarColor"=dword:000000ff
"TaskbarTextColor"=dword:000000ff
"SkipMetro"=dword:00000001
"OpenMouseMonitor"=dword:00000000
"MenuItems7"=hex(7):49,00,74,00,65,00,6d,00,31,00,2e,00,43,00,6f,00,6d,00,6d,\
  00,61,00,6e,00,64,00,3d,00,63,00,6f,00,6d,00,70,00,75,00,74,00,65,00,72,00,\
  00,00,49,00,74,00,65,00,6d,00,31,00,2e,00,53,00,65,00,74,00,74,00,69,00,6e,\
  00,67,00,73,00,3d,00,4e,00,4f,00,45,00,58,00,50,00,41,00,4e,00,44,00,00,00,\
  49,00,74,00,65,00,6d,00,32,00,2e,00,43,00,6f,00,6d,00,6d,00,61,00,6e,00,64,\
  00,3d,00,64,00,6f,00,77,00,6e,00,6c,00,6f,00,61,00,64,00,73,00,00,00,49,00,\
  74,00,65,00,6d,00,32,00,2e,00,54,00,69,00,70,00,3d,00,24,00,4d,00,65,00,6e,\
  00,75,00,2e,00,44,00,6f,00,77,00,6e,00,6c,00,6f,00,61,00,64,00,54,00,69,00,\
  70,00,00,00,49,00,74,00,65,00,6d,00,32,00,2e,00,53,00,65,00,74,00,74,00,69,\
  00,6e,00,67,00,73,00,3d,00,4e,00,4f,00,45,00,58,00,50,00,41,00,4e,00,44,00,\
  00,00,49,00,74,00,65,00,6d,00,33,00,2e,00,43,00,6f,00,6d,00,6d,00,61,00,6e,\
  00,64,00,3d,00,75,00,73,00,65,00,72,00,5f,00,64,00,6f,00,63,00,75,00,6d,00,\
  65,00,6e,00,74,00,73,00,00,00,49,00,74,00,65,00,6d,00,33,00,2e,00,54,00,69,\
  00,70,00,3d,00,24,00,4d,00,65,00,6e,00,75,00,2e,00,55,00,73,00,65,00,72,00,\
  44,00,6f,00,63,00,75,00,6d,00,65,00,6e,00,74,00,73,00,54,00,69,00,70,00,00,\
  00,49,00,74,00,65,00,6d,00,33,00,2e,00,53,00,65,00,74,00,74,00,69,00,6e,00,\
  67,00,73,00,3d,00,4e,00,4f,00,45,00,58,00,50,00,41,00,4e,00,44,00,00,00,49,\
  00,74,00,65,00,6d,00,34,00,2e,00,43,00,6f,00,6d,00,6d,00,61,00,6e,00,64,00,\
  3d,00,73,00,65,00,70,00,61,00,72,00,61,00,74,00,6f,00,72,00,00,00,49,00,74,\
  00,65,00,6d,00,35,00,2e,00,43,00,6f,00,6d,00,6d,00,61,00,6e,00,64,00,3d,00,\
  70,00,63,00,5f,00,73,00,65,00,74,00,74,00,69,00,6e,00,67,00,73,00,00,00,49,\
  00,74,00,65,00,6d,00,35,00,2e,00,53,00,65,00,74,00,74,00,69,00,6e,00,67,00,\
  73,00,3d,00,54,00,52,00,41,00,43,00,4b,00,5f,00,52,00,45,00,43,00,45,00,4e,\
  00,54,00,00,00,49,00,74,00,65,00,6d,00,36,00,2e,00,43,00,6f,00,6d,00,6d,00,\
  61,00,6e,00,64,00,3d,00,63,00,6f,00,6e,00,74,00,72,00,6f,00,6c,00,5f,00,70,\
  00,61,00,6e,00,65,00,6c,00,00,00,49,00,74,00,65,00,6d,00,36,00,2e,00,4c,00,\
  61,00,62,00,65,00,6c,00,3d,00,24,00,4d,00,65,00,6e,00,75,00,2e,00,43,00,6f,\
  00,6e,00,74,00,72,00,6f,00,6c,00,50,00,61,00,6e,00,65,00,6c,00,00,00,49,00,\
  74,00,65,00,6d,00,36,00,2e,00,54,00,69,00,70,00,3d,00,24,00,4d,00,65,00,6e,\
  00,75,00,2e,00,43,00,6f,00,6e,00,74,00,72,00,6f,00,6c,00,50,00,61,00,6e,00,\
  65,00,6c,00,54,00,69,00,70,00,00,00,49,00,74,00,65,00,6d,00,36,00,2e,00,53,\
  00,65,00,74,00,74,00,69,00,6e,00,67,00,73,00,3d,00,54,00,52,00,41,00,43,00,\
  4b,00,5f,00,52,00,45,00,43,00,45,00,4e,00,54,00,7c,00,4e,00,4f,00,45,00,58,\
  00,50,00,41,00,4e,00,44,00,00,00,49,00,74,00,65,00,6d,00,37,00,2e,00,43,00,\
  6f,00,6d,00,6d,00,61,00,6e,00,64,00,3d,00,72,00,75,00,6e,00,00,00,00,00
"CascadingMenu"=dword:00000000
"ShowNewFolder"=dword:00000000
"EnableExit"=dword:00000000
"EnableExplorer"=dword:00000000
"DisablePinExt"=dword:00000000
'@
      New-Item -Path 'C:\OpenShellSettings.reg' -ItemType File -Force
      Add-Content -Path 'C:\OpenShellSettings.reg' -Value $regContent -Force
      Start-Process regedit.exe -ArgumentList '/s C:\OpenShellSettings.reg' 

      #move all current shortcuts in windows start menu dir to openshell pinned dir
      Write-Status -Message 'Moving Shortcuts...' -Type Output
  
      if (!(Test-Path "$env:USERPROFILE\AppData\Roaming\OpenShell\Pinned")) {
        New-Item -Path "$env:USERPROFILE\AppData\Roaming\OpenShell\Pinned" -ItemType Directory -Force | Out-Null

      }
      $startShortcuts = Get-ChildItem -Path "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\Start Menu\Programs"  -Filter *.lnk -Force
      $startShortcuts += Get-ChildItem -Path 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs'  -Filter *.lnk -Force 
      foreach ($shortcut in $startShortcuts) {
        #dont move Administrative Tools shortcut
        if ($shortcut.FullName -notlike '*Administrative Tools*') {
          Move-Item -Path $shortcut.FullName -Destination "$env:USERPROFILE\AppData\Roaming\OpenShell\Pinned" -Force
        }

      }

      #restart explorer to apply changes
      Write-Status -Message 'Explorer Restarting to Apply Changes...' -Type Output
    
      Stop-Process -name 'sihost' -force

      Remove-Item -Path 'C:\OpenShellSettings.reg' -Force -ErrorAction SilentlyContinue

    }
    
    
    if ($checkbox9.Checked) {
      Write-Status -Message 'Replacing Recycle Bin Icon with Windows 10...' -Type Output
      $iconEmpty = "$env:SystemRoot\System32\imageres.dll,-55"
      $iconFull = "$env:SystemRoot\System32\imageres.dll,-54"

      $names = @('(Default)', 'full', 'empty')

      #set each regkey to win 10 icon paths
      foreach ($name in $names) {
        if ($name -eq 'full') {
          $value = "$iconFull,0"
        }
        else {
          $value = "$iconEmpty,0"
        }

        Set-ItemProperty -Path 'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\CLSID\{645FF040-5081-101B-9F08-00AA002F954E}\DefaultIcon' -Name $name -Value $value -Force
      }

    }


    if ($checkbox13.Checked) {
      Write-Status -Message 'Restoring Windows 10 Snipping Tool...' -Type Output
      #old snipping
      #uninstall uwp snipping
      $ProgressPreference = 'SilentlyContinue'
      Get-AppXPackage '*ScreenSketch*' -AllUsers -ErrorAction SilentlyContinue | ForEach-Object { Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ErrorAction SilentlyContinue }
      Get-AppxPackage '*ScreenSketch*' -ErrorAction SilentlyContinue | Remove-AppxPackage -ErrorAction SilentlyContinue
      Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Where-Object DisplayName -like '*ScreenSketch*' | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue

      #takeown and remove
      takeown /f C:\Windows\System32\en-US /r /d Y >$null
      icacls C:\Windows\System32\en-US /grant *S-1-5-32-544:F /t >$null
      Remove-Item -Path 'C:\Windows\System32\SnippingTool.exe' -Force -ErrorAction SilentlyContinue
      Remove-Item -Path 'C:\Windows\System32\en-US\SnippingTool.exe.mui' -Force -ErrorAction SilentlyContinue

      $snippingexe = Search-File '*SnippingTool.exe'
      $snippingmui = Search-File '*SnippingTool.exe.mui'
      Move-Item $snippingexe -Destination 'C:\Windows\System32' -Force
      Move-Item $snippingmui -Destination 'C:\Windows\System32\en-US' -Force
      #create startmenu shortcut
      $WshShell = New-Object -comObject WScript.Shell
      $Shortcut = $WshShell.CreateShortcut('C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Accessories\SnippingTool.lnk')
      $Shortcut.TargetPath = ('C:\Windows\System32\SnippingTool.exe')
      $Shortcut.Save()
    }

    if ($checkbox15.Checked) {
      Write-Status -Message 'Replacing Windows 11 Taskmanager with Windows 10...' -Type Output
      
      #replace task manager with wrapper to run taskmgr -d
      $wrapper = Search-File '*zTaskmgr.exe'

      takeown /f C:\Windows\System32\Taskmgr.exe *>$null
      icacls C:\Windows\System32\Taskmgr.exe /grant *S-1-5-32-544:F /t *>$null

      Rename-Item C:\Windows\System32\Taskmgr.exe -NewName 'Taskmgr_WIN11.exe' -Force | Out-Null
      Copy-Item $wrapper -Destination 'C:\Windows\System32' -Force
      Start-Sleep 1
      Rename-Item 'C:\Windows\System32\zTaskmgr.exe' -NewName 'Taskmgr.exe' -Force

      #copy syswow64 taskmanager and replace system32
      # takeown /f C:\Windows\System32\Taskmgr.exe *>$null
      # icacls C:\Windows\System32\Taskmgr.exe /grant *S-1-5-32-544:F /t *>$null
      # Copy-Item -Path 'C:\Windows\SysWOW64\Taskmgr.exe' -Destination 'C:\Windows\System32' -Force

    
      
    }

    if ($checkbox17.Checked) {

      Write-Status -Message 'Enabling Windows 10 Notepad...' -Type Output

      try {
        Get-AppXPackage '*notepad*' -AllUsers -ErrorAction Stop | ForEach-Object { Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ErrorAction Stop }
      }
      catch {}
      try {
        Remove-AppxPackage -Package '*notepad*' -AllUsers -ErrorAction Stop
      }
      catch {}
      try {
        Get-AppxProvisionedPackage -Online | Where-Object DisplayName -like '*notepad*' | Remove-AppxProvisionedPackage -AllUsers -Online -ErrorAction Stop | Out-Null
      }
      catch {} 
      

      Add-WindowsCapability -Online -Name Microsoft.Windows.Notepad.System~~~~0.0.1.0 

      Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\notepad.exe' -Force -ErrorAction SilentlyContinue
      Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Applications\notepad.exe' -Name NoOpenWith -Force -ErrorAction SilentlyContinue

      # Reg.exe add 'HKLM\SOFTWARE\Classes\txtfilelegacy\shell\Open\command' /ve /t REG_SZ /d 'C:\Windows\System32\Notepad.exe "%1"' /f
      #Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.txt\UserChoice' /v 'ProgId' /t REG_SZ /d 'txtfilelegacy' /f
      
      $newtxt = Search-File '*newtxt.reg'
      $txtfile = Search-File '*txtfile.reg'
      regedit.exe /s $newtxt
      regedit.exe /s $txtfile
      
      $WshShell = New-Object -comObject WScript.Shell
      $Shortcut = $WshShell.CreateShortcut('C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Notepad.lnk')
      $Shortcut.TargetPath = 'C:\Windows\System32\Notepad.exe'
      $Shortcut.Save()

      
    }

  

    if ($checkbox19.Checked) {
      #enable windows 10 icons
      $ogIcons = 'C:\Windows\SystemResources\imageres.dll.mun'
      Write-Status -Message 'Making Backup of C:\Windows\SystemResources\imageres.dll.mun > zBackup' -Type Output
      if (!(Test-Path "$env:USERPROFILE\zBackup")) {
        New-Item "$env:USERPROFILE\zBackup" -ItemType Directory | Out-Null
      }

      #takeownership and move win10 imageres
      takeown.exe /f 'C:\Windows\SystemResources' *>$null
      icacls.exe 'C:\Windows\SystemResources' /grant *S-1-5-32-544:F /T /C *>$null
      takeown.exe /f $ogIcons *>$null
      icacls.exe $ogIcons /grant *S-1-5-32-544:F /T /C *>$null
      Copy-item $ogIcons -Destination "$env:USERPROFILE\zBackup" -Force
      Write-Status -Message 'Replacing With Windows 10 Icons...' -Type Output
      Remove-Item $ogIcons -Force
      $win10imageres = Search-File '*imageres10.dll.mun'
      Move-Item $win10imageres -Destination 'C:\Windows\SystemResources' -Force
      Rename-Item 'C:\Windows\SystemResources\imageres10.dll.mun' -NewName 'imageres.dll.mun' -Force
      #clear icon cache and restart explorer to apply
      taskkill /f /im explorer.exe
      Remove-Item -Path "$env:USERPROFILE\AppData\Local\Microsoft\Windows\Explorer\*iconcache_*" -Force
      Remove-Item -Path "$env:USERPROFILE\AppData\Local\Microsoft\Windows\Explorer\*thumbcache_*" -Force
      #restart explorer
      Start-Process explorer.exe

    }

    if ($checkbox21.Checked) {
      Write-Status -Message "Backing up Original Winver.exe > [$env:USERPROFILE\zBackup]" -Type Output
     
      takeown.exe /f 'C:\Windows\System32\winver.exe' *>$null
      icacls.exe 'C:\Windows\System32\winver.exe' /grant *S-1-5-32-544:F /T /C *>$null
      if (!(Test-Path "$env:USERPROFILE\zBackup")) {
        New-Item "$env:USERPROFILE\zBackup" -ItemType Directory | Out-Null
      }
      Copy-item 'C:\Windows\System32\winver.exe' -Destination "$env:USERPROFILE\zBackup" -Force
      Rename-Item "$env:USERPROFILE\zBackup\winver.exe" -NewName 'OGwinver.exe' -Force
      $Menu = $true
      do {
        $input = Read-Host "Choose 1 For Standard `nChoose 2 for Mono Theme" 
        if ($input -eq 1) {
          Write-Status -Message 'Replacing Winver...' -Type Output
        
          $stdpath = Search-file '*WinverStandard.exe'
          Remove-Item 'C:\Windows\System32\winver.exe' -Force
          Move-Item $stdpath -Destination 'C:\Windows\System32' -Force
          Rename-Item 'C:\Windows\System32\WinverStandard.exe' -NewName 'winver.exe' -Force
          $Menu = $false
        }
        elseif ($input -eq 2) {
          Write-Status -Message 'Replacing Winver...' -Type Output
       
          $monopath = Search-file '*WinverMono.exe'
          Remove-Item 'C:\Windows\System32\winver.exe' -Force
          Move-Item $monopath -Destination 'C:\Windows\System32' -Force
          Rename-Item 'C:\Windows\System32\WinverMono.exe' -NewName 'winver.exe' -Force
          $Menu = $false
        }
        else {
          Write-Host 'Invalid Input!' -ForegroundColor Red
        }
      }while ($Menu)
      
    }


    if ($checkbox22.Checked) {
      Write-Status -Message 'Removing Quick Settings Tiles...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer' /v 'SimplifyQuickSettings' /t REG_DWORD /d '1' /f
      $valueContent = try { Get-ItemPropertyValue 'HKCU:\Control Panel\Quick Actions\Control Center' -Name 'UserLayoutPaginated' }catch { $null }
      if (!$valueContent) {
        reg.exe add 'HKCU\Control Panel\Quick Actions\Control Center' /v 'UserLayoutPaginated' /t REG_SZ /d '[{\"Name\":\"Toggles\",\"QuickActions\":[]},{\"Name\":\"Sliders\",\"QuickActions\":[{\"FriendlyName\":\"Microsoft.QuickAction.Brightness\"},{\"FriendlyName\":\"Microsoft.QuickAction.VolumeNoTimer\"}]}]' /f
      }
      
      $disableTilesScript = @'
      $valueContent = Get-ItemPropertyValue 'HKCU:\Control Panel\Quick Actions\Control Center' -Name 'UserLayoutPaginated'
      $jsonobj = ConvertFrom-Json $valueContent 
      foreach ($group in $jsonobj) {
        if ($group.Name -eq 'Toggles' -and $group.PSObject.Properties.Name -contains 'QuickActions') {
          $group.QuickActions = @($group.QuickActions | Where-Object { $_ -notlike '*Microsoft.QuickAction.Accessibility*' })
        }
      }
      
      $newjson = $jsonobj | ConvertTo-Json -Depth 1
      Set-ItemProperty 'HKCU:\Control Panel\Quick Actions\Control Center' -Name 'UserLayoutPaginated' -Value $newjson
      Stop-Process -Name ShellHost
'@
      #run first and then make a task to run on boot since windows will reset this
      Invoke-Expression -Command $disableTilesScript >$null
      Write-Status -Message 'Creating Scheduled Task to Disable on Boot...' -Type Output
      
      New-Item "$env:programdata\DisableQuickSettingsTiles.ps1" -ItemType File -Force | Out-Null
      Set-Content "$env:programdata\DisableQuickSettingsTiles.ps1" -Value $disableTilesScript -Force | Out-Null
      #create silent script launcher
      New-Item "$env:programdata\DisableQuickSettingsTiles.vbs" -ItemType File -Force | Out-Null
      $vbsScript = @"
Dim shell,command
command = "powershell.exe -ep bypass -c ""$env:programdata\DisableQuickSettingsTiles.ps1"""
Set shell = CreateObject("WScript.Shell")
shell.Run command,0
"@
      Set-Content "$env:programdata\DisableQuickSettingsTiles.vbs" -Value $vbsScript -Force | Out-Null

      #get username and sid
      $currentUserName = $env:COMPUTERNAME + '\' + $env:USERNAME
      $username = Get-LocalUser -Name $env:USERNAME | Select-Object -ExpandProperty sid

      $content = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
<RegistrationInfo>
<Date>2024-05-20T12:59:50.8741407</Date>
<Author>$currentUserName</Author>
<URI>\DisableQuickSettingsTiles</URI>
</RegistrationInfo>
<Triggers>
<LogonTrigger>
<Enabled>true</Enabled>
</LogonTrigger>
</Triggers>
<Principals>
<Principal id="Author">
<UserId>$username</UserId>
<LogonType>InteractiveToken</LogonType>
<RunLevel>HighestAvailable</RunLevel>
</Principal>
</Principals>
<Settings>
<MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
<DisallowStartIfOnBatteries>true</DisallowStartIfOnBatteries>
<StopIfGoingOnBatteries>true</StopIfGoingOnBatteries>
<AllowHardTerminate>true</AllowHardTerminate>
<StartWhenAvailable>false</StartWhenAvailable>
<RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
<IdleSettings>
<StopOnIdleEnd>true</StopOnIdleEnd>
<RestartOnIdle>false</RestartOnIdle>
</IdleSettings>
<AllowStartOnDemand>true</AllowStartOnDemand>
<Enabled>true</Enabled>
<Hidden>false</Hidden>
<RunOnlyIfIdle>false</RunOnlyIfIdle>
<WakeToRun>false</WakeToRun>
<ExecutionTimeLimit>PT72H</ExecutionTimeLimit>
<Priority>7</Priority>
</Settings>
<Actions Context="Author">
<Exec>
<Command>wscript.exe</Command>
<Arguments>C:\ProgramData\DisableQuickSettingsTiles.vbs</Arguments>
</Exec>
</Actions>
</Task>
"@
      Set-Content -Path "$tempDir\DisableQuickSettings" -Value $content -Force

      schtasks /Create /XML "$tempDir\DisableQuickSettings" /TN '\DisableQuickSettingsTiles' /F | Out-Null 

      Remove-Item -Path "$tempDir\DisableQuickSettings" -Force -ErrorAction SilentlyContinue
      
    }


    if ($checkbox24.Checked) {
      Write-Status -Message 'Disabling Notepad Tabs and Rewrite...' -Type Output
      $settingsDat = "$env:LOCALAPPDATA\Packages\Microsoft.WindowsNotepad_8wekyb3d8bbwe\Settings\settings.dat"
      if (!(Test-Path $settingsDat)) {
        #create settings.dat file if notepad has never been opened
        $wshell = New-Object -ComObject WScript.Shell;
        $wshell.Run('notepad.exe', 0, $false) >$null
        Start-Sleep 3
        taskkill.exe /im notepad.exe /f *>$null
        Start-Sleep 1
      }

      $regContent = @'
Windows Registry Editor Version 5.00

[HKEY_USERS\TEMP\LocalState]
"OpenFile"=hex(5f5e104):01,00,00,00,d1,55,24,57,d1,84,db,01
"GhostFile"=hex(5f5e10b):00,42,60,f1,5a,d1,84,db,01
"RewriteEnabled"=hex(5f5e10b):00,12,4a,7f,5f,d1,84,db,01
"GenerateNewBadgeLifetime"=hex(5f5e105):00,00,00,00,4e,05,87,c4,dc,bb,dc,01 ; remove new badges from features
'@

      #load notepad settings to registry
      reg load HKU\TEMP $settingsDat >$null
      New-Item "$tempDir\DisableTabs.reg" -Value $regContent -Force | Out-Null
      regedit.exe /s "$tempDir\DisableTabs.reg"
      Start-Sleep 1
      reg unload HKU\TEMP >$null
      Remove-Item "$tempDir\DisableTabs.reg" -Force -ErrorAction SilentlyContinue


    }
      
          

    if ($checkbox26.Checked) {
      Write-Status -Message 'Hiding Ads and Useless Cards in Settings...' -Type Output
      #disable account ads by setting the default state for velocity ids

      $settingsJSON = (Get-ChildItem -Path "$env:windir\SystemApps" -Recurse).FullName | Where-Object { $_ -like '*wsxpacks\Account\SettingsExtensions.json' }

      #takeownership
      takeown /f $settingsJSON *>$null
      icacls $settingsJSON /grant *S-1-5-32-544:F /t *>$null

      $jsonContent = Get-Content $settingsJSON | ConvertFrom-Json
      $list = 'SubscriptionCard', 'SubscriptionCard_Enterprise', 'CopilotSubscriptionCard', 
      'CopilotSubscriptionCard_Enterprise', 'XboxSubscriptionCard', 'XboxSubscriptionCard_Enterprise',
      'SignedOutCard', 'SignedOutCard_SecondPlace', 'SignedOutCard_Enterprise_Local', 
      'SignedOutCard_Enterprise_AAD', 'SettingsPageGroupAccounts'

      $jsonContent.addedHomeCards = $jsonContent.addedHomeCards | Where-Object { $list -notcontains $_.cardId }
      $jsonContent.hiddenPages = $jsonContent.hiddenPages | ForEach-Object { 
        if ($_.pageGroupId -eq 'SettingsPageGroupAccounts' -and $_.conditions -and $_.conditions.velocityKey) { 
          $_.conditions.velocityKey.default = 'disabled'
        }
        $_ 
      }
      $jsonContent.addedPages = $jsonContent.addedPages | ForEach-Object { 
        if ($_.pageId -eq 'SettingsPageGroupAccounts_Home' -and $_.conditions -and $_.conditions.velocityKey) { 
          $_.conditions.velocityKey.default = 'disabled'
        }
        $_ 
      }

      $newContent = $jsonContent | ConvertTo-Json -Depth 100
      Set-Content -Path $settingsJSON -Value $newContent -Force

      #disable annoying "charms" in settings banner 
      $command = "Reg.exe add 'HKLM\SOFTWARE\Microsoft\WindowsRuntime\ActivatableClassId\ValueBanner.IdealStateFeatureControlProvider' /v ActivationType /t REG_DWORD /d 0 /f"
      Run-Trusted -command $command

      Reg.exe add 'HKLM\SOFTWARE\Policies\Microsoft\Windows\CloudContent' /v 'DisableConsumerAccountStateContent' /t REG_DWORD /d '1' /f *>$null
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\RulesEngine\StateManager' /v 'LastSuppressionTimes' /t REG_SZ /d '{\"settingshomealertbanner\":\"2099-01-01T00:00:00Z\",\"startmenu\":\"2099-01-01T00:00:00Z\"}' /f *>$null
    }


   


    if ($checkbox28.Checked) {
      Write-Status -Message 'Enabling Small Taskbar Icons...' -Type Output
      Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' /v 'IconSizePreference' /t REG_DWORD /d '0' /f >$null
    }

    if ($checkbox29.Checked) {
      Write-Status -Message 'Setting Background Mouse Throttle to 50hz...' -Type Output
      reg.exe add 'HKCU\Control Panel\Mouse' /v 'RawMouseThrottleEnabled' /t REG_DWORD /d '1' /f >$null
      reg.exe add 'HKCU\Control Panel\Mouse' /v 'RawMouseThrottleDuration' /t REG_DWORD /d '20' /f >$null
    }

    if ($checkbox30.Checked) {
      Write-Status -Message 'Enabling New Start Menu (25h2)...' -Type Output
      $key = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows NT\CurrentVersion')
      $OSBuild = "$($key.GetValue('CurrentBuild')).$($key.GetValue('UBR'))"
      $key.Close()
      try {
        Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoStartMenuMorePrograms' -ErrorAction Stop
        $missingNewKey = $false
      }
      catch {
        $missingNewKey = $true
      }
      if ([version]$OSBuild -lt ([version]'26200.8037') -or $missingNewKey) {
        Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\FeatureManagement\Overrides\14\3036241548' /v 'EnabledState' /t REG_DWORD /d '2' /f >$null
        Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\FeatureManagement\Overrides\14\2792562829' /v 'EnabledState' /t REG_DWORD /d '2' /f >$null
        Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\FeatureManagement\Overrides\14\762256525' /v 'EnabledState' /t REG_DWORD /d '2' /f >$null
        Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\FeatureManagement\Overrides\14\734731404' /v 'EnabledState' /t REG_DWORD /d '2' /f >$null
      }
      else {
        Reg.exe delete 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' /v 'NoStartMenuMorePrograms' /f
      }
    }

    if ($checkbox31.Checked) {
      Write-Status -Message 'Reverting New Start Menu...' -Type Output
      $key = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows NT\CurrentVersion')
      $OSBuild = "$($key.GetValue('CurrentBuild')).$($key.GetValue('UBR'))"
      $key.Close()
      
      if ([version]$OSBuild -lt ([version]'26200.8037')) {
        Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\FeatureManagement\Overrides\14\3036241548' /v 'EnabledState' /t REG_DWORD /d '0' /f >$null
        Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\FeatureManagement\Overrides\14\2792562829' /v 'EnabledState' /t REG_DWORD /d '0' /f >$null
        Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\FeatureManagement\Overrides\14\762256525' /v 'EnabledState' /t REG_DWORD /d '0' /f >$null
        Reg.exe add 'HKLM\SYSTEM\ControlSet001\Control\FeatureManagement\Overrides\14\734731404' /v 'EnabledState' /t REG_DWORD /d '0' /f >$null
      }
      else {
        Reg.exe add 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' /v 'NoStartMenuMorePrograms' /t REG_DWORD /d '1' /f
      }
      
    }

    if ($checkbox20.Checked) {
      Write-Status -Message 'Enabling Windows 10 Sounds...' -Type Output
      
      if (!(Test-Path "$env:USERPROFILE\zBackup")) {
        New-Item "$env:USERPROFILE\zBackup" -ItemType Directory | Out-Null
      }
      $soundBackup = "$env:USERPROFILE\zBackup\Windows11Sounds"
      if (!(Test-Path $soundBackup)) {
        Write-Status -Message 'Backing up Windows 11 Sounds...' -Type Output
        New-Item $soundBackup -ItemType Directory | Out-Null
        $win11sounds = Get-ChildItem -Path C:\Windows\Media -Recurse -Filter 'Windows*' | ForEach-Object { $_.FullName }
        foreach ($sound in $win11sounds) {
          Copy-Item -Path $sound -Destination $soundBackup -Force
        }
      }
      
      $path = Search-Directory -filter '*win10sounds'
      $command = "`$sounds = Get-ChildItem -Path `"$path`" -Recurse -Force | ForEach-Object { `$_.FullName }; foreach(`$sound in `$sounds){Move-item `$sound -destination C:\Windows\Media -force}"
      Run-Trusted -command $command
    }


  }
}
Export-ModuleMember -Function W11Tweaks  
      
  
function UltimateCleanup {

  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  [System.Windows.Forms.Application]::EnableVisualStyles()

  # Create the form
  $form = New-Object System.Windows.Forms.Form
  $form.Text = 'Ultimate Cleanup'
  $form.Size = New-Object System.Drawing.Size(530, 420)
  $form.StartPosition = 'CenterScreen'
  $form.BackColor = 'Black'
  $form.Font = New-Object System.Drawing.Font('Segoe UI', 8)

  $type = $form.GetType()
  $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
  $propInfo.SetValue($form, $true, $null)

  $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
  $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

  # Override the form's paint event to apply the gradient
  $form.Add_Paint({
      param($sender, $e)
      $rect = New-Object System.Drawing.Rectangle(0, 0, $form.Width, $form.Height)
      $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        $rect, 
        $startColor, 
        $endColor, 
        [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
      )
      $e.Graphics.FillRectangle($brush, $rect)
      $brush.Dispose()
    })

  $label = New-Object System.Windows.Forms.Label
  $label.Location = New-Object System.Drawing.Point(10, 10)
  $label.Size = New-Object System.Drawing.Size(250, 24)
  $label.Text = 'Disk Cleanup Options:'
  $label.ForeColor = 'White'
  $label.BackColor = [System.Drawing.Color]::Transparent
  $label.Font = New-Object System.Drawing.Font('Segoe UI', 10) 
  $form.Controls.Add($label)


  $label = New-Object System.Windows.Forms.Label
  $label.Location = New-Object System.Drawing.Point(270, 10)
  $label.Size = New-Object System.Drawing.Size(250, 24)
  $label.Text = 'Additional Options:'
  $label.ForeColor = 'White'
  $label.BackColor = [System.Drawing.Color]::Transparent
  $label.Font = New-Object System.Drawing.Font('Segoe UI', 10) 
  $form.Controls.Add($label)

  $lineStartPoint = New-Object System.Drawing.Point(10, 34)
  $lineEndPoint = New-Object System.Drawing.Point(250, 34)
  $lineColor = [System.Drawing.Color]::Gray
  $lineWidth = 1.5

  $form.Add_Paint({
      $graphics = $form.CreateGraphics()
      $pen = New-Object System.Drawing.Pen($lineColor, $lineWidth)
      $graphics.DrawLine($pen, $lineStartPoint, $lineEndPoint)
      $pen.Dispose()
      $graphics.Dispose()
    })


  $lineStartPoint2 = New-Object System.Drawing.Point(270, 34)
  $lineEndPoint2 = New-Object System.Drawing.Point(450, 34)
  $lineColor2 = [System.Drawing.Color]::Gray
  $lineWidth2 = 1.5

  $form.Add_Paint({
      $graphics = $form.CreateGraphics()
      $pen = New-Object System.Drawing.Pen($lineColor2, $lineWidth2)
      $graphics.DrawLine($pen, $lineStartPoint2, $lineEndPoint2)
      $pen.Dispose()
      $graphics.Dispose()
    })

  # Create the CheckedListBox
  $checkedListBox = New-Object System.Windows.Forms.CheckedListBox
  $checkedListBox.Location = New-Object System.Drawing.Point(10, 50)
  $checkedListBox.Size = New-Object System.Drawing.Size(250, 300)
  $checkedListBox.CheckOnClick = $true
  $checkedListBox.BackColor = 'Black'
  $checkedListBox.ForeColor = 'White'
  $options = @(
    'Active Setup Temp Folders'
    'Thumbnail Cache'
    'Delivery Optimization Files'
    'D3D Shader Cache'
    'Downloaded Program Files'
    'Internet Cache Files'
    'Setup Log Files'
    'Temporary Files'
    'Windows Error Reporting Files'
    'Offline Pages Files'
    'Recycle Bin'
    'Temporary Setup Files'
    'Update Cleanup'
    'Upgrade Discarded Files'
    'Windows Defender'
    'Windows ESD installation files'
    'Windows Reset Log Files'
    'Windows Upgrade Log Files'
    'Previous Installations'
    'Old ChkDsk Files'
    'Feedback Hub Archive log files'
    'Diagnostic Data Viewer database files'
    'Device Driver Packages'
  )
  foreach ($option in $options) {
    $checkedListBox.Items.Add($option, $false) | Out-Null
  }

  # Create the checkboxes
  $checkBox1 = New-Object System.Windows.Forms.CheckBox
  $checkBox1.Text = 'Clear Event Viewer Logs'
  $checkBox1.Location = New-Object System.Drawing.Point(270, 50)
  $checkBox1.ForeColor = 'White'
  $checkBox1.BackColor = [System.Drawing.Color]::Transparent
  $checkBox1.AutoSize = $true

  $checkBox2 = New-Object System.Windows.Forms.CheckBox
  $checkBox2.Text = 'Clear Windows Logs'
  $checkBox2.Location = New-Object System.Drawing.Point(270, 80)
  $checkBox2.ForeColor = 'White'
  $checkBox2.BackColor = [System.Drawing.Color]::Transparent
  $checkBox2.AutoSize = $true

  $checkBox3 = New-Object System.Windows.Forms.CheckBox
  $checkBox3.Text = 'Clear TEMP Cache'
  $checkBox3.Location = New-Object System.Drawing.Point(270, 110)
  $checkBox3.ForeColor = 'White'
  $checkBox3.BackColor = [System.Drawing.Color]::Transparent
  $checkBox3.AutoSize = $true

  $checkBox4 = New-Object System.Windows.Forms.CheckBox
  $checkBox4.Text = 'Clean Nvidia Driver Shader Cache'
  $checkBox4.Location = New-Object System.Drawing.Point(270, 140)
  $checkBox4.ForeColor = 'White'
  $checkBox4.BackColor = [System.Drawing.Color]::Transparent
  $checkBox4.AutoSize = $true
  $form.Controls.Add($checkBox4)

  $checkBox5 = New-Object System.Windows.Forms.CheckBox
  $checkBox5.Text = 'Remove Windows.old Folder'
  $checkBox5.Location = New-Object System.Drawing.Point(270, 170)
  $checkBox5.ForeColor = 'White'
  $checkBox5.BackColor = [System.Drawing.Color]::Transparent
  $checkBox5.AutoSize = $true
  $form.Controls.Add($checkBox5)

  $checkBox6 = New-Object System.Windows.Forms.CheckBox
  $checkBox6.Text = 'Remove Old Duplicate Drivers'
  $checkBox6.Location = New-Object System.Drawing.Point(270, 200)
  $checkBox6.ForeColor = 'White'
  $checkBox6.BackColor = [System.Drawing.Color]::Transparent
  $checkBox6.AutoSize = $true
  $form.Controls.Add($checkBox6)

  # Create the Clean button
  $buttonclean = Create-ModernButton -Text 'Clean' -Location (New-Object Drawing.Point(330, 310)) -Size (New-Object Drawing.Size(100, 30)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2
  <#
  $buttonClean = New-Object System.Windows.Forms.Button
  $buttonClean.Text = 'Clean'
  $buttonClean.Location = New-Object System.Drawing.Point(330, 310)
  $buttonClean.Size = New-Object System.Drawing.Size(100, 30)
  $buttonClean.ForeColor = 'White'
  $buttonClean.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
  $buttonClean.DialogResult = [System.Windows.Forms.DialogResult]::OK
  $buttonClean.Add_MouseEnter({
      $buttonClean.BackColor = [System.Drawing.Color]::FromArgb(64, 64, 64)
    })

  $buttonClean.Add_MouseLeave({
      $buttonClean.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
    })
    #>
  
  $checkALL = New-Object System.Windows.Forms.CheckBox
  $checkALL.Text = 'Check All'
  $checkALL.Location = New-Object System.Drawing.Point(10, 345)
  $checkALL.ForeColor = 'White'
  $checkALL.BackColor = [System.Drawing.Color]::Transparent
  $checkALL.AutoSize = $true
  $checkALL.add_CheckedChanged({
      if ($checkALL.Checked) {
        $i = 0
        foreach ($option in $options) {
          $checkedListBox.SetItemChecked($i, $true)
          $i++
        }
      }
      else {
        $i = 0
        foreach ($option in $options) {
          $checkedListBox.SetItemChecked($i, $false)
          $i++
        }
      }
    })
  $form.Controls.Add($checkALL)
  
  # Add controls to the form
  $form.Controls.Add($checkedListBox)
  $form.Controls.Add($checkBox1)
  $form.Controls.Add($checkBox2)
  $form.Controls.Add($checkBox3)
  $form.Controls.Add($buttonClean)

  # Show the form
  $result = $form.ShowDialog()


  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    $driveletter = $env:SystemDrive -replace ':', ''
    $drive = Get-PSDrive $driveletter
    $usedInGB = [math]::Round($drive.Used / 1GB, 4)
    Write-Host 'BEFORE CLEANING' -ForegroundColor Red 
    Write-Host "Used space on $($drive.Name):\ $usedInGB GB" -ForegroundColor Red
    


    if ($checkBox1.Checked) {
      Write-Status -Message 'Clearing Event Viewer Logs...' -Type Output
      
      wevtutil el | Foreach-Object { wevtutil cl "$_" >$null 2>&1 } 
    }
    if ($checkBox2.Checked) {
      #CLEAR LOGS
      Write-Status -Message 'Clearing Windows Log Files...' -Type Output
      
      #Clear Distributed Transaction Coordinator logs
      Remove-Item -Path $env:SystemRoot\DtcInstall.log -Force -ErrorAction SilentlyContinue 
      #Clear Optional Component Manager and COM+ components logs
      Remove-Item -Path $env:SystemRoot\comsetup.log -Force -ErrorAction SilentlyContinue 
      #Clear Pending File Rename Operations logs
      Remove-Item -Path $env:SystemRoot\PFRO.log -Force -ErrorAction SilentlyContinue 
      #Clear Windows Deployment Upgrade Process Logs
      Remove-Item -Path $env:SystemRoot\setupact.log -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\setuperr.log -Force -ErrorAction SilentlyContinue 
      #Clear Windows Setup Logs
      Remove-Item -Path $env:SystemRoot\setupapi.log -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\Panther\* -Force -Recurse -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\inf\setupapi.app.log -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\inf\setupapi.dev.log -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\inf\setupapi.offline.log -Force -ErrorAction SilentlyContinue 
      #Clear Windows System Assessment Tool logs
      Remove-Item -Path $env:SystemRoot\Performance\WinSAT\winsat.log -Force -ErrorAction SilentlyContinue 
      #Clear Password change events
      Remove-Item -Path $env:SystemRoot\debug\PASSWD.LOG -Force -ErrorAction SilentlyContinue 
      #Clear DISM (Deployment Image Servicing and Management) Logs
      Remove-Item -Path $env:SystemRoot\Logs\CBS\CBS.log -Force -ErrorAction SilentlyContinue  
      Remove-Item -Path $env:SystemRoot\Logs\DISM\DISM.log -Force -ErrorAction SilentlyContinue  
      #Clear Server-initiated Healing Events Logs
      Remove-Item -Path "$env:SystemRoot\Logs\SIH\*" -Force -ErrorAction SilentlyContinue 
      #Common Language Runtime Logs
      Remove-Item -Path "$env:LocalAppData\Microsoft\CLR_v4.0\UsageTraces\*" -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path "$env:LocalAppData\Microsoft\CLR_v4.0_32\UsageTraces\*" -Force -ErrorAction SilentlyContinue 
      #Network Setup Service Events Logs
      Remove-Item -Path "$env:SystemRoot\Logs\NetSetup\*" -Force -ErrorAction SilentlyContinue 
      #Disk Cleanup tool (Cleanmgr.exe) Logs
      Remove-Item -Path "$env:SystemRoot\System32\LogFiles\setupcln\*" -Force -ErrorAction SilentlyContinue 
      #Clear Windows update and SFC scan logs
      Remove-Item -Path $env:SystemRoot\Temp\CBS\* -Force -ErrorAction SilentlyContinue 
      #Clear Windows Update Medic Service logs
      takeown /f $env:SystemRoot\Logs\waasmedic /r -Value y *>$null
      icacls $env:SystemRoot\Logs\waasmedic /grant *S-1-5-32-544:F /t *>$null
      Remove-Item -Path $env:SystemRoot\Logs\waasmedic -Recurse -ErrorAction SilentlyContinue 
      #Clear Cryptographic Services Traces
      Remove-Item -Path $env:SystemRoot\System32\catroot2\dberr.txt -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\System32\catroot2.log -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\System32\catroot2.jrs -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\System32\catroot2.edb -Force -ErrorAction SilentlyContinue 
      Remove-Item -Path $env:SystemRoot\System32\catroot2.chk -Force -ErrorAction SilentlyContinue 
      #Windows Update Logs
      Remove-Item -Path "$env:SystemRoot\Traces\WindowsUpdate\*" -Force -ErrorAction SilentlyContinue 
    }
    if ($checkBox3.Checked) {
      Write-Status -Message 'Clearing TEMP Files...' -Type Output
   
      #cleanup temp files
      $temp1 = 'C:\Windows\Temp'
      $temp2 = $tempDir
      $tempFiles = (Get-ChildItem -Path $temp1 , $temp2 -Recurse -Force).FullName
      foreach ($file in $tempFiles) {
        Remove-Item -Path $file -Recurse -Force -ErrorAction SilentlyContinue
      }
    }

    if ($checkBox4.Checked) {
      Write-Status -Message 'Cleaning DX and GL Cache...' -Type Output
      Remove-Item -Path "$env:LocalAppData\NVIDIA\GLCache" -Recurse -Force -ErrorAction SilentlyContinue
      Remove-Item -Path "$env:USERPROFILE\AppData\LocalLow\NVIDIA\PerDriverVersion\DXCache" -Recurse -Force -ErrorAction SilentlyContinue
      
    }

    if ($checkBox5.Checked) {
      Write-Status -Message 'Removing Windows.old Folder...' -Type Output
      #use multiple methods to remove folder
      $command = "Get-ChildItem `"$env:SystemDrive\Windows.old`" -Recurse | Remove-Item -Force -Recurse"
      Run-Trusted -command $command
      Start-Sleep 1
      $command = "Remove-Item `"$env:SystemDrive\Windows.old`" -Recurse -Force"
      Run-Trusted -command $command
      Write-Status -Message 'Taking Ownership...This may take a moment' -Type Output
      takeown /f "$env:SystemDrive\Windows.old" /r /d Y *>$null
      icacls "$env:SystemDrive\Windows.old" /grant *S-1-5-32-544:F /t *>$null
      cmd.exe /c rmdir /S /Q "$env:SystemDrive\Windows.old" *>$null
    }

    if ($checkBox6.Checked) {
      Write-Status -Message 'Searching For Old Duplicate Drivers...' -Type Output
      # Use this PowerShell script to find and remove old and unused device drivers from the Windows Driver Store
      # Explanation: http://woshub.com/how-to-remove-unused-drivers-from-driver-store/

      $dismOut = dism /online /get-drivers
      $Lines = $dismOut | Select-Object -Skip 10
      $Operation = 'theName'
      $Drivers = @()
      foreach ( $Line in $Lines ) {
        if ($line -ne 'The operation completed successfully.') {
          $tmp = $Line
          $txt = $($tmp.Split( ':' ))[1]
          switch ($Operation) {
            'theName' {
              $Name = $txt
              $Operation = 'theFileName'
              break
            }
            'theFileName' {
              $FileName = $txt.Trim()
              $Operation = 'theEntr'
              break
            }
            'theEntr' {
              $Entr = $txt.Trim()
              $Operation = 'theClassName'
              break
            }
            'theClassName' {
              $ClassName = $txt.Trim()
              $Operation = 'theVendor'
              break
            }
            'theVendor' {
              $Vendor = $txt.Trim()
              $Operation = 'theDate'
              break
            }
            'theDate' {
              # we'll change the default date format for easy sorting
              $tmp = $txt.split( '.' )
              $txt = "$($tmp[2]).$($tmp[1]).$($tmp[0].Trim())"
              $Date = $txt
              $Operation = 'theVersion'
              break
            }
            'theVersion' {
              $Version = $txt.Trim()
              $Operation = 'theNull'
              $params = [ordered]@{ 'FileName' = $FileName
                'Vendor'                       = $Vendor
                'Date'                         = $Date
                'Name'                         = $Name
                'ClassName'                    = $ClassName
                'Version'                      = $Version
                'Entr'                         = $Entr
              }
              $obj = New-Object -TypeName PSObject -Property $params
              $Drivers += $obj
              break
            }
            'theNull' {
              $Operation = 'theName'
              break
            }
          }
        }
      }
      $last = ''
      $NotUnique = @()
      foreach ( $Dr in $($Drivers | Sort-Object Filename) ) {
        if ($Dr.FileName -eq $last  ) { $NotUnique += $Dr }
        $last = $Dr.FileName
      }
      $NotUnique | Sort-Object FileName | Format-Table
      # search for duplicate drivers 
      $list = $NotUnique | Select-Object -ExpandProperty FileName -Unique
      $ToDel = @()
      foreach ( $Dr in $list ) {
        #  Write-Host 'duplicate driver found' -ForegroundColor Yellow
        $sel = $Drivers | Where-Object { $_.FileName -eq $Dr } | Sort-Object date -Descending | Select-Object -Skip 1
        #  $sel | Format-Table
        $ToDel += $sel
      }
      # Write-Host 'List of driver version  to remove' -ForegroundColor Red
      #  $ToDel | Format-Table
      # Removing old driver versions
      if ($ToDel.Count -gt 0) {
        Write-Status -Message "Removing $($ToDel.Count) Duplicate Drivers..." -Type Output
        foreach ( $item in $ToDel ) {
          $Name = $($item.Name).Trim()
          # Write-Host "deleting $Name" -ForegroundColor Yellow
          # Write-Host "pnputil.exe /remove-device  $Name" -ForegroundColor Yellow
          Invoke-Expression -Command "pnputil.exe /remove-device $Name"
        }
      }
      else {
        Write-Status -Message 'No Duplicate Drivers Found!' -Type Output
      }
    }

    if ($checkedListBox.CheckedItems) {
      $key = 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches'
      foreach ($item in $checkedListBox.CheckedItems) {
        reg.exe add "$key\$item" /v StateFlags0069 /t REG_DWORD /d 00000002 /f >$nul 2>&1
      }
      Write-Status -Message 'Running Disk Cleanup...' -Type Output
    
      #credits to @instead1337 for monitoring logic
      $timeout = 300
      $cleanupProcess = Start-Process cleanmgr.exe -ArgumentList '/sagerun:69' -Wait:$false -PassThru
      $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
      $lastCpuUsage = 0
      $lastMemoryUsage = 0

      while ($cleanupProcess -and !$cleanupProcess.HasExited -and $stopwatch.Elapsed.TotalSeconds -lt $timeout) {
        Start-Sleep -Seconds 10
        $process = Get-Process -Id $cleanupProcess.Id -EA SilentlyContinue
        if ($process) {
          $cpuUsage = $process.CPU
          $memoryUsage = $process.WS
          if ($cpuUsage -eq $lastCpuUsage -and $memoryUsage -eq $lastMemoryUsage) {
            Write-Status -Message 'Disk Cleanup Is Most Likely Frozen...' -Type Output
            Write-Status -Message 'Closing Disk Cleanup Window...' -Type Output
            if ($cleanupProcess.MainWindowHandle) {
              $cleanupProcess.CloseMainWindow() | Out-Null
              Start-Sleep -Seconds 5
              if (!$cleanupProcess.HasExited) { $cleanupProcess | Stop-Process -EA SilentlyContinue }
            }
            else {
              $cleanupProcess | Stop-Process -EA SilentlyContinue
            }
          }
          $lastCpuUsage = $cpuUsage
          $lastMemoryUsage = $memoryUsage
        }
        
      }

      
    }

    $drive = Get-PSDrive $driveletter
    $usedInGB = [math]::Round($drive.Used / 1GB, 4)
    Write-Host 'AFTER CLEANING' -ForegroundColor Green
    Write-Host "Used space on $($drive.Name):\ $usedInGB GB" -ForegroundColor Green
    
  }

  
}
Export-ModuleMember -Function UltimateCleanup



function Run-Trusted([String]$command) {

  try {
    Stop-Service -Name TrustedInstaller -Force -ErrorAction Stop -WarningAction Stop
  }
  catch {
    taskkill /im trustedinstaller.exe /f >$null
  }
  #get bin path to revert later
  $service = Get-CimInstance -ClassName Win32_Service -Filter "Name='TrustedInstaller'"
  $DefaultBinPath = $service.PathName
  #make sure path is valid and the correct location
  $trustedInstallerPath = "$env:SystemRoot\servicing\TrustedInstaller.exe"
  if ($DefaultBinPath -ne $trustedInstallerPath) {
    $DefaultBinPath = $trustedInstallerPath
  }
  #convert command to base64 to avoid errors with spaces
  $bytes = [System.Text.Encoding]::Unicode.GetBytes($command)
  $base64Command = [Convert]::ToBase64String($bytes)
  #change bin to command
  sc.exe config TrustedInstaller binPath= "cmd.exe /c powershell.exe -encodedcommand $base64Command" | Out-Null
  #run the command
  sc.exe start TrustedInstaller | Out-Null
  #set bin back to default
  sc.exe config TrustedInstaller binpath= "`"$DefaultBinPath`"" | Out-Null
  try {
    Stop-Service -Name TrustedInstaller -Force -ErrorAction Stop -WarningAction Stop
  }
  catch {
    taskkill /im trustedinstaller.exe /f >$null
  }
  
}
Export-ModuleMember -Function Run-Trusted





# -------------- splitting up get-childitem to search for files and folders individually turns out to be the fastest way to search for files 
# -------------- removed dotnet file searching too slow in most cases because of recursion required
      
function Search-File($filter) {
  $roots = @($folder, $sysDrive) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
  if (-not $roots) { return $null }

  return (Get-ChildItem -Path $roots -Filter $filter -Recurse -File -ErrorAction SilentlyContinue -Force | Where-Object Name -NotIn '$Recycle.Bin' | Select-Object -First 1).FullName
}
Export-ModuleMember -Function Search-File
      
      

function Search-Directory($filter) {
  $roots = @($folder, $sysDrive) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
  if (-not $roots) { return $null }

  return (Get-ChildItem -Path $roots -Filter $filter -Recurse -Directory -ErrorAction SilentlyContinue -Force | Where-Object Name -NotIn '$Recycle.Bin' | Select-Object -First 1).FullName
}
Export-ModuleMember -Function Search-Directory   


 

function Custom-MsgBox {
  param(
    [string]$message,
    [ValidateSet('Question', 'Warning', 'None')]
    [string]$type
  )
  Add-Type -AssemblyName System.Windows.Forms

  # Enable visual styles
  [System.Windows.Forms.Application]::EnableVisualStyles()

  # Create the form
  $form = New-Object System.Windows.Forms.Form
  $form.Text = 'mpware'
  if ($type -eq 'None') {
    $form.Size = New-Object System.Drawing.Size(280, 180)
  }
  else {
    $form.Size = New-Object System.Drawing.Size(370, 200)
  }
  $form.StartPosition = 'CenterScreen'
  $form.BackColor = [System.Drawing.Color]::Black
  $form.ForeColor = [System.Drawing.Color]::White
  $form.Font = New-Object System.Drawing.Font('Segoe UI', 8)

  # Add Icon
  $pictureBox = New-Object System.Windows.Forms.PictureBox
  $pictureBox.Location = New-Object System.Drawing.Point(20, 30) 
  $pictureBox.Size = New-Object System.Drawing.Size(50, 50) 
  $pictureBox.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
  if ($type -eq 'Warning') {
    $imagePath = 'C:\Windows\System32\SecurityAndMaintenance_Alert.png'
  }
  $pictureBox.Visible = $false
  $form.Controls.Add($pictureBox)

  # Create the label
  $label = New-Object System.Windows.Forms.Label
  $label.Text = $message
  if ($type -eq 'None') {
    $label.Size = New-Object System.Drawing.Size(200, 60)
  }
  else {
    $label.Size = New-Object System.Drawing.Size(250, 80)
  }
  $label.Location = New-Object System.Drawing.Point(90, 40)
  if ($message -like '*Restart PC?') {
    $label.Font = New-Object System.Drawing.Font('Segoe UI', 10)
  }
  $label.ForeColor = [System.Drawing.Color]::White
  $form.Controls.Add($label)

  $ribbonPanel = New-Object System.Windows.Forms.Panel
  $ribbonPanel.Dock = [System.Windows.Forms.DockStyle]::Bottom
  $ribbonPanel.Height = 40
  $ribbonPanel.BackColor = [System.Drawing.Color]::FromArgb(35, 35, 35)  
  $form.Controls.Add($ribbonPanel)


  # Create the OK button
  $okButton = New-Object System.Windows.Forms.Button
  if ($type -eq 'Question') {
    $okButton.Text = 'Yes'
  }
  else {
    $okButton.Text = 'OK'
  }
  if ($type -eq 'None') {
    $okButton.Location = New-Object System.Drawing.Point((($ribbonPanel.Width / 2) + 40), 8)
  }
  else {
    $okButton.Location = New-Object System.Drawing.Point(($ribbonPanel.Width / 2), 8)
  }
  $okButton.BackColor = 'Black'
  $okButton.Size = New-Object System.Drawing.Size(75, 25)
  $okButton.ForeColor = [System.Drawing.Color]::White
  $oKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
  $ribbonPanel.Controls.Add($okButton)

  if (!($type -eq 'None')) {
    # Create the Cancel button
    $cancelButton = New-Object System.Windows.Forms.Button
    if ($type -eq 'Question') {
      $cancelButton.Text = 'No'
    }
    else {
      $cancelButton.Text = 'Cancel'
    }
    $cancelButton.Location = New-Object System.Drawing.Point((($ribbonPanel.Width / 2) + 85), 8)
    $cancelButton.Size = New-Object System.Drawing.Size(75, 25)
    $cancelButton.BackColor = 'Black'
    $cancelButton.ForeColor = [System.Drawing.Color]::White
    $cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $ribbonPanel.Controls.Add($cancelButton)

  }
   
  # Show the form
  $result = $form.ShowDialog()

  return $result
}
Export-ModuleMember -Function Custom-MsgBox


function Check-Internet {
  $noInternet = $false
  $testUrls = @(
    'https://www.google.com',
    'https://www.microsoft.com',
    'https://www.cloudflare.com'
  )

  foreach ($url in $testUrls) {
    try {
      Invoke-WebRequest -Uri $url -Method Head -DisableKeepAlive -UseBasicParsing -ErrorAction Stop | Out-Null
      $noInternet = $false
      break  
    }
    catch [System.Net.WebException] {
      $noInternet = $true
    }
  }

  if ($noInternet) {
    Write-Status -Message 'This Tweak Requires Internet Connection...' -Type Error
    return 1
  }
  else {
    return 0
  }

}
Export-ModuleMember -Function Check-Internet


function Get-FileFromWeb {
  param (
    # Parameter help description
    [Parameter(Mandatory)]
    [string]$URL,
  
    # Parameter help description
    [Parameter(Mandatory)]
    [string]$File 
  )
  Begin {
    function Show-Progress {
      param (
        # Enter total value
        [Parameter(Mandatory)]
        [Single]$TotalValue,
        
        # Enter current value
        [Parameter(Mandatory)]
        [Single]$CurrentValue,
        
        # Enter custom progresstext
        [Parameter(Mandatory)]
        [string]$ProgressText,
        
        # Enter value suffix
        [Parameter()]
        [string]$ValueSuffix,
        
        # Enter bar lengh suffix
        [Parameter()]
        [int]$BarSize = 40,

        # show complete bar
        [Parameter()]
        [switch]$Complete
      )
            
      # calc %
      $percent = $CurrentValue / $TotalValue
      $percentComplete = $percent * 100
      if ($ValueSuffix) {
        $ValueSuffix = " $ValueSuffix" # add space in front
      }
      if ($psISE) {
        Write-Progress "$ProgressText $CurrentValue$ValueSuffix of $TotalValue$ValueSuffix" -id 0 -percentComplete $percentComplete            
      }
      else {
        # build progressbar with string function
        $curBarSize = $BarSize * $percent
        $progbar = ''
        $progbar = $progbar.PadRight($curBarSize, [char]9608)
        $progbar = $progbar.PadRight($BarSize, [char]9617)
        
        if (!$Complete.IsPresent) {
          Write-Host -NoNewLine "`r$ProgressText $progbar [ $($CurrentValue.ToString('#.###').PadLeft($TotalValue.ToString('#.###').Length))$ValueSuffix / $($TotalValue.ToString('#.###'))$ValueSuffix ] $($percentComplete.ToString('##0.00').PadLeft(6)) % complete"
        }
        else {
          Write-Host -NoNewLine "`r$ProgressText $progbar [ $($TotalValue.ToString('#.###').PadLeft($TotalValue.ToString('#.###').Length))$ValueSuffix / $($TotalValue.ToString('#.###'))$ValueSuffix ] $($percentComplete.ToString('##0.00').PadLeft(6)) % complete"                    
        }                
      }   
    }
  }
  Process {
    try {
      $storeEAP = $ErrorActionPreference
      $ErrorActionPreference = 'Stop'
        
      # invoke request
      $request = [System.Net.HttpWebRequest]::Create($URL)
      $response = $request.GetResponse()
  
      if ($response.StatusCode -eq 401 -or $response.StatusCode -eq 403 -or $response.StatusCode -eq 404) {
        throw "Remote file either doesn't exist, is unauthorized, or is forbidden for '$URL'."
      }
  
      if ($File -match '^\.\\') {
        $File = Join-Path (Get-Location -PSProvider 'FileSystem') ($File -Split '^\.')[1]
      }
            
      if ($File -and !(Split-Path $File)) {
        $File = Join-Path (Get-Location -PSProvider 'FileSystem') $File
      }

      if ($File) {
        $fileDirectory = $([System.IO.Path]::GetDirectoryName($File))
        if (!(Test-Path($fileDirectory))) {
          [System.IO.Directory]::CreateDirectory($fileDirectory) | Out-Null
        }
      }

      [long]$fullSize = $response.ContentLength
      $fullSizeMB = $fullSize / 1024 / 1024
  
      # define buffer
      [byte[]]$buffer = new-object byte[] 1048576
      [long]$total = [long]$count = 0
  
      # create reader / writer
      $reader = $response.GetResponseStream()
      $writer = new-object System.IO.FileStream $File, 'Create'
  
      # start download
      $finalBarCount = 0 #show final bar only one time
      do {
          
        $count = $reader.Read($buffer, 0, $buffer.Length)
          
        $writer.Write($buffer, 0, $count)
              
        $total += $count
        $totalMB = $total / 1024 / 1024
          
        if ($fullSize -gt 0) {
          Show-Progress -TotalValue $fullSizeMB -CurrentValue $totalMB -ProgressText "Downloading $($File.Name)" -ValueSuffix 'MB'
        }

        if ($total -eq $fullSize -and $count -eq 0 -and $finalBarCount -eq 0) {
          Show-Progress -TotalValue $fullSizeMB -CurrentValue $totalMB -ProgressText "Downloading $($File.Name)" -ValueSuffix 'MB' -Complete
          $finalBarCount++
        }

      } while ($count -gt 0)
    }
  
    catch {
        
      $ExeptionMsg = $_.Exception.Message
      Write-Host "Download breaks with error : $ExeptionMsg"
    }
  
    finally {
      # cleanup
      if ($reader) { $reader.Close() }
      if ($writer) { $writer.Flush(); $writer.Close() }
        
      $ErrorActionPreference = $storeEAP
      [GC]::Collect()
    }    
  }
}

Export-ModuleMember -Function Get-FileFromWeb

function Install-Browsers {
  

  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.Application]::EnableVisualStyles()

  $form = New-Object System.Windows.Forms.Form
  $form.Text = 'Browser Installer'
  $form.Size = New-Object System.Drawing.Size(300, 200)
  $form.StartPosition = 'CenterScreen'
  $form.BackColor = [System.Drawing.Color]::Black

  $type = $form.GetType()
  $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
  $propInfo.SetValue($form, $true, $null)

  $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
  $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

  # Override the form's paint event to apply the gradient
  $form.Add_Paint({
      param($sender, $e)
      $rect = New-Object System.Drawing.Rectangle(0, 0, $form.Width, $form.Height)
      $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        $rect, 
        $startColor, 
        $endColor, 
        [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
      )
      $e.Graphics.FillRectangle($brush, $rect)
      $brush.Dispose()
    })

  $chromeRadio = New-Object System.Windows.Forms.RadioButton
  $chromeRadio.Location = New-Object System.Drawing.Point(20, 20)
  $chromeRadio.Size = New-Object System.Drawing.Size(150, 20)
  $chromeRadio.Text = 'Chrome'
  $chromeRadio.BackColor = [System.Drawing.Color]::Transparent
  $chromeRadio.ForeColor = [System.Drawing.Color]::White
  $form.Controls.Add($chromeRadio)

  $firefoxRadio = New-Object System.Windows.Forms.RadioButton
  $firefoxRadio.Location = New-Object System.Drawing.Point(20, 50)
  $firefoxRadio.Size = New-Object System.Drawing.Size(150, 20)
  $firefoxRadio.Text = 'Firefox'
  $firefoxRadio.BackColor = [System.Drawing.Color]::Transparent
  $firefoxRadio.ForeColor = [System.Drawing.Color]::White
  $form.Controls.Add($firefoxRadio)

  $braveRadio = New-Object System.Windows.Forms.RadioButton
  $braveRadio.Location = New-Object System.Drawing.Point(20, 80)
  $braveRadio.Size = New-Object System.Drawing.Size(150, 20)
  $braveRadio.Text = 'Brave'
  $braveRadio.BackColor = [System.Drawing.Color]::Transparent
  $braveRadio.ForeColor = [System.Drawing.Color]::White
  $form.Controls.Add($braveRadio)

  $installButton = Create-ModernButton -Text 'Install' -Location (New-Object Drawing.Point(100, 120)) -Size (New-Object Drawing.Size(100, 30)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2
  $form.Controls.Add($installButton)


  $result = $form.ShowDialog()


  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    if ($chromeRadio.Checked) {
      $uri = 'https://dl.google.com/tag/s/appguid%3D%7B8A69D345-D564-463C-AFF1-A69D9E530F96%7D%26iid%3D%7B297129A1-A25F-2799-7699-95238E0A3F50%7D%26lang%3Den%26browser%3D3%26usagestats%3D1%26appname%3DGoogle%2520Chrome%26needsadmin%3Dprefers%26ap%3Dx64-stable-statsdef_1%26installdataindex%3Dempty/update2/installers/ChromeSetup.exe'
      Get-FileFromWeb -URL $uri -File "$tempDir\ChromeInstaller.exe"
      Write-Host 
      Write-Status -Message 'Installing Chrome...' -Type Output
      Start-Process "$tempDir\ChromeInstaller.exe" -ArgumentList '/silent /install' -Wait 
      Remove-Item "$tempDir\ChromeInstaller.exe" -Force -ErrorAction SilentlyContinue

      Write-Status -Message 'Adding uBlock Lite...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist' /v '1' /t REG_SZ /d 'ddkjiahejlhfcafbddmgiahcphecmpfh;https://clients2.google.com/service/update2/crx' /f

      Write-Status -Message 'Adding Chrome Policies...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'PrivacySandboxSiteEnabledAdsEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'WebRtcEventLogCollectionAllowed' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'PrivacySandboxAdTopicsEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'UrlKeyedAnonymizedDataCollectionEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'RemoteAccessHostRequireCurtain' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'SafeBrowsingProtectionLevel' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'SafeBrowsingExtendedReportingEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'RemoteAccessHostFirewallTraversal' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'SafeBrowsingSurveysEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'PrivacySandboxAdMeasurementEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'RemoteAccessHostAllowClientPairing' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'PrivacySandboxPromptEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'BlockThirdPartyCookies' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'CloudReportingEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'HardwareAccelerationModeEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'BackgroundModeEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'HighEfficiencyModeEnabled' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Google\Chrome' /v 'GenAILocalFoundationalModelSettings' /t REG_DWORD /d '1' /f

    
    }
    elseif ($firefoxRadio.Checked) {
      $uri = 'https://download.mozilla.org/?product=firefox-latest-ssl&os=win64&lang=en-US'
      Get-FileFromWeb -URL $uri -File "$tempDir\FireFoxInstaller.exe" 
      Write-Host
      Write-Status -Message 'Installing Firefox...' -Type Output
      Start-Process "$tempDir\FireFoxInstaller.exe" -ArgumentList '-ms' -Wait 
      Remove-Item "$tempDir\FireFoxInstaller.exe" -Force -ErrorAction SilentlyContinue

      Write-Status -Message 'Adding Firefox Policies...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'DisableCrashReporter' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'DisableHardwareAcceleration' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'DisablePocketRecommendations' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'EnableTrackingProtection' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'DisableTelemetry' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'DisablePocketSponsoredStories' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'DisableWelcomePage' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'DisableLocationServices' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\Mozilla\Firefox' /v 'DisablePocket' /t REG_DWORD /d '1' /f
    }
    elseif ($braveRadio.Checked) {
      $headers = @{
        'User-Agent' = 'PowerShell'
      }
      $apiUrl = 'https://api.github.com/repos/brave/brave-browser/releases/latest'
      $response = Invoke-RestMethod -Uri $apiUrl -Method Get -Headers $headers -UseBasicParsing -ErrorAction Stop
      $downloadUrl = $response.assets | Where-Object { $_.name -eq 'BraveBrowserStandaloneSilentSetup.exe' } | Select-Object -ExpandProperty browser_download_url
    
      Get-FileFromWeb -URL $downloadUrl -File "$tempDir\BraveInstaller.exe"
      Write-Host
      Write-Status -Message 'Installing Brave...' -Type Output 
      Start-Process "$tempDir\BraveInstaller.exe" -Wait
      Remove-Item "$tempDir\BraveInstaller.exe" -Force -ErrorAction SilentlyContinue

      Write-Status -Message 'Adding Brave Policies...' -Type Output
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'SafeBrowsingExtendedReportingEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'UrlKeyedAnonymizedDataCollectionEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'FeedbackSurveysEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'BraveRewardsDisabled' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'BraveWalletDisabled' /t REG_DWORD /d '1' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'BraveAIChatEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'BackgroundModeEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'MediaRecommendationsEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'ShoppingListEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'PromotionsEnabled' /t REG_DWORD /d '0' /f
      Reg.exe add 'HKLM\SOFTWARE\Policies\BraveSoftware\Brave' /v 'DefaultBrowserSettingEnabled' /t REG_DWORD /d '0' /f
       
    }

    Custom-MsgBox -message 'Browser Installed!' -type None
  }

}
Export-ModuleMember -Function Install-Browsers


function FixUploadBufferBloat {
  param (
    [switch]$Enable,
    [switch]$Disable
  )

  #-------------------------- CREDITS AVEYO FOR CHANGES -----------------------------

  if ($Enable) {
    Write-Status -Message 'Applying Network Settings to Limit Upload Bandwidth and Improve Latency Under Load...' -Type Output
   
    #get all network adapters
    $NIC = @()
    foreach ($a in Get-NetAdapter -Physical | Select-Object DeviceID, Name) { 
      $NIC += @{ $($a | Select-Object Name -ExpandProperty Name) = $($a | Select-Object DeviceID -ExpandProperty DeviceID) }
    }
    

    $enableQos = {    
      New-Item 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' 'Do not use NLA' 1 -type string -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' DisableUserTOSSetting 0 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' NonBestEffortLimit 80 -type dword -force -ea 0 
      Get-NetQosPolicy | Remove-NetQosPolicy -Confirm:$False -ea 0
      Remove-NetQosPolicy 'Bufferbloat' -Confirm:$False -ea 0
      New-NetQosPolicy 'Bufferbloat' -Precedence 254 -DSCPAction 46 -NetworkProfile Public -Default -MinBandwidthWeightAction 25
    }
    &$enableQos *>$null

    $tcpTweaks = {
      $NIC.Values | ForEach-Object {
        Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$_" TcpAckFrequency 2 -type dword -force -ea 0  
        Set-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$_" TcpNoDelay 1 -type dword -force -ea 0
      }
      if (Get-Item 'HKLM:\SOFTWARE\Microsoft\MSMQ') { Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters' TCPNoDelay 1 -type dword -force -ea 0 }
      Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' NetworkThrottlingIndex 0xffffffff -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' SystemResponsiveness 10 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' NonBestEffortLimit 80 -type dword -force -ea 0 
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' LargeSystemCache 0 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' Size 3 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' DefaultTTL 64 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' MaxUserPort 65534 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' TcpTimedWaitDelay 30 -type dword -force -ea 0
      New-Item 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' 'Do not use NLA' 1 -type string -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider' DnsPriority 6 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider' HostsPriority 5 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider' LocalPriority 4 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider' NetbtPriority 7 -type dword -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' DisableTaskOffload -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' MaximumReassemblyHeaders 0xffff -type dword -force -ea 0 
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\AFD\Parameters' FastSendDatagramThreshold 1500 -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\AFD\Parameters' DefaultReceiveWindow $(2048 * 4096) -type dword -force -ea 0
      Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\AFD\Parameters' DefaultSendWindow $(2048 * 4096) -type dword -force -ea 0
    }
    &$tcpTweaks *>$null


    #disable adapters while applying 
    $NIC.Keys | ForEach-Object { Disable-NetAdapter -InterfaceAlias "$_" -Confirm:$False }

    $netAdaptTweaks = {
      foreach ($key in $NIC.Keys) {
        # reset advanced 
        $netProperty = Get-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'NetworkAddress' -ErrorAction SilentlyContinue
        if ($null -ne $netProperty.RegistryValue -and $netProperty.RegistryValue -ne ' ') {
          $mac = $netProperty.RegistryValue 
        }
        Get-NetAdapter -Name "$key" | Reset-NetAdapterAdvancedProperty -DisplayName '*'
        # restore custom mac
        if ($null -ne $mac) { 
          Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'NetworkAddress' -RegistryValue $mac 
        }
        # set receive and transmit buffers - less is better for latency, worst for throughput; too less and packet loss increases
        $rx = (Get-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*ReceiveBuffers').NumericParameterMaxValue  
        $tx = (Get-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*TransmitBuffers').NumericParameterMaxValue
        if ($null -ne $rx -and $null -ne $tx) {
          Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*ReceiveBuffers' -RegistryValue $rx # $rx 1024 320
          Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*TransmitBuffers' -RegistryValue $tx # $tx 2048 160
        }
        # pci-e adapters in msi-x mode from intel are generally fine with ITR Adaptive - others? not so much
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*InterruptModeration' -RegistryValue 0 # Off 0 On 1
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'ITR' -RegistryValue 0 # Off 0 Adaptive 65535
        # recieve side scaling is always worth it, some adapters feature more queues = cpu threads; not available for wireless   
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*RSS' -RegistryValue 1
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*NumRssQueues' -RegistryValue 2
        # priority tag
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*PriorityVLANTag' -RegistryValue 1
        # undesirable stuff 
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*FlowControl' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*JumboPacket' -RegistryValue 1514
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*HeaderDataSplit' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'TcpSegmentation' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'RxOptimizeThreshold' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'WaitAutoNegComplete' -RegistryValue 1
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'PowerSavingMode' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*SelectiveSuspend' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'EnableGreenEthernet' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'AdvancedEEE' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword 'EEE' -RegistryValue 0
        Set-NetAdapterAdvancedProperty -Name "$key" -RegistryKeyword '*EEE' -RegistryValue 0
      }

    }
    &$netAdaptTweaks *>$null


    $netAdaptTweaks2 = { $NIC.Keys | ForEach-Object {
        Set-NetAdapterRss -Name "$_" -NumberOfReceiveQueues 2 -MaxProcessorNumber 4 -Profile 'NUMAStatic' -Enabled $true -ea 0
        Enable-NetAdapterQos -Name "$_" -ea 0
        Enable-NetAdapterChecksumOffload -Name "$_" -ea 0
        Disable-NetAdapterRsc -Name "$_" -ea 0
        Disable-NetAdapterUso -Name "$_" -ea 0
        Disable-NetAdapterLso -Name "$_" -ea 0
        Disable-NetAdapterIPsecOffload -Name "$_" -ea 0
        Disable-NetAdapterEncapsulatedPacketTaskOffload -Name "$_" -ea 0
      }
        
      Set-NetOffloadGlobalSetting -TaskOffload Enabled
      Set-NetOffloadGlobalSetting -Chimney Disabled
      Set-NetOffloadGlobalSetting -PacketCoalescingFilter Disabled
      Set-NetOffloadGlobalSetting -ReceiveSegmentCoalescing Disabled
      Set-NetOffloadGlobalSetting -ReceiveSideScaling Enabled
      Set-NetOffloadGlobalSetting -NetworkDirect Enabled
      Set-NetOffloadGlobalSetting -NetworkDirectAcrossIPSubnets Allowed -ea 0
    }
    &$netAdaptTweaks2 *>$null

    #enable adapters
    $NIC.Keys | ForEach-Object { Enable-NetAdapter -InterfaceAlias "$_" -Confirm:$False }

    $netShTweaks = {
      netsh winsock set autotuning on                                    # Winsock send autotuning
      netsh int udp set global uro=disabled                              # UDP Receive Segment Coalescing Offload - 11 24H2
      netsh int tcp set heuristics wsh=disabled forcews=enabled          # Window Scaling heuristics
      netsh int tcp set supplemental internet minrto=300                 # Controls TCP retransmission timeout. 20 to 300 msec.
      netsh int tcp set supplemental internet icw=10                     # Controls initial congestion window. 2 to 64 MSS
      netsh int tcp set supplemental internet congestionprovider=newreno # Controls the congestion provider. Default: cubic
      netsh int tcp set supplemental internet enablecwndrestart=disabled # Controls whether congestion window is restarted.
      netsh int tcp set supplemental internet delayedacktimeout=40       # Controls TCP delayed ack timeout. 10 to 600 msec.
      netsh int tcp set supplemental internet delayedackfrequency=2      # Controls TCP delayed ack frequency. 1 to 255.
      netsh int tcp set supplemental internet rack=enabled               # Controls whether RACK time based recovery is enabled.
      netsh int tcp set supplemental internet taillossprobe=enabled      # Controls whether Tail Loss Probe is enabled.
      netsh int tcp set security mpp=disabled                            # Memory pressure protection (SYN flood drop)
      netsh int tcp set security profiles=disabled                       # Profiles protection (private vs domain)

      netsh int tcp set global rss=enabled                    # Enable receive-side scaling.
      netsh int tcp set global autotuninglevel=Normal         # Fix the receive window at its default value
      netsh int tcp set global ecncapability=enabled          # Enable/disable ECN Capability.
      netsh int tcp set global timestamps=enabled             # Enable/disable RFC 1323 timestamps.
      netsh int tcp set global initialrto=1000                # Connect (SYN) retransmit time (in ms).
      netsh int tcp set global rsc=disabled                   # Enable/disable receive segment coalescing.
      netsh int tcp set global nonsackrttresiliency=disabled  # Enable/disable rtt resiliency for non sack clients.
      netsh int tcp set global maxsynretransmissions=4        # Connect retry attempts using SYN packets.
      netsh int tcp set global fastopen=enabled               # Enable/disable TCP Fast Open.
      netsh int tcp set global fastopenfallback=enabled       # Enable/disable TCP Fast Open fallback.
      netsh int tcp set global hystart=enabled                # Enable/disable the HyStart slow start algorithm.
      netsh int tcp set global prr=enabled                    # Enable/disable the Proportional Rate Reduction algorithm.
      netsh int tcp set global pacingprofile=off              # Set the periods during which pacing is enabled. off: Never pace.

      netsh int ip set global loopbacklargemtu=enable         # Loopback Large Mtu
      netsh int ip set global loopbackworkercount=4           # Loopback Worker Count 1 2 4
      netsh int ip set global loopbackexecutionmode=inline    # Loopback Execution Mode adaptive|inline|worker
      netsh int ip set global reassemblylimit=267748640       # Reassembly Limit 267748640|0
      netsh int ip set global reassemblyoutoforderlimit=48    # Reassembly Out Of Order Limit 32
      netsh int ip set global sourceroutingbehavior=drop      # Source Routing Behavior drop|dontforward
      netsh int ip set dynamicport tcp start=32769 num=32766  # DynamicPortRange tcp
      netsh int ip set dynamicport udp start=32769 num=32766  # DynamicPortRange udp
    }
    &$netShTweaks *>$null

  }
  elseif ($Disable) {
    Write-Status -Message 'Reverting Network Tweaks...' -Type Output
   
    #get all network adapters
    $NIC = @()
    foreach ($a in Get-NetAdapter -Physical | Select-Object DeviceID, Name) { 
      $NIC += @{ $($a | Select-Object Name -ExpandProperty Name) = $($a | Select-Object DeviceID -ExpandProperty DeviceID) }
    }

    $revertTcpTweaks = {
      $NIC.Values | ForEach-Object {
        Remove-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$_" TcpAckFrequency -force -ea 0
        Remove-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$_" TcpDelAckTicks -force -ea 0
        Remove-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$_" TcpNoDelay -force -ea 0
      }
      if (Get-Item 'HKLM:\SOFTWARE\Microsoft\MSMQ') { Remove-ItemProperty 'HKLM:\SOFTWARE\Microsoft\MSMQ\Parameters' TCPNoDelay -force -ea 0 }
      Remove-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' NetworkThrottlingIndex -force -ea 0
      Remove-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' SystemResponsiveness -force -ea 0
      Remove-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Psched' NonBestEffortLimit -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' LargeSystemCache -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' Size -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' DefaultTTL -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' MaxUserPort -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' TcpTimedWaitDelay -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' 'Do not use NLA' -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider' DnsPriority -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider' HostsPriority -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider' LocalPriority -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\ServiceProvider' NetbtPriority -force -ea 0
    }
    &$revertTcpTweaks *>$null

    $resetRegtweaks = {
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\AFD\Parameters' FastSendDatagramThreshold -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\AFD\Parameters' DefaultSendWindow -force -ea 0 
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\AFD\Parameters' DefaultReceiveWindow -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' IRPStackSize -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' DisableTaskOffload -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' MaximumReassemblyHeaders -force -ea 0  
    }
    &$resetRegtweaks *>$null

    $resetNetAdaptTweaks = {
      $NIC.Keys | ForEach-Object { Disable-NetAdapter -InterfaceAlias "$_" -Confirm:$False }

      $NIC.Keys | ForEach-Object {
        $mac = $(Get-NetAdapterAdvancedProperty -Name "$_" -RegistryKeyword 'NetworkAddress' -ea 0).RegistryValue
        Get-NetAdapter -Name "$_" | Reset-NetAdapterAdvancedProperty -DisplayName '*'
        if ($mac) { Set-NetAdapterAdvancedProperty -Name "$_" -RegistryKeyword 'NetworkAddress' -RegistryValue $mac }
      }

      $NIC.Keys | ForEach-Object { Enable-NetAdapter -InterfaceAlias "$_" -Confirm:$False }
    }
    &$resetNetAdaptTweaks *>$null

    $resetNetshTweaks = {
      netsh int ip set dynamicport tcp start=49152 num=16384
      netsh int ip set dynamicport udp start=49152 num=16384
      netsh int ip set global reassemblyoutoforderlimit=32
      netsh int ip set global reassemblylimit=267748640
      netsh int ip set global loopbackexecutionmode=adaptive 
      netsh int ip set global sourceroutingbehavior=dontforward
      netsh int ip reset; 
      netsh int ipv6 reset 
      netsh int ipv4 reset 
      netsh int tcp reset 
      netsh int udp reset 
      netsh winsock reset
    }
    &$resetNetshTweaks *>$null

    $resetQos = {
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\QoS' 'Do not use NLA' -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' DefaultTOSValue -force -ea 0
      Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' DisableUserTOSSetting -force -ea 0
      Remove-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS' 'Tcp Autotuning Level' -force -ea 0
      Get-NetQosPolicy | Remove-NetQosPolicy -Confirm:$False -ea 0
    }
    &$resetQos *>$null


  }


}
Export-ModuleMember -Function FixUploadBufferBloat


function Write-Status {
  param(
    [ValidateSet('Warning', 'Output', 'Error')]
    $Type,
    [string]$Message
  )


  if ($Type -eq 'Warning') {
    Write-Host "[WARNING] $Message" -ForegroundColor DarkYellow
  }
  elseif ($Type -eq 'Output') {
    Write-Host "[+] $Message" -ForegroundColor Cyan
  }
  else {
    Write-Host "[ERROR] $Message" -ForegroundColor Red
  }

}
Export-ModuleMember -Function Write-Status



function Display-Settings {

  #check if settings file is made
  $settingsContent = @'
  #mpware SCRIPT SETTINGS
  dontCheckUpdates = 0
'@
 
  
  $settingsLocation = "$env:USERPROFILE\mpwareSettings.cfg"
  if (!(Test-Path $settingsLocation)) {
    Write-Status -Message 'Creating Settings File...' -Type Output
    New-Item $settingsLocation -Force | Out-Null
    Set-Content $settingsLocation -Value $settingsContent -Force | Out-Null
  }

  #read settings file
  $dontCheck4Updates = $false
  $readContent = (Get-Content -Path $settingsLocation -Raw -Force) -split "`r`n"
  foreach ($line in $readContent) {
    if ($line -like '*dontCheckUpdates*') {
      $sLine = $line -split '='
      if ($sLine[1].Trim() -eq '1') {
        $dontCheck4Updates = $true
      }
    }
  }

  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.Application]::EnableVisualStyles()

  # Create the form
  $form = New-Object System.Windows.Forms.Form
  $form.Text = 'mpware Settings'
  $form.Size = New-Object System.Drawing.Size(300, 230)
  $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  $form.MaximizeBox = $false
  $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
  $form.BackColor = 'Black'
  $form.Font = New-Object System.Drawing.Font('Segoe UI', 8)

  $type = $form.GetType()
  $propInfo = $type.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic)
  $propInfo.SetValue($form, $true, $null)

  $startColor = [System.Drawing.Color]::FromArgb(18, 18, 18)   #rgb(61, 74, 102)
  $endColor = [System.Drawing.Color]::FromArgb(0, 0, 0)       #rgb(0, 0, 0)

  # Override the form's paint event to apply the gradient
  $form.Add_Paint({
      param($sender, $e)
      $rect = New-Object System.Drawing.Rectangle(0, 0, $form.Width, $form.Height)
      $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        $rect, 
        $startColor, 
        $endColor, 
        [System.Drawing.Drawing2D.LinearGradientMode]::ForwardDiagonal
      )
      $e.Graphics.FillRectangle($brush, $rect)
      $brush.Dispose()
    })
    
  # Create the checkboxes
  $checkbox1 = New-Object System.Windows.Forms.CheckBox
  $checkbox1.Text = "Don't Check For Updates"
  $checkbox1.Location = New-Object System.Drawing.Point(20, 20)
  $checkbox1.ForeColor = 'White'
  $checkbox1.BackColor = [System.Drawing.Color]::Transparent
  $checkbox1.AutoSize = $true
  if ($dontCheck4Updates) {
    $checkbox1.Checked = $true
  }
  $form.Controls.Add($checkbox1)
    
  $checkbox2 = New-Object System.Windows.Forms.CheckBox
  $checkbox2.Text = 'Clear Script Location Cache'
  $checkbox2.Location = New-Object System.Drawing.Point(20, 50)
  $checkbox2.ForeColor = 'White'
  $checkbox2.BackColor = [System.Drawing.Color]::Transparent
  $checkbox2.AutoSize = $true
  $form.Controls.Add($checkbox2)
    
  $checkbox3 = New-Object System.Windows.Forms.CheckBox
  $checkbox3.Text = 'Reset Current Config Options'
  $checkbox3.Location = New-Object System.Drawing.Point(20, 80)
  $checkbox3.ForeColor = 'White'
  $checkbox3.BackColor = [System.Drawing.Color]::Transparent
  $checkbox3.AutoSize = $true
  $form.Controls.Add($checkbox3)
  
  $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
  $Global:asSystem = $false
  if ($currentUser.User -eq 'S-1-5-18') {
    $Global:asSystem = $true
  }
  $checkbox4 = New-Object System.Windows.Forms.CheckBox
  $checkbox4.Text = 'Run as TrustedInstaller'
  $checkbox4.Location = New-Object System.Drawing.Point(20, 110)
  $checkbox4.ForeColor = 'White'
  $checkbox4.BackColor = [System.Drawing.Color]::Transparent
  if ($Global:asSystem) {
    $checkbox4.Checked = $true
  }
  $checkbox4.AutoSize = $true
  $form.Controls.Add($checkbox4)
  
  $OKButton = Create-ModernButton -Text 'OK' -Location (New-Object Drawing.Point(70, 150)) -Size (New-Object Drawing.Size(75, 25)) -DialogResult ([System.Windows.Forms.DialogResult]::OK) -borderSize 2

  $form.Controls.Add($OKButton)
  
  $CancelButton = Create-ModernButton -Text 'Cancel' -Location (New-Object Drawing.Point(150, 150)) -Size (New-Object Drawing.Size(75, 25)) -DialogResult ([System.Windows.Forms.DialogResult]::Cancel) -borderSize 2

  $form.Controls.Add($CancelButton)
    
    
  # Show the form and wait for user input
  $result = $form.ShowDialog()

  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {

    if ($dontCheck4Updates -and $checkbox1.Checked -eq $false) {
      Write-Status -Message 'Enabling Check For Updates...' -Type Output
      $newContent = $()
      foreach ($line in $readContent) {
        if ($line -like '*dontCheckUpdates*') {
          $sLine = $line -split '='
          $newLine = "$($sLine[0].Trim()) = 0"
          $newContent += "$newLine`n"
        }
        else {
          $newContent += "$line`n"
        }
      }
      Set-Content -Path $settingsLocation -Value $newContent -Force 
    }
    elseif (!$dontCheck4Updates -and $checkbox1.Checked -eq $true) {
      Write-Status -Message 'Disabling Check For Updates...' -Type Output
      $newContent = $()
      foreach ($line in $readContent) {
        if ($line -like '*dontCheckUpdates*') {
          $sLine = $line -split '='
          $newLine = "$($sLine[0].Trim()) = 1"
          $newContent += "$newLine`n"
        }
        else {
          $newContent += "$line`n"
        }
      }
      Set-Content -Path $settingsLocation -Value $newContent -Force 
    }



    if ($checkbox2.Checked) {
      Write-Status -Message 'Removing Location File...' -Type Output
      Remove-Item "$env:USERPROFILE\mpwareLocation.tmp" -Force -ErrorAction SilentlyContinue
    }


    if ($checkbox3.Checked) {
      Write-Status -Message 'Resetting Current Config...' -Type Output
      <#
      #set all config settings back to 0
      $currentConfig = Get-Content -Path "$env:USERPROFILE\mpware-config.cfg" -Force
      $newConfig = @()
      foreach ($line in $currentConfig) {
        if ($line -notmatch '#') {
          $splitLine = $line -split '='
          $settingName = $splitLine[0]
          $newConfig += "$($settingName.trim()) = 0"
        }
        else {
          $newConfig += $line
        }
      
      }
      $newConfig | Out-File -FilePath "$env:USERPROFILE\mpware-config.cfg" -Force
      #>
      #reset just the currently read in options
      $Global:enabledOptions = @()
    }

    if ($checkbox4.Checked -and !$Global:asSystem) {
      Write-Status -Message 'Re-Launching mpware with Trusted Installer Priv...' -Type Output
      $exe = Get-Process -Name '*mpware'
      
      RunAsTI "$($exe.Path)"
      Stop-Process -Id $PID
      
    }

  }
}
Export-ModuleMember -Function Display-Settings



function RunAsTI ($cmd, $arg) {
  #create key for current user
  $id = 'RunAsTI'
  $key = "Registry::HKU\$(((whoami /user)-split' ')[-1])\Volatile Environment"
  # .NET reflection and win32 api to run process with system priv
  $code = @'
 $I=[int32]; $M=$I.module.gettype("System.Runtime.Interop`Services.Mar`shal"); $P=$I.module.gettype("System.Int`Ptr"); $S=[string]
 $D=@(); $T=@(); $DM=[AppDomain]::CurrentDomain."DefineDynami`cAssembly"(1,1)."DefineDynami`cModule"(1); $Z=[uintptr]::size
 0..5|% {$D += $DM."Defin`eType"("AveYo_$_",1179913,[ValueType])}; $D += [uintptr]; 4..6|% {$D += $D[$_]."MakeByR`efType"()}
 $F='kernel','advapi','advapi', ($S,$S,$I,$I,$I,$I,$I,$S,$D[7],$D[8]), ([uintptr],$S,$I,$I,$D[9]),([uintptr],$S,$I,$I,[byte[]],$I)
 0..2|% {$9=$D[0]."DefinePInvok`eMethod"(('CreateProcess','RegOpenKeyEx','RegSetValueEx')[$_],$F[$_]+'32',8214,1,$S,$F[$_+3],1,4)}
 $DF=($P,$I,$P),($I,$I,$I,$I,$P,$D[1]),($I,$S,$S,$S,$I,$I,$I,$I,$I,$I,$I,$I,[int16],[int16],$P,$P,$P,$P),($D[3],$P),($P,$P,$I,$I)
 1..5|% {$k=$_; $n=1; $DF[$_-1]|% {$9=$D[$k]."Defin`eField"('f' + $n++, $_, 6)}}; 0..5|% {$T += $D[$_]."Creat`eType"()}
 0..5|% {nv "A$_" ([Activator]::CreateInstance($T[$_])) -fo}; function F ($1,$2) {$T[0]."G`etMethod"($1).invoke(0,$2)}
 $TI=(whoami /groups)-like'*1-16-16384*'; $As=0; if(!$cmd) {$cmd='control';$arg='admintools'}; if ($cmd-eq'This PC'){$cmd='file:'}
 if (!$TI) {'TrustedInstaller','lsass','winlogon'|% {if (!$As) {$9=sc.exe start $_; $As=@(get-process -name $_ -ea 0|% {$_})[0]}}
 function M ($1,$2,$3) {$M."G`etMethod"($1,[type[]]$2).invoke(0,$3)}; $H=@(); $Z,(4*$Z+16)|% {$H += M "AllocHG`lobal" $I $_}
 M "WriteInt`Ptr" ($P,$P) ($H[0],$As.Handle); $A1.f1=131072; $A1.f2=$Z; $A1.f3=$H[0]; $A2.f1=1; $A2.f2=1; $A2.f3=1; $A2.f4=1
 $A2.f6=$A1; $A3.f1=10*$Z+32; $A4.f1=$A3; $A4.f2=$H[1]; M "StructureTo`Ptr" ($D[2],$P,[boolean]) (($A2 -as $D[2]),$A4.f2,$false)
 $Run=@($null, "powershell -win 1 -nop -c iex `$env:R; # $id", 0, 0, 0, 0x0E080600, 0, $null, ($A4 -as $T[4]), ($A5 -as $T[5]))
 F 'CreateProcess' $Run; return}; $env:R=''; rp $key $id -force; $priv=[diagnostics.process]."GetM`ember"('SetPrivilege',42)[0]
 'SeSecurityPrivilege','SeTakeOwnershipPrivilege','SeBackupPrivilege','SeRestorePrivilege' |% {$priv.Invoke($null, @("$_",2))}
 $HKU=[uintptr][uint32]2147483651; $NT='S-1-5-18'; $reg=($HKU,$NT,8,2,($HKU -as $D[9])); F 'RegOpenKeyEx' $reg; $LNK=$reg[4]
 function L ($1,$2,$3) {sp 'HKLM:\Software\Classes\AppID\{CDCBCFCA-3CDC-436f-A4E2-0E02075250C2}' 'RunAs' $3 -force -ea 0
  $b=[Text.Encoding]::Unicode.GetBytes("\Registry\User\$1"); F 'RegSetValueEx' @($2,'SymbolicLinkValue',0,6,[byte[]]$b,$b.Length)}
 function Q {[int](gwmi win32_process -filter 'name="explorer.exe"'|?{$_.getownersid().sid-eq$NT}|select -last 1).ProcessId}
 $11bug=($((gwmi Win32_OperatingSystem).BuildNumber)-eq'22000')-AND(($cmd-eq'file:')-OR(test-path -lit $cmd -PathType Container))
 if ($11bug) {'System.Windows.Forms','Microsoft.VisualBasic' |% {[Reflection.Assembly]::LoadWithPartialName("'$_")}}
 if ($11bug) {$path='^(l)'+$($cmd -replace '([\+\^\%\~\(\)\[\]])','{$1}')+'{ENTER}'; $cmd='control.exe'; $arg='admintools'}
 L ($key-split'\\')[1] $LNK ''; $R=[diagnostics.process]::start($cmd,$arg); if ($R) {$R.PriorityClass='High'; $R.WaitForExit()}
 if ($11bug) {$w=0; do {if($w-gt40){break}; sleep -mi 250;$w++} until (Q); [Microsoft.VisualBasic.Interaction]::AppActivate($(Q))}
 if ($11bug) {[Windows.Forms.SendKeys]::SendWait($path)}; do {sleep 7} while(Q); L '.Default' $LNK 'Interactive User'
'@

  #create variables for reg key code
  $V = ''
  'cmd', 'arg', 'id', 'key' | ForEach-Object { 
    $V += "`n`$$_='$($(Get-Variable $_ -val)-replace"'","''")';" 
  }
  #set reg key to above code and run
  Set-ItemProperty $key $id $($V, $code) -Type 7 -Force -ErrorAction SilentlyContinue
  Start-Process powershell -ArgumentList "-win 1 -nop -c `n$V `$env:R=(gi `$key -ea 0).getvalue(`$id)-join''; iex `$env:R" -verb runas -WindowStyle Hidden
} # lean & mean snippet by AveYo, 2022.01.28
Export-ModuleMember -Function RunAsTI



function Show-ModernFilePicker {
  param(
    [ValidateSet('Folder', 'File')]
    $Mode,
    [string]$fileType

  )

  if ($Mode -eq 'Folder') {
    $Title = 'Select Folder'
    $modeOption = $false
    $Filter = "Folders|`n"
  }
  else {
    $Title = 'Select File'
    $modeOption = $true
    if ($fileType) {
      $Filter = "$fileType Files (*.$fileType) | *.$fileType|All files (*.*)|*.*"
    }
    else {
      $Filter = 'All Files (*.*)|*.*'
    }
  }
  #modern file dialog
  #modified code from: https://gist.github.com/IMJLA/1d570aa2bb5c30215c222e7a5e5078fd
  $AssemblyFullName = 'System.Windows.Forms, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
  $Assembly = [System.Reflection.Assembly]::Load($AssemblyFullName)
  $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
  $OpenFileDialog.AddExtension = $modeOption
  $OpenFileDialog.CheckFileExists = $modeOption
  $OpenFileDialog.DereferenceLinks = $true
  $OpenFileDialog.Filter = $Filter
  $OpenFileDialog.Multiselect = $false
  $OpenFileDialog.Title = $Title
  $OpenFileDialog.InitialDirectory = [Environment]::GetFolderPath('Desktop')

  $OpenFileDialogType = $OpenFileDialog.GetType()
  $FileDialogInterfaceType = $Assembly.GetType('System.Windows.Forms.FileDialogNative+IFileDialog')
  $IFileDialog = $OpenFileDialogType.GetMethod('CreateVistaDialog', @('NonPublic', 'Public', 'Static', 'Instance')).Invoke($OpenFileDialog, $null)
  $null = $OpenFileDialogType.GetMethod('OnBeforeVistaDialog', @('NonPublic', 'Public', 'Static', 'Instance')).Invoke($OpenFileDialog, $IFileDialog)
  if ($Mode -eq 'Folder') {
    [uint32]$PickFoldersOption = $Assembly.GetType('System.Windows.Forms.FileDialogNative+FOS').GetField('FOS_PICKFOLDERS').GetValue($null)
    $FolderOptions = $OpenFileDialogType.GetMethod('get_Options', @('NonPublic', 'Public', 'Static', 'Instance')).Invoke($OpenFileDialog, $null) -bor $PickFoldersOption
    $null = $FileDialogInterfaceType.GetMethod('SetOptions', @('NonPublic', 'Public', 'Static', 'Instance')).Invoke($IFileDialog, $FolderOptions)
  }
  
  

  $VistaDialogEvent = [System.Activator]::CreateInstance($AssemblyFullName, 'System.Windows.Forms.FileDialog+VistaDialogEvents', $false, 0, $null, $OpenFileDialog, $null, $null).Unwrap()
  [uint32]$AdviceCookie = 0
  $AdvisoryParameters = @($VistaDialogEvent, $AdviceCookie)
  $AdviseResult = $FileDialogInterfaceType.GetMethod('Advise', @('NonPublic', 'Public', 'Static', 'Instance')).Invoke($IFileDialog, $AdvisoryParameters)
  $AdviceCookie = $AdvisoryParameters[1]
  $Result = $FileDialogInterfaceType.GetMethod('Show', @('NonPublic', 'Public', 'Static', 'Instance')).Invoke($IFileDialog, [System.IntPtr]::Zero)
  $null = $FileDialogInterfaceType.GetMethod('Unadvise', @('NonPublic', 'Public', 'Static', 'Instance')).Invoke($IFileDialog, $AdviceCookie)
  if ($Result -eq [System.Windows.Forms.DialogResult]::OK) {
    $FileDialogInterfaceType.GetMethod('GetResult', @('NonPublic', 'Public', 'Static', 'Instance')).Invoke($IFileDialog, $null)
  }

  return $OpenFileDialog.FileName
}
Export-ModuleMember -Function Show-ModernFilePicker


function Repair-Windows {
  $choice = Read-Host -Prompt 'Run SFC /Scannow? [Y/N]'
  if ($choice.ToUpper() -eq 'Y') {
    Write-Status -Message 'Running SFC Scannow...' -Type Output
    Start-Process sfc.exe -ArgumentList '/scannow' -NoNewWindow -Wait
  }

  $choice = Read-Host -Prompt 'Run DISM Repair Commands? [Y/N]'
  if ($choice.ToUpper() -eq 'Y') {
    Write-Status -Message 'Running DISM Repair Commands...' -Type Output
    Start-Process DISM.exe -ArgumentList '/Online /Cleanup-Image /ScanHealth' -NoNewWindow -Wait
    Start-Process DISM.exe -ArgumentList '/Online /Cleanup-Image /CheckHealth' -NoNewWindow -Wait
    Start-Process DISM.exe -ArgumentList '/Online /Cleanup-Image /RestoreHealth' -NoNewWindow -Wait
  }
 
 
  $choice = Read-Host -Prompt 'Repair Windows Update? [Y/N]'
  if ($choice.ToUpper() -eq 'Y') {
    Write-Status -Message 'Repairing Windows Update...' -Type Output
    Stop-Service wuauserv -NoWait -Force -ErrorAction SilentlyContinue
    Stop-Service BITS -NoWait -Force -ErrorAction SilentlyContinue
    Remove-Item -Path 'C:\Windows\SoftwareDistribution' -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path 'C:\Windows\Logs\WindowsUpdate' -Recurse -Force -ErrorAction SilentlyContinue
    Set-Service BITS -StartupType Automatic -ErrorAction SilentlyContinue
    Set-Service wuauserv -StartupType Manual -ErrorAction SilentlyContinue
    Set-Service DoSvc -StartupType Automatic -ErrorAction SilentlyContinue
    Start-Service wuauserv *>$null
    Start-Service BITS *>$null
    Start-Service DoSvc *>$null
  }

  $choice2 = Read-Host -Prompt 'Reset Network Settings? [Y/N]'
  if ($choice2.ToUpper() -eq 'Y') {
    Write-Status -Message 'Resetting Network Settings and Flushing DNS...' -Type Output
    ipconfig /release >$null                         
    ipconfig /renew >$null                        
    ipconfig /flushdns >$null                       
    netsh winsock reset >$null                      
    netsh int ip reset >$null
  }

  $choice5 = Read-Host -Prompt 'Clear Icon Cache? [Y/N]'
  if ($choice5.ToUpper() -eq 'Y') {
    Write-Status -Message 'Clearing Icon Cache...' -Type Output
    $cacheDir = "$env:LocalAppData\Microsoft\Windows\Explorer"
    Get-ChildItem -Path $cacheDir -Filter 'iconcache_*.db' | Remove-Item -Force -ErrorAction SilentlyContinue
    Get-ChildItem -Path $cacheDir -Filter 'thumbcache_*.db' | Remove-Item -Force -ErrorAction SilentlyContinue
    Stop-Process -Name explorer
  }
  
  $choice3 = Read-Host -Prompt 'Run Check Disk Scan? [Y/N]'
  if ($choice3.ToUpper() -eq 'Y') {
    Write-Status -Message 'Running Check Disk Scan...' -Type Output
    Start-Process chkdsk.exe -ArgumentList '/scan' -NoNewWindow -Wait
    $choice4 = Read-Host -Prompt 'Schedule Check Disk Repair On Next Restart? [Y/N]'
    if ($choice4.ToUpper() -eq 'Y') {
      Start-Process chkdsk.exe -ArgumentList '/f' -NoNewWindow -Wait
    }
  }

}
Export-ModuleMember -Function Repair-Windows


function Restart-Explorer {
  Write-Status -Message 'Restarting Explorer...' -Type Output
  try {
    Stop-Process -name explorer -Force -ErrorAction Stop
  }
  catch {
    #try taskkill instead if stop process doesnt work for some reason
    taskkill.exe /F /IM 'explorer.exe' *>$null
  }
  #sleep for 10 seconds and start explorer if not auto starting
  $time = 10
  do {
    $time--
    Start-Sleep 1
  }while (!(Get-Process explorer -ErrorAction SilentlyContinue) -and $time -ne 0)
  if ($time -eq 0) {
    Write-Status -Message 'Explorer Did Not Restart Automatically...' -Type Output
    Write-Status -Message 'Starting Explorer...' -Type Output
    Start-Process explorer
  }
  
  
}
Export-ModuleMember -Function Restart-Explorer


function Restart-Bios {
  $result = Custom-MsgBox -message 'Are You Sure You Want to Restart to BIOS?' -type Question
  if ($result -eq 'OK') {
    #double command to fix enviroment error
    shutdown /r /fw /t 0
    shutdown /r /fw /t 0
  }
}
Export-ModuleMember -Function Restart-Bios


function Create-ModernButton {
  param (
    [string]$Text,
    [System.Drawing.Point]$Location,
    [System.Drawing.Size]$Size,
    [scriptblock]$ClickAction,
    [string]$TooltipText,
    [string]$IconPath = $null,
    [int]$CornerRadius = 6,
    [int]$borderSize = 0,
    [int]$fontSize = 9,
    [int]$r = 22, 
    [int]$g = 27,
    [int]$b = 36,
    $DialogResult,
    $Visible = $true
  )


  # Get DPI scaling
  Add-Type @'
      using System;
      using System.Runtime.InteropServices;
      using System.Drawing;
      using System.Windows.Forms;
      
      public class DPIHelper {
          [DllImport("user32.dll")]
          public static extern int GetDpiForWindow(IntPtr hwnd);
          
          [DllImport("gdi32.dll")]
          public static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);
          
          [DllImport("gdi32.dll")]
          public static extern bool DeleteObject(IntPtr hObject);
          
          public static float GetScaleFactor(Control control) {
              if (control.Handle != IntPtr.Zero) {
                  int dpi = GetDpiForWindow(control.Handle);
                  return dpi / 96.0f;
              }
              return 1.0f;
          }
      }
'@ -ReferencedAssemblies System.Drawing, System.Windows.Forms

  $button = New-Object Windows.Forms.Button
  $button.Text = $Text
  if ($Location) { $button.Location = $Location }  
  $button.Size = $Size
  if ($DialogResult) { $button.DialogResult = $DialogResult }
  $button.Visible = $Visible 
  $button.BackColor = [System.Drawing.Color]::FromArgb($r, $g, $b) #rgb(66, 70, 80)
  $button.ForeColor = [System.Drawing.Color]::White
  $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $button.FlatAppearance.BorderSize = $borderSize
  $button.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(84, 163, 255)
  $button.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(31, 39, 53)
  $button.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb($r, $g, $b)
  $button.Cursor = [System.Windows.Forms.Cursors]::Hand
  $button.Font = New-Object System.Drawing.Font('Segoe UI', $fontSize, [System.Drawing.FontStyle]::Regular)
  $button.UseCompatibleTextRendering = $false
  $button.Tag = @{
    OriginalColor = [System.Drawing.Color]::FromArgb($r, $g, $b)
    HoverColor    = [System.Drawing.Color]::FromArgb(31, 39, 53)
  }

  # Handle DPI-aware rounded corners with improved calculation
  $Global:setRoundedRegion = {
    if ($this.Width -gt 0 -and $this.Height -gt 0) {
      try {
        # Dispose existing region to prevent memory leaks
        if ($this.Region -ne $null -and -not $this.Region.IsInfinite([System.Drawing.Graphics]::FromHwnd($this.Handle))) {
          $this.Region.Dispose()
        }
              
        $scaleFactor = if ($this.Handle -ne [IntPtr]::Zero) { [DPIHelper]::GetScaleFactor($this) } else { 1.0 }
        $adjustedRadius = [Math]::Max(2, [Math]::Round($CornerRadius * $scaleFactor))
              
        # Account for border width in calculations
        $borderWidth = $this.FlatAppearance.BorderSize
        $width = $this.Width
        $height = $this.Height
              
        # Create the rounded rectangle region accounting for border
        # The region should encompass the entire button including border
        $regionHandle = [DPIHelper]::CreateRoundRectRgn(
          0, 
          0, 
          $width + 1, 
          $height + 1, 
          $adjustedRadius * 2, 
          $adjustedRadius * 2
        )
              
        if ($regionHandle -ne [IntPtr]::Zero) {
          $this.Region = [System.Drawing.Region]::FromHrgn($regionHandle)
          # Clean up the handle
          [DPIHelper]::DeleteObject($regionHandle)
        }
      }
      catch {
        # Fallback - just ensure we don't crash
        Write-Host "Region setting error: $($_.Exception.Message)"
      }
    }
  }
  
  $button.Add_HandleCreated($setRoundedRegion)
  $button.Add_SizeChanged($setRoundedRegion)
  $button.Add_Resize($setRoundedRegion)
  
  # Also set region after a short delay to handle timing issues
  $button.Add_VisibleChanged({
      if ($this.Visible) {
        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 10
        $timer.Add_Tick({
            $setRoundedRegion.Invoke()
            $this.Stop()
            $this.Dispose()
          })
        $timer.Start()
      }
    })

  # Add icon with proper scaling
  if ($IconPath -and (Test-Path $IconPath)) {
    $icon = [System.Drawing.Image]::FromFile($IconPath)
    $button.Image = New-Object System.Drawing.Bitmap $icon, 20, 20
    $button.ImageAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $button.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $button.TextImageRelation = [System.Windows.Forms.TextImageRelation]::ImageBeforeText
    $button.Padding = New-Object System.Windows.Forms.Padding(10, 0, 10, 0)
  }

  # Hover effects
  $button.Add_MouseEnter({ try { $this.BackColor = $this.Tag.hoverColor }catch {} })
  $button.Add_MouseLeave({ try { $this.BackColor = $this.Tag.originalColor }catch {} })

  #  $button.Add_MouseDown({ 
  #          $this.FlatAppearance.BorderSize = $borderSize
  #          $this.BackColor = [System.Drawing.Color]::FromArgb(50, 54, 66)
  #      })
  #  $button.Add_MouseUp({ 
  #          $this.FlatAppearance.BorderSize = $borderSize
  #          $this.BackColor = [System.Drawing.Color]::FromArgb(69, 73, 85)
  #      })

  # Click event
  if ($ClickAction) {
    $button.Add_Click($ClickAction)
  }

  # Add tooltip
  if ($TooltipText) {
    $tooltip = New-Object System.Windows.Forms.ToolTip
    $tooltip.SetToolTip($button, $TooltipText)
  }

  $button.TabStop = $false

  return $button
}
Export-ModuleMember -Function Create-ModernButton


function Get-EnabledOptions {
  $config = "$env:USERPROFILE\mpware-config.cfg"
  $configContent = Get-Content -Path $config -Force

  foreach ($line in $configContent) {
    if ($line -notlike '#*' -and !([string]::IsNullOrWhiteSpace($line))) {
      $settingName = ($line -split '=')[0].Trim()
      $settingValue = ($line -split '=')[1].Trim()
      if ($settingValue -eq '1' -and $Global:enabledOptions -notcontains $settingName) {
        $Global:enabledOptions += $settingName
      }
               
    }
        
  }
}
Export-ModuleMember -Function Get-EnabledOptions

function Remove-CBS-Apps {
  param (
    [switch]$restore
  )

  Function Get-UserNameFromSID {
    Param (	[Parameter(ValueFromPipelineByPropertyName)]$SID = '' )
    $objSID = New-Object System.Security.Principal.SecurityIdentifier( $SID ) 
    $objUser = $objSID.Translate( [System.Security.Principal.NTAccount] ) 
    Return $objUser.Value 
  }

  Function Remove-NonRemovablePackage {
    param(
      [string]$name
    )
    $scriptPath = Search-File '*Remove-Locked.ps1'
    $command = ".$($scriptPath); Remove-Locked $name"
    run-trusted $command
  }

  Function Set-FilePathAdminsFullControl {
    Param(	[Parameter(ValueFromPipelineByPropertyName)]$FilePath )
    Process {
      $szUser = 'Administrators'
      $aclOrig = Get-Acl $FilePath
      $aclPath = Get-Acl $FilePath
      #Write-Host -ForegroundColor White "Setting '$szUser' to have full control of '$FilePath'..."
      $arPath = New-Object System.Security.AccessControl.FileSystemAccessRule( $szUser, 'FullControl', $([System.Security.AccessControl.InheritanceFlags]::None), 'None', 'Allow' )
      $aclPath.SetAccessRule( $arPath )
      Set-Acl $FilePath $aclPath
      Return $aclOrig
    }
  }

  Function Reset-FilePathACL {
    Param(	[Parameter(ValueFromPipelineByPropertyName)]$FilePath,
      [Parameter(ValueFromPipelineByPropertyName)]$ACL )
    Process {
      #Write-Host -ForegroundColor White "Resetting permissions on '$FilePath'..."
      Set-Acl $FilePath $ACL
    }
  }

  Function Hide-StartMenuItem {
    Param(	[Parameter(ValueFromPipelineByPropertyName)]$Name,
      [Parameter(ValueFromPipelineByPropertyName)]$DisplayName,
      [Parameter(ValueFromPipelineByPropertyName)]$XML )
    Process {
      $xmlNode = $XML.Package.Applications.Application | Where-Object { $_.Id -Eq $Name }
      If ( $xmlNode.VisualElements ) {
        $szAppListEntryValue = $xmlNode.VisualElements.GetAttribute( 'AppListEntry' )
        If ( $szAppListEntryValue -Ne 'none' ) {
          #Write-Host -ForegroundColor White "Hiding the Start menu item '$DisplayName'..."
          $xmlNode.VisualElements.SetAttribute( 'AppListEntry', 'none' )
        }
        Else {
          #Write-Host -ForegroundColor White "The Start menu item '$DisplayName' is already hidden."
        }
      }
    }
  }

  Function Get-XMLAttribute {
    Param(	[Parameter(ValueFromPipelineByPropertyName)]$Name,
      [Parameter(ValueFromPipelineByPropertyName)]$Attribute,
      [Parameter(ValueFromPipelineByPropertyName)]$XML,
      [Parameter(ValueFromPipelineByPropertyName)]$ShowError )
    Process {
      $szAttributeValue = ''
      $xmlNode = $XML | Where-Object { $_.Name -Eq $Name }
      If ( $xmlNode ) {
        $szAttributeValue = $xmlNode.GetAttribute( $Attribute )
      }
      ElseIf ( $ShowError ) {
        #Write-Host -ForegroundColor Red "ERROR: Failed to find the attribute '$Attribute' for '$Name'."
      }
      Return $szAttributeValue, $xmlNode
    }
  }


  Function Increment-PackageVersion {
    Param(	[Parameter(ValueFromPipelineByPropertyName)]$Name,
      [Parameter(ValueFromPipelineByPropertyName)]$Attribute,
      [Parameter(ValueFromPipelineByPropertyName)]$XML )
    Process {
      $szNewPackageVersion = ''
      $szPackageVersion, $xmlNode = Get-XMLAttribute -Name $Name -Attribute $Attribute -XML $XML -ShowError:$True
      If ( ($szPackageVersion -Ne '') -And ($Null -Ne $xmlNode) ) {
        $szNewPackageVersion = "$(([System.Version]$szPackageVersion).Major).$(([System.Version]$szPackageVersion).Minor).$(([System.Version]$szPackageVersion).Build).$(([System.Version]$szPackageVersion).Revision+1)"
        #Write-Host -ForegroundColor White "Changing package '$Name' version from '$szPackageVersion' to '$szNewPackageVersion'..."
        $xmlNode.SetAttribute( 'Version', $szNewPackageVersion )
      }
      Return $szNewPackageVersion
    }
  }

  Function Save-XMLFile {
    Param(	[Parameter(ValueFromPipelineByPropertyName)]$Name,
      [Parameter(ValueFromPipelineByPropertyName)]$Path,
      [Parameter(ValueFromPipelineByPropertyName)]$XML )
    Process {
      #Write-Host -ForegroundColor White "Saving the updated Appx manifest file for '$Name'..."
      $objUTF8WithoutBOM = New-Object System.Text.UTF8Encoding( $False )
      $objUTF8WithoutBOMSW = New-Object System.IO.StreamWriter( $Path, $False, $objUTF8WithoutBOM )
      $XML.Save( $objUTF8WithoutBOMSW )
      $objUTF8WithoutBOMSW.Close()
    }
  }

  Function Remove-StartMenuCBSItems {
    Param( [switch]$RestartExplorer )
    Process {
      $szCBSName = 'MicrosoftWindows.Client.CBS'
      $szCBSAppName = "$($szCBSName)_cw5n1h2txyewy"
      $szWindowsPath = [Environment]::GetFolderPath( 'Windows' )
      $szCBSXMLPath = "$szWindowsPath\SystemApps\$($szCBSAppName)\appxmanifest.xml"
      #Write-Host -ForegroundColor White "Reading the Appx manifest file for '$szCBSAppName'..."
      $xmlCBS = [XML]( Get-Content $szCBSXMLPath )
      $szCBSNewVersion = Increment-PackageVersion -Name $szCBSName -Attribute 'Version' -XML ($xmlCBS.Package.Identity)
      If ( $szCBSNewVersion -Eq '' ) { Return }
      $szCBSDesc = $xmlCBS.Package.Properties.Description
      If ( ($Null -Eq $szCBSDesc) -Or !($szCBSDesc.StartsWith('RemoveCBS')) ) {
        $szOrigCBSVersion = $szCBSVersion
        $objDescElement = $xmlCBS.CreateElement( 'Description', $xmlCBS.Package.Properties.NamespaceURI )
        $objDescElement.InnerText = "RemoveCBS_$szOrigCBSVersion"
        $xmlCBSNode = $xmlCBS.Package.Properties.AppendChild( $objDescElement )
      }
      Else {
        $szOrigCBSVersion = $szCBSDesc.Replace( 'RemoveCBS_', '' )
      }
      Hide-StartMenuItem -Name 'WebExperienceHost' -DisplayName 'Get Started' -XML $xmlCBS
      Hide-StartMenuItem -Name 'WindowsBackup' -DisplayName 'Windows Back up' -XML $xmlCBS
      #this doesnt seem to be there anymore (not sure for everyone)
      #Hide-StartMenuItem -Name 'CrossDeviceResumeApp' -DisplayName 'Continue from Phone' -XML $xmlCBS
      $szOrigBackFilePath = "$($szCBSXMLPath)_$($szOrigCBSVersion)_original.xml"
      If ( !(Test-Path -Path $szOrigBackFilePath) ) {
        #Write-Host -ForegroundColor White "Creating a backup of the original Appx manifest file for '$szCBSAppName'..."
        Copy-Item -Force -Path $szCBSXMLPath -Destination $szOrigBackFilePath
      }
      Else {
        #Write-Host -ForegroundColor White "Creating a backup of the current Appx manifest file for '$szCBSAppName'..."
        $szCurrentTime = (Get-Date).ToString( 'yyyy-MM-dd_HH-mm-ss' )
        Copy-Item -Force -Path $szCBSXMLPath -Destination "$($szCBSXMLPath)_$($szOrigCBSVersion)_$($szCurrentTime).xml"
      }
      $aclOrigCBSXML = Set-FilePathAdminsFullControl -FilePath $szCBSXMLPath
      Save-XMLFile -Name $szCBSAppName -Path $szCBSXMLPath -XML $xmlCBS
      Remove-NonRemovablePackage -Name $szCBSName
      #Write-Host -ForegroundColor White "Installing package '$szCBSName' for all users..."
      Get-AppxPackage -AllUsers -Name $szCBSName | ForEach-Object { Add-AppxPackage -ForceApplicationShutdown -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" }
      #Write-Host -ForegroundColor White 'Waiting a second...'
      Start-Sleep -Seconds 1
      If ( $RestartExplorer ) { Restart-Explorer }
      Reset-FilePathACL -FilePath $szCBSXMLPath -ACL $aclOrigCBSXML
    }
  }

  Function Restore-StartMenuCBSItems {
    Param( [switch]$RestartExplorer )
    Process {
      $szWindowsPath = [Environment]::GetFolderPath( 'Windows' )
      $szCBSName = 'MicrosoftWindows.Client.CBS'
      $szCBSAppName = "$($szCBSName)_cw5n1h2txyewy"
      $szCBSAppPath = "$szWindowsPath\SystemApps\$($szCBSAppName)"
      $szCBSXMLPath = "$szCBSAppPath\appxmanifest.xml"
      $szOrigCBSVersion = ''
      $szScriptName = 'RemoveCBS'
      #Write-Host -ForegroundColor White "Reading the Appx manifest file for '$szCBSAppName'..."
      $xmlCBS = [XML]( Get-Content $szCBSXMLPath )
      $szCBSDesc = $xmlCBS.Package.Properties.Description
      If ( ($Null -Eq $szCBSDesc) -Or !($szCBSDesc.StartsWith("$($szScriptName)_")) ) {
        #Write-Host -ForegroundColor Yellow "The original version of the package '$szCBSAppName' is currently installed. Taking no action."
        Return
      }
      Else {
        $szOrigCBSVersion = $szCBSDesc.Replace( "$($szScriptName)_", '' )
      }
      $szOrigBackFilePath = "$($szCBSXMLPath)_$($szOrigCBSVersion)_original.xml"
      Remove-NonRemovablePackage -Name $szCBSName
      If ( Test-Path -Path $szOrigBackFilePath ) {
        $szCBSNewVersion = Increment-PackageVersion -Name $szCBSName -Attribute 'Version' -XML ($xmlCBS.Package.Identity)
        $xmlOrigCBS = [XML]( Get-Content $szOrigBackFilePath )
        $xmlOrigCBS.Package.Identity.SetAttribute( 'Version', $szCBSNewVersion )
        Save-XMLFile -Name $szCBSAppName -Path $szOrigBackFilePath -XML $xmlOrigCBS
        $aclOrigCBSXML = Set-FilePathAdminsFullControl -FilePath $szCBSXMLPath
        #Write-Host -ForegroundColor White "Restoring the original AppX manifest file for '$szCBSAppName' (with a incremented revision number)..."
        Move-Item -Force -Path $szOrigBackFilePath -Destination $szCBSXMLPath
        Reset-FilePathACL -FilePath $szCBSXMLPath -ACL $aclOrigCBSXML
      }
      $aBackupFiles = Get-ChildItem "$szCBSAppPath\*" -Include 'appxmanifest.xml_*.xml'
      If ( $Null -Ne $aBackupFiles ) {
        #Write-Host -ForegroundColor White "Removing backups of the Appx manifest file for '$szCBSAppName'..."
        $aBackupFiles | Remove-Item
      }
      #Write-Host -ForegroundColor White "Installing package '$szCBSName' for all users..."
      Get-AppxPackage -AllUsers -Name $szCBSName | ForEach-Object { Add-AppxPackage -ForceApplicationShutdown -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" }
      If ( $RestartExplorer ) { Restart-Explorer }
    }
  }

  if ($restore) {
    Restore-StartMenuCBSItems -RestartExplorer
  }
  else {
    Remove-StartMenuCBSItems -RestartExplorer
  }
  
}
Export-ModuleMember -Function Remove-CBS-Apps





